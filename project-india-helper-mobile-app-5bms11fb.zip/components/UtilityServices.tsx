import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  Alert, 
  ActivityIndicator, 
  StyleSheet,
  Dimensions 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Zap, Droplets, Flame, Search, Calendar, AlertCircle, CheckCircle, Clock } from 'lucide-react-native';
import { utilityService, UtilityBillInfo, UtilityProvider } from '../services/utilityService';
import { useLanguage } from '../contexts/LanguageContext';

const { width } = Dimensions.get('window');

interface UtilityServicesProps {
  onServiceSelect?: (service: string) => void;
}

export default function UtilityServices({ onServiceSelect }: UtilityServicesProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'bills' | 'providers' | 'tips'>('bills');
  const [loading, setLoading] = useState(false);

  // Bill Info states
  const [selectedProvider, setSelectedProvider] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [billInfo, setBillInfo] = useState<UtilityBillInfo | null>(null);

  // Providers state
  const [providers, setProviders] = useState<UtilityProvider[]>([]);

  const handleBillCheck = async () => {
    if (!selectedProvider || !accountNumber) {
      Alert.alert('Error', 'Please select a provider and enter account number');
      return;
    }

    if (!utilityService.validateAccountNumber(accountNumber, selectedProvider)) {
      Alert.alert('Error', 'Please enter a valid account number for the selected provider');
      return;
    }

    setLoading(true);
    try {
      const info = await utilityService.getBillInfo(selectedProvider, accountNumber);
      setBillInfo(info);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to get bill information');
    } finally {
      setLoading(false);
    }
  };

  const handleGetProviders = async () => {
    setLoading(true);
    try {
      const providersList = await utilityService.getUtilityProviders();
      setProviders(providersList);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to get providers');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { key: 'bills', title: 'Bill Info', icon: Search, color: '#4285F4' },
    { key: 'providers', title: 'Providers', icon: Zap, color: '#00A86B' },
    { key: 'tips', title: 'Tips & Help', icon: AlertCircle, color: '#9C27B0' },
  ];

  const renderTabButton = (tab: any) => (
    <TouchableOpacity
      key={tab.key}
      onPress={() => setActiveTab(tab.key as any)}
      style={[
        styles.tabButton,
        activeTab === tab.key && { backgroundColor: tab.color }
      ]}
    >
      <tab.icon 
        size={18} 
        color={activeTab === tab.key ? 'white' : '#666'} 
      />
      <Text style={[
        styles.tabButtonText,
        activeTab === tab.key && styles.tabButtonTextActive
      ]}>
        {tab.title}
      </Text>
    </TouchableOpacity>
  );

  const renderInputField = (
    label: string, 
    value: string, 
    onChangeText: (text: string) => void, 
    placeholder: string,
    keyboardType: 'default' | 'numeric' = 'default'
  ) => (
    <View style={styles.inputContainer}>
      <Text style={styles.inputLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        style={styles.textInput}
        keyboardType={keyboardType}
        placeholderTextColor="#999"
      />
    </View>
  );

  const renderActionButton = (
    title: string, 
    onPress: () => void, 
    icon: React.ReactNode, 
    color: string,
    disabled: boolean = false
  ) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={[styles.actionButton, { backgroundColor: color }]}
    >
      {loading ? (
        <ActivityIndicator color="white" size="small" />
      ) : (
        <>
          {icon}
          <Text style={styles.actionButtonText}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );

  const getUtilityIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'electricity': return Zap;
      case 'water': return Droplets;
      case 'gas': return Flame;
      default: return Zap;
    }
  };

  const getUtilityColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'electricity': return '#FFD700';
      case 'water': return '#4285F4';
      case 'gas': return '#FF6B35';
      default: return '#4285F4';
    }
  };

  const renderBillsTab = () => (
    <View style={styles.tabContent}>
      {/* Provider Selection */}
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Select Provider</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.providerScroll}>
          {['BESCOM', 'KSEB', 'TNEB', 'BWSSB', 'IGL'].map((provider) => (
            <TouchableOpacity
              key={provider}
              onPress={() => setSelectedProvider(provider)}
              style={[
                styles.providerChip,
                selectedProvider === provider && styles.providerChipActive
              ]}
            >
              <Text style={[
                styles.providerChipText,
                selectedProvider === provider && styles.providerChipTextActive
              ]}>
                {provider}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {renderInputField(
        'Account Number',
        accountNumber,
        setAccountNumber,
        'Enter your account number',
        'numeric'
      )}

      {renderActionButton(
        'Get Bill Info',
        handleBillCheck,
        <Search size={20} color="white" />,
        '#4285F4'
      )}

      {billInfo && (
        <View style={styles.resultCard}>
          <LinearGradient
            colors={['#4285F4', '#5A9BF8']}
            style={styles.resultHeader}
          >
            <Text style={styles.resultTitle}>{billInfo.provider} Bill</Text>
            <Text style={styles.resultSubtitle}>Account: {billInfo.accountNumber}</Text>
          </LinearGradient>
          
          <View style={styles.resultContent}>
            <View style={styles.billAmountSection}>
              <Text style={styles.billAmountLabel}>Amount Due</Text>
              <Text style={styles.billAmountValue}>
                {utilityService.formatCurrency(billInfo.billAmount)}
              </Text>
            </View>

            <View style={styles.billDetailsGrid}>
              <View style={styles.billDetailItem}>
                <Text style={styles.billDetailLabel}>Due Date</Text>
                <Text style={styles.billDetailValue}>{billInfo.dueDate}</Text>
                <View style={styles.dueDateStatus}>
                  {(() => {
                    const status = utilityService.getDueDateStatus(billInfo.dueDate);
                    const StatusIcon = status.status === 'overdue' ? AlertCircle : 
                                     status.status === 'urgent' ? Clock : CheckCircle;
                    return (
                      <>
                        <StatusIcon size={12} color={status.color} />
                        <Text style={[styles.dueDateText, { color: status.color }]}>
                          {status.message}
                        </Text>
                      </>
                    );
                  })()}
                </View>
              </View>

              <View style={styles.billDetailItem}>
                <Text style={styles.billDetailLabel}>Bill Date</Text>
                <Text style={styles.billDetailValue}>{billInfo.billDate}</Text>
              </View>

              {billInfo.unitsConsumed && (
                <View style={styles.billDetailItem}>
                  <Text style={styles.billDetailLabel}>Units Consumed</Text>
                  <Text style={styles.billDetailValue}>{billInfo.unitsConsumed}</Text>
                </View>
              )}

              {billInfo.tariffRate && (
                <View style={styles.billDetailItem}>
                  <Text style={styles.billDetailLabel}>Tariff Rate</Text>
                  <Text style={styles.billDetailValue}>₹{billInfo.tariffRate}</Text>
                </View>
              )}
            </View>

            {billInfo.previousReading && billInfo.currentReading && (
              <View style={styles.readingsSection}>
                <Text style={styles.readingsTitle}>Meter Readings</Text>
                <View style={styles.readingsGrid}>
                  <View style={styles.readingItem}>
                    <Text style={styles.readingLabel}>Previous</Text>
                    <Text style={styles.readingValue}>{billInfo.previousReading}</Text>
                  </View>
                  <View style={styles.readingItem}>
                    <Text style={styles.readingLabel}>Current</Text>
                    <Text style={styles.readingValue}>{billInfo.currentReading}</Text>
                  </View>
                  <View style={styles.readingItem}>
                    <Text style={styles.readingLabel}>Consumption</Text>
                    <Text style={styles.readingValue}>
                      {billInfo.currentReading - billInfo.previousReading}
                    </Text>
                  </View>
                </View>
              </View>
            )}

            <TouchableOpacity style={styles.payButton}>
              <Text style={styles.payButtonText}>Pay Bill</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Quick Provider Access */}
      <View style={styles.quickAccessSection}>
        <Text style={styles.sectionTitle}>Quick Access</Text>
        <View style={styles.quickAccessGrid}>
          {Object.entries(utilityService.getProvidersByState()).slice(0, 2).map(([state, stateProviders]) => (
            stateProviders.slice(0, 2).map((provider, index) => {
              const UtilityIcon = getUtilityIcon(provider.type);
              const color = getUtilityColor(provider.type);
              
              return (
                <TouchableOpacity
                  key={`${state}-${index}`}
                  style={styles.quickAccessCard}
                  onPress={() => setSelectedProvider(provider.name)}
                >
                  <View style={[styles.quickAccessIcon, { backgroundColor: color + '20' }]}>
                    <UtilityIcon size={24} color={color} />
                  </View>
                  <Text style={styles.quickAccessTitle}>{provider.name}</Text>
                  <Text style={styles.quickAccessSubtitle}>{provider.type}</Text>
                  <Text style={styles.quickAccessState}>{provider.state}</Text>
                </TouchableOpacity>
              );
            })
          )).flat()}
        </View>
      </View>
    </View>
  );

  const renderProvidersTab = () => (
    <View style={styles.tabContent}>
      {renderActionButton(
        'Load All Providers',
        handleGetProviders,
        <Zap size={20} color="white" />,
        '#00A86B'
      )}

      {providers.length > 0 ? (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Utility Providers ({providers.length})</Text>
          {providers.map((provider, index) => {
            const UtilityIcon = getUtilityIcon(provider.type);
            const color = getUtilityColor(provider.type);
            
            return (
              <View key={index} style={styles.providerCard}>
                <View style={styles.providerHeader}>
                  <View style={[styles.providerIcon, { backgroundColor: color + '20' }]}>
                    <UtilityIcon size={24} color={color} />
                  </View>
                  <View style={styles.providerInfo}>
                    <Text style={styles.providerName}>{provider.name}</Text>
                    <Text style={styles.providerFullName}>{provider.fullName}</Text>
                    <Text style={styles.providerDetails}>{provider.type} • {provider.state}</Text>
                  </View>
                </View>
                <TouchableOpacity 
                  style={styles.selectProviderButton}
                  onPress={() => {
                    setSelectedProvider(provider.name);
                    setActiveTab('bills');
                  }}
                >
                  <Text style={styles.selectProviderText}>Select</Text>
                </TouchableOpacity>
              </View>
            );
          })}
        </ScrollView>
      ) : (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Providers by State</Text>
          {Object.entries(utilityService.getProvidersByState()).map(([state, stateProviders]) => (
            <View key={state} style={styles.stateSection}>
              <Text style={styles.stateTitle}>{state}</Text>
              {stateProviders.map((provider, index) => {
                const UtilityIcon = getUtilityIcon(provider.type);
                const color = getUtilityColor(provider.type);
                
                return (
                  <View key={index} style={styles.providerCard}>
                    <View style={styles.providerHeader}>
                      <View style={[styles.providerIcon, { backgroundColor: color + '20' }]}>
                        <UtilityIcon size={20} color={color} />
                      </View>
                      <View style={styles.providerInfo}>
                        <Text style={styles.providerName}>{provider.name}</Text>
                        <Text style={styles.providerType}>{provider.type}</Text>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );

  const renderTipsTab = () => (
    <View style={styles.tabContent}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Bill Payment Tips</Text>
          {utilityService.getBillPaymentTips().map((tip, index) => (
            <View key={index} style={styles.tipItem}>
              <Text style={styles.tipBullet}>•</Text>
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Energy Saving Tips</Text>
          {utilityService.getEnergySavingTips().map((tip, index) => (
            <View key={index} style={styles.tipItem}>
              <Zap size={12} color="#FFD700" />
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Water Conservation Tips</Text>
          {utilityService.getWaterSavingTips().map((tip, index) => (
            <View key={index} style={styles.tipItem}>
              <Droplets size={12} color="#4285F4" />
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Common Issues & Solutions</Text>
          {utilityService.getBillIssuesAndSolutions().map((item, index) => (
            <View key={index} style={styles.issueItem}>
              <Text style={styles.issueTitle}>{item.issue}</Text>
              <Text style={styles.issueSolution}>{item.solution}</Text>
            </View>
          ))}
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Emergency Contacts</Text>
          {Object.entries(utilityService.getEmergencyContacts()).map(([type, contacts]) => (
            <View key={type} style={styles.emergencySection}>
              <Text style={styles.emergencyType}>{type}</Text>
              {contacts.map((contact, index) => (
                <View key={index} style={styles.emergencyContact}>
                  <Text style={styles.emergencyService}>{contact.service}</Text>
                  <Text style={styles.emergencyNumber}>{contact.number}</Text>
                  <Text style={styles.emergencyAvailable}>{contact.available}</Text>
                </View>
              ))}
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabScrollContainer}
        >
          {tabs.map(renderTabButton)}
        </ScrollView>
      </View>

      {/* Tab Content */}
      <ScrollView style={styles.contentContainer} showsVerticalScrollIndicator={false}>
        {activeTab === 'bills' && renderBillsTab()}
        {activeTab === 'providers' && renderProvidersTab()}
        {activeTab === 'tips' && renderTipsTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  tabContainer: {
    backgroundColor: 'white',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  tabScrollContainer: {
    paddingHorizontal: 20,
    gap: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    minWidth: 120,
  },
  tabButtonText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  tabButtonTextActive: {
    color: 'white',
  },
  contentContainer: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E5E5E5',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    backgroundColor: 'white',
    color: '#333',
  },
  providerScroll: {
    marginTop: 8,
  },
  providerChip: {
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  providerChipActive: {
    backgroundColor: '#4285F4',
  },
  providerChipText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  providerChipTextActive: {
    color: 'white',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  resultCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  resultHeader: {
    padding: 20,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  resultSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
  },
  resultContent: {
    padding: 20,
    gap: 20,
  },
  billAmountSection: {
    alignItems: 'center',
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  billAmountLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  billAmountValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
  },
  billDetailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  billDetailItem: {
    flex: 1,
    minWidth: '45%',
  },
  billDetailLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  billDetailValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  dueDateStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  dueDateText: {
    fontSize: 12,
    fontWeight: '600',
  },
  readingsSection: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
  },
  readingsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  readingsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  readingItem: {
    alignItems: 'center',
  },
  readingLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  readingValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  payButton: {
    backgroundColor: '#00A86B',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  payButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  quickAccessSection: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  quickAccessGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  quickAccessCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    width: (width - 60) / 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  quickAccessIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  quickAccessTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  quickAccessSubtitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  quickAccessState: {
    fontSize: 10,
    color: '#999',
  },
  resultsContainer: {
    maxHeight: 500,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  providerCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  providerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  providerIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  providerInfo: {
    flex: 1,
  },
  providerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  providerFullName: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  providerDetails: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  providerType: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  selectProviderButton: {
    backgroundColor: '#4285F4',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
  },
  selectProviderText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  stateSection: {
    marginBottom: 24,
  },
  stateTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  tipsSection: {
    marginBottom: 24,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    gap: 8,
  },
  tipBullet: {
    fontSize: 16,
    color: '#4285F4',
    marginTop: 2,
  },
  tipText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 20,
  },
  issueItem: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  issueTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  issueSolution: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  emergencySection: {
    marginBottom: 20,
  },
  emergencyType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  emergencyContact: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  emergencyService: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  emergencyNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4285F4',
    marginBottom: 2,
  },
  emergencyAvailable: {
    fontSize: 12,
    color: '#666',
  },
});