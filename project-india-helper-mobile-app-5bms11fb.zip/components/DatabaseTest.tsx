import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert, ScrollView } from 'react-native';
import { blink } from '@/lib/blink';
import { useAuth } from '@/contexts/AuthContext';

export default function DatabaseTest() {
  const { user, isAuthenticated } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [testing, setTesting] = useState(false);

  const addTestResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${result}`]);
  };

  const testBillOperations = async () => {
    if (!user) {
      addTestResult('❌ No user authenticated');
      return;
    }

    setTesting(true);
    addTestResult('🧪 Starting Bill Manager tests...');

    try {
      // Test 1: Create a test bill
      addTestResult('📝 Creating test bill...');
      const testBill = await blink.db.bills.create({
        id: `test_bill_${Date.now()}`,
        userId: user.id,
        billType: 'electricity',
        providerName: 'Test Provider',
        accountNumber: '123456789',
        amount: '1500.00',
        dueDate: '2025-01-15',
        paymentStatus: 'pending',
        reminderEnabled: 'true',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      addTestResult(`✅ Bill created with ID: ${testBill.id}`);

      // Test 2: Fetch user bills
      addTestResult('📋 Fetching user bills...');
      const userBills = await blink.db.bills.list({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
      });
      addTestResult(`✅ Found ${userBills.length} bills for user`);

      // Test 3: Update bill payment status
      addTestResult('💳 Updating bill payment status...');
      const updatedBill = await blink.db.bills.update(testBill.id, {
        paymentStatus: 'paid',
        paymentDate: new Date().toISOString(),
        paymentMethod: 'UPI',
        updatedAt: new Date().toISOString(),
      });
      addTestResult(`✅ Bill payment status updated to: ${updatedBill.paymentStatus}`);

      // Test 4: Delete test bill
      addTestResult('🗑️ Cleaning up test bill...');
      await blink.db.bills.delete(testBill.id);
      addTestResult('✅ Test bill deleted successfully');

      addTestResult('🎉 All Bill Manager tests passed!');
    } catch (error) {
      addTestResult(`❌ Test failed: ${error.message}`);
      console.error('Database test error:', error);
    } finally {
      setTesting(false);
    }
  };

  const clearResults = () => {
    setTestResults([]);
  };

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#FAFAFA' }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', marginBottom: 20, color: '#003366' }}>
        Database Test Console
      </Text>
      
      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 20 }}>
        <TouchableOpacity
          onPress={testBillOperations}
          disabled={testing || !isAuthenticated}
          style={{
            backgroundColor: testing || !isAuthenticated ? '#ccc' : '#00A86B',
            paddingHorizontal: 20,
            paddingVertical: 10,
            borderRadius: 8,
            flex: 1,
          }}
        >
          <Text style={{ color: 'white', textAlign: 'center', fontWeight: '600' }}>
            {testing ? 'Testing...' : 'Test Bill Manager'}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          onPress={clearResults}
          style={{
            backgroundColor: '#666',
            paddingHorizontal: 20,
            paddingVertical: 10,
            borderRadius: 8,
          }}
        >
          <Text style={{ color: 'white', textAlign: 'center', fontWeight: '600' }}>
            Clear
          </Text>
        </TouchableOpacity>
      </View>

      {!isAuthenticated && (
        <View style={{ 
          backgroundColor: '#FFF3CD', 
          padding: 15, 
          borderRadius: 8, 
          marginBottom: 20,
          borderLeftWidth: 4,
          borderLeftColor: '#FFC107'
        }}>
          <Text style={{ color: '#856404', fontWeight: '600' }}>
            ⚠️ Please sign in to test Bill Manager functionality
          </Text>
        </View>
      )}

      <ScrollView 
        style={{ 
          flex: 1, 
          backgroundColor: 'white', 
          borderRadius: 8, 
          padding: 15,
          borderWidth: 1,
          borderColor: '#E5E5E5'
        }}
        showsVerticalScrollIndicator={false}
      >
        {testResults.length === 0 ? (
          <Text style={{ color: '#666', fontStyle: 'italic' }}>
            No test results yet. Click "Test Bill Manager" to run tests.
          </Text>
        ) : (
          testResults.map((result, index) => (
            <Text 
              key={index} 
              style={{ 
                marginBottom: 8, 
                fontSize: 14, 
                fontFamily: 'monospace',
                color: result.includes('❌') ? '#F44336' : 
                       result.includes('✅') ? '#00A86B' : 
                       result.includes('🧪') || result.includes('🎉') ? '#9C27B0' : '#333'
              }}
            >
              {result}
            </Text>
          ))
        )}
      </ScrollView>
    </View>
  );
}