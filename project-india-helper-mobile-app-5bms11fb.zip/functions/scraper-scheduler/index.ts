import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

interface SchedulerConfig {
  service: string;
  action: string;
  interval: number; // in minutes
  enabled: boolean;
  lastRun?: string;
  nextRun?: string;
}

interface ScrapingJob {
  id: string;
  service: string;
  action: string;
  data: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  error?: string;
  result?: any;
}

const UNIVERSAL_SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

// Default scraping schedules
const DEFAULT_SCHEDULES: SchedulerConfig[] = [
  {
    service: 'bus',
    action: 'operators',
    interval: 1440, // Daily
    enabled: true
  },
  {
    service: 'flight',
    action: 'search',
    interval: 60, // Hourly for popular routes
    enabled: true
  },
  {
    service: 'utility',
    action: 'providers',
    interval: 10080, // Weekly
    enabled: true
  },
  {
    service: 'hotel',
    action: 'search',
    interval: 720, // Twice daily
    enabled: false // Coming soon
  },
  {
    service: 'airport',
    action: 'info',
    interval: 1440, // Daily
    enabled: false // Coming soon
  },
  {
    service: 'fuel',
    action: 'prices',
    interval: 360, // Every 6 hours
    enabled: false // Coming soon
  },
  {
    service: 'hospital',
    action: 'search',
    interval: 10080, // Weekly
    enabled: false // Coming soon
  }
];

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    switch (action) {
      case 'run-scheduled':
        return await runScheduledJobs();
      case 'add-schedule':
        return await addSchedule(req);
      case 'get-schedules':
        return await getSchedules();
      case 'get-jobs':
        return await getJobs(req);
      case 'run-job':
        return await runJob(req);
      default:
        return createErrorResponse('Invalid action');
    }
  } catch (error) {
    console.error('Scheduler Error:', error);
    return createErrorResponse('Internal server error: ' + error.message);
  }
});

async function runScheduledJobs(): Promise<Response> {
  try {
    const schedules = await getStoredSchedules();
    const now = new Date();
    const jobsToRun: ScrapingJob[] = [];

    for (const schedule of schedules) {
      if (!schedule.enabled) continue;

      const lastRun = schedule.lastRun ? new Date(schedule.lastRun) : new Date(0);
      const minutesSinceLastRun = (now.getTime() - lastRun.getTime()) / (1000 * 60);

      if (minutesSinceLastRun >= schedule.interval) {
        const job: ScrapingJob = {
          id: generateJobId(),
          service: schedule.service,
          action: schedule.action,
          data: getDefaultDataForJob(schedule.service, schedule.action),
          status: 'pending',
          createdAt: now.toISOString()
        };

        jobsToRun.push(job);
      }
    }

    // Execute jobs
    const results = [];
    for (const job of jobsToRun) {
      try {
        const result = await executeScrapingJob(job);
        results.push(result);
        
        // Update schedule last run time
        await updateScheduleLastRun(job.service, job.action, now.toISOString());
      } catch (error) {
        console.error(`Job ${job.id} failed:`, error);
        results.push({
          ...job,
          status: 'failed',
          error: error.message,
          completedAt: new Date().toISOString()
        });
      }
    }

    return createSuccessResponse({
      jobsRun: results.length,
      results: results
    }, 'scheduled-jobs');
  } catch (error) {
    return createErrorResponse('Failed to run scheduled jobs: ' + error.message);
  }
}

async function executeScrapingJob(job: ScrapingJob): Promise<ScrapingJob> {
  try {
    job.status = 'running';
    
    const response = await fetch(`${UNIVERSAL_SCRAPER_URL}?service=${job.service}&action=${job.action}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(job.data),
    });

    if (!response.ok) {
      throw new Error(`Scraper request failed: ${response.status}`);
    }

    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Scraping failed');
    }

    job.status = 'completed';
    job.result = result.data;
    job.completedAt = new Date().toISOString();

    // Store result in cache/database for quick access
    await storeScrapingResult(job);

    return job;
  } catch (error) {
    job.status = 'failed';
    job.error = error.message;
    job.completedAt = new Date().toISOString();
    throw error;
  }
}

async function addSchedule(req: Request): Promise<Response> {
  try {
    const schedule: SchedulerConfig = await req.json();
    
    // Validate schedule
    if (!schedule.service || !schedule.action || !schedule.interval) {
      return createErrorResponse('Service, action, and interval are required');
    }

    if (schedule.interval < 5) {
      return createErrorResponse('Minimum interval is 5 minutes');
    }

    const schedules = await getStoredSchedules();
    
    // Check if schedule already exists
    const existingIndex = schedules.findIndex(s => 
      s.service === schedule.service && s.action === schedule.action
    );

    if (existingIndex >= 0) {
      schedules[existingIndex] = schedule;
    } else {
      schedules.push(schedule);
    }

    await storeSchedules(schedules);

    return createSuccessResponse(schedule, 'schedule-added');
  } catch (error) {
    return createErrorResponse('Failed to add schedule: ' + error.message);
  }
}

async function getSchedules(): Promise<Response> {
  try {
    const schedules = await getStoredSchedules();
    return createSuccessResponse(schedules, 'schedules');
  } catch (error) {
    return createErrorResponse('Failed to get schedules: ' + error.message);
  }
}

async function getJobs(req: Request): Promise<Response> {
  try {
    const url = new URL(req.url);
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const status = url.searchParams.get('status');

    // In a real implementation, this would query a database
    // For now, return mock job history
    const mockJobs: ScrapingJob[] = [
      {
        id: 'job_001',
        service: 'bus',
        action: 'operators',
        data: {},
        status: 'completed',
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        completedAt: new Date(Date.now() - 3500000).toISOString(),
        result: { operators: 6 }
      },
      {
        id: 'job_002',
        service: 'flight',
        action: 'search',
        data: { from: 'DEL', to: 'BOM', date: '2024-02-15' },
        status: 'completed',
        createdAt: new Date(Date.now() - 1800000).toISOString(),
        completedAt: new Date(Date.now() - 1700000).toISOString(),
        result: { flights: 12 }
      }
    ];

    let filteredJobs = mockJobs;
    if (status) {
      filteredJobs = mockJobs.filter(job => job.status === status);
    }

    return createSuccessResponse(filteredJobs.slice(0, limit), 'jobs');
  } catch (error) {
    return createErrorResponse('Failed to get jobs: ' + error.message);
  }
}

async function runJob(req: Request): Promise<Response> {
  try {
    const { service, action, data } = await req.json();
    
    if (!service || !action) {
      return createErrorResponse('Service and action are required');
    }

    const job: ScrapingJob = {
      id: generateJobId(),
      service,
      action,
      data: data || getDefaultDataForJob(service, action),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    const result = await executeScrapingJob(job);
    return createSuccessResponse(result, 'job-executed');
  } catch (error) {
    return createErrorResponse('Failed to run job: ' + error.message);
  }
}

// Helper functions
async function getStoredSchedules(): Promise<SchedulerConfig[]> {
  // In a real implementation, this would read from a database
  // For now, return default schedules
  return DEFAULT_SCHEDULES;
}

async function storeSchedules(schedules: SchedulerConfig[]): Promise<void> {
  // In a real implementation, this would save to a database
  console.log('Storing schedules:', schedules);
}

async function updateScheduleLastRun(service: string, action: string, lastRun: string): Promise<void> {
  // In a real implementation, this would update the database
  console.log(`Updated last run for ${service}/${action}: ${lastRun}`);
}

async function storeScrapingResult(job: ScrapingJob): Promise<void> {
  // In a real implementation, this would cache the result
  console.log(`Stored result for job ${job.id}:`, job.result);
}

function getDefaultDataForJob(service: string, action: string): any {
  switch (service) {
    case 'bus':
      if (action === 'search') {
        return { from: 'Bangalore', to: 'Chennai', date: new Date().toISOString().split('T')[0] };
      }
      return {};
    
    case 'flight':
      if (action === 'search') {
        return { from: 'DEL', to: 'BOM', date: new Date().toISOString().split('T')[0] };
      }
      return {};
    
    case 'utility':
      return {};
    
    case 'hotel':
      if (action === 'search') {
        return { 
          location: 'Mumbai', 
          checkIn: new Date().toISOString().split('T')[0], 
          checkOut: new Date(Date.now() + 86400000).toISOString().split('T')[0],
          guests: 2,
          rooms: 1
        };
      }
      return {};
    
    case 'airport':
      if (action === 'info') {
        return { airportCode: 'DEL' };
      }
      return {};
    
    case 'fuel':
      if (action === 'prices') {
        return { city: 'Mumbai' };
      }
      return {};
    
    case 'hospital':
      if (action === 'search') {
        return { location: 'Bangalore' };
      }
      return {};
    
    default:
      return {};
  }
}

function generateJobId(): string {
  return 'job_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function createSuccessResponse<T>(data: T, source: string): Response {
  const response = {
    success: true,
    data,
    timestamp: new Date().toISOString(),
    source
  };

  return new Response(JSON.stringify(response), {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
}

function createErrorResponse(error: string): Response {
  const response = {
    success: false,
    error,
    timestamp: new Date().toISOString(),
    source: 'scraper-scheduler'
  };

  return new Response(JSON.stringify(response), {
    status: 400,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
}