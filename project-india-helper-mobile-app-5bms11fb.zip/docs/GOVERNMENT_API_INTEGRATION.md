# Government API Integration Guide

## 🇮🇳 Real Government APIs Available in India

### 1. **Digital India APIs**
- **API Gateway**: https://api.digitalindia.gov.in/
- **Services**: Aadhaar verification, PAN verification, Driving License
- **Authentication**: OAuth 2.0, API Keys
- **Status**: Production Ready

### 2. **Aadhaar APIs (UIDAI)**
- **Verification API**: https://resident.uidai.gov.in/
- **Services**: Aadhaar number verification, demographic authentication
- **Authentication**: AUA/KUA license required
- **Cost**: ₹0.50 per verification
- **Documentation**: https://uidai.gov.in/ecosystem/authentication-devices-documents/developer-section.html

### 3. **PAN APIs (Income Tax Department)**
- **Verification API**: https://www.incometax.gov.in/iec/foportal/
- **Services**: PAN verification, status check
- **Authentication**: API Key + Digital Certificate
- **Cost**: ₹5 per verification

### 4. **Passport APIs (MEA)**
- **Status API**: https://passportindia.gov.in/AppOnlineProject/statusEnquiry/
- **Services**: Application status, appointment booking
- **Authentication**: Application number + DOB
- **Cost**: Free for status check

### 5. **Driving License APIs (Parivahan)**
- **API**: https://parivahan.gov.in/parivahan/
- **Services**: DL verification, RC verification, challan status
- **Authentication**: State-specific APIs
- **Cost**: Varies by state

### 6. **Railway APIs (IRCTC)**
- **API**: https://www.irctc.co.in/nget/
- **Services**: PNR status, train running status, seat availability
- **Authentication**: API Key
- **Cost**: Commercial rates apply

### 7. **DigiLocker APIs**
- **API**: https://digilocker.gov.in/
- **Services**: Document verification, digital document access
- **Authentication**: OAuth 2.0
- **Cost**: Free for basic usage

## 🔐 Security Requirements

### API Key Management
- Store all API keys in Blink Vault (encrypted)
- Use Blink Edge Functions for secure API calls
- Never expose keys in frontend code

### Authentication Flow
1. User provides consent for data access
2. App authenticates with government API
3. Secure data exchange via encrypted channels
4. Store minimal data, respect privacy

## 🚀 Implementation Strategy

### Phase 1: Core APIs (Immediate)
- PNR Status (Railway)
- Passport Status Check
- Basic Aadhaar verification (if license obtained)

### Phase 2: Document Verification
- PAN verification
- Driving License verification
- DigiLocker integration

### Phase 3: Advanced Services
- Government scheme eligibility
- Real-time application tracking
- Document upload and verification

## 📋 API Integration Checklist

### Before Integration:
- [ ] Obtain necessary licenses (AUA for Aadhaar)
- [ ] Register with API providers
- [ ] Get API keys and certificates
- [ ] Set up test environment
- [ ] Implement security measures

### During Integration:
- [ ] Create Blink Edge Functions for each API
- [ ] Implement error handling and fallbacks
- [ ] Add rate limiting and caching
- [ ] Test with real data
- [ ] Monitor API usage and costs

### After Integration:
- [ ] Monitor API performance
- [ ] Handle API changes and updates
- [ ] Maintain compliance with regulations
- [ ] Regular security audits

## 💰 Cost Considerations

| Service | Cost per Request | Monthly Limit | Notes |
|---------|------------------|---------------|-------|
| Aadhaar Verification | ₹0.50 | 10,000 | Requires AUA license |
| PAN Verification | ₹5.00 | 1,000 | Digital certificate needed |
| PNR Status | ₹0.10 | 50,000 | IRCTC commercial rates |
| Passport Status | Free | Unlimited | Rate limited |
| DigiLocker | Free | 10,000 | OAuth required |

## 🔧 Technical Implementation

### Edge Function Structure
```typescript
// functions/government-api/index.ts
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

serve(async (req) => {
  const { service, data } = await req.json();
  
  switch (service) {
    case 'pnr_status':
      return await checkPNRStatus(data.pnr);
    case 'passport_status':
      return await checkPassportStatus(data.applicationNumber, data.dob);
    case 'aadhaar_verify':
      return await verifyAadhaar(data.aadhaarNumber);
    default:
      return new Response('Service not found', { status: 404 });
  }
});
```

### Frontend Integration
```typescript
// Use Blink's secure API proxy
const response = await blink.data.fetch({
  url: 'https://your-edge-function-url/government-api',
  method: 'POST',
  headers: {
    'Authorization': 'Bearer {{government_api_key}}',
    'Content-Type': 'application/json'
  },
  body: {
    service: 'pnr_status',
    data: { pnr: pnrNumber }
  }
});
```

## 📞 Getting Started

### 1. Railway PNR Status (Easiest to implement)
- Register at: https://railwayapi.com/
- Get API key
- Implement PNR status checking

### 2. Passport Status
- Use public API: https://passportindia.gov.in/
- No registration required for status check
- Parse HTML response or use unofficial APIs

### 3. DigiLocker Integration
- Register at: https://digilocker.gov.in/
- OAuth 2.0 setup
- Document verification capabilities

## 🚨 Important Notes

1. **Compliance**: Ensure GDPR/Data Protection compliance
2. **Rate Limits**: Respect API rate limits to avoid blocking
3. **Fallbacks**: Always have fallback mechanisms
4. **User Consent**: Get explicit user consent for data access
5. **Data Retention**: Follow government guidelines for data storage

## 📞 Support Contacts

- **Digital India**: support@digitalindia.gov.in
- **UIDAI**: help@uidai.gov.in
- **IRCTC**: care@irctc.co.in
- **Passport Seva**: support@passportindia.gov.in