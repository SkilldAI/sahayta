# API Setu Integration Guide

## Overview

**API Setu** is India's official government API directory with **3,497 APIs** from **2,259 organizations** including central and state governments. This is the primary source for integrating real government APIs into our India Helper app.

🌐 **Website**: https://directory.apisetu.gov.in/
📊 **Statistics**: 3,497 APIs | 2,259 Organizations | 137 Central Govt | 1,967 State Govt | 100 Private Sector

## Key API Categories for India Helper App

### 1. Identity Documents (61 APIs)
**Perfect for Aadhaar/PAN verification and document management**

#### Available APIs:
- **PAN Verification** - Income Tax Department
  - Individual PAN verification
  - Organization PAN verification
  - Provider: DigiLocker
  - URL: https://directory.apisetu.gov.in/api-collection/pan

- **Driving License & Vehicle Registration** - Ministry of Road Transport
  - Driving License verification
  - Vehicle Registration Certificate
  - Provider: SARATHI & VAHAN systems
  - URL: https://directory.apisetu.gov.in/api-collection/transport

- **EPFO Services** - Employees Provident Fund Organization
  - UAN verification
  - Pension Payment Order
  - Scheme Certificates
  - URL: https://directory.apisetu.gov.in/api-collection/epfindia

### 2. Transport & Infrastructure
**For transportation booking and status tracking**

- Railway APIs (IRCTC integration)
- Bus booking systems
- Flight status APIs
- Traffic and route information

### 3. Banking & Financial Services
**For financial tools and GST calculations**

- GST verification APIs
- Banking service APIs
- Financial scheme information
- Tax calculation services

### 4. Utility Services
**For bill payments and utility management**

- Electricity bill APIs
- Water bill services
- Gas connection APIs
- Telecom services

### 5. Government & Public Sector
**For government scheme applications and status tracking**

- Scheme application APIs
- Status tracking services
- Government portal integrations
- Citizen services

## Integration Architecture

### Step 1: API Setu Registration
1. Visit https://partners.apisetu.gov.in/signup
2. Create developer account
3. Subscribe to required APIs
4. Obtain API keys and credentials

### Step 2: Authentication Methods
API Setu uses multiple authentication methods:
- **API Keys** - For basic authentication
- **OAuth 2.0** - For secure access
- **DigiLocker Integration** - For document verification
- **JWT Tokens** - For session management

### Step 3: Implementation Strategy

#### A. Blink Edge Functions Integration
```typescript
// functions/api-setu/index.ts
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  const { service, action, data } = await req.json();
  
  // Route to specific API Setu services
  switch (service) {
    case 'pan_verification':
      return await verifyPAN(data);
    case 'driving_license':
      return await verifyDrivingLicense(data);
    case 'vehicle_registration':
      return await verifyVehicleRegistration(data);
    default:
      return new Response(JSON.stringify({ error: 'Service not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      });
  }
});

async function verifyPAN(data: { panNumber: string }) {
  const response = await fetch('https://api.apisetu.gov.in/pan/verify', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${Deno.env.get('API_SETU_TOKEN')}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      pan: data.panNumber,
      consent: 'Y'
    })
  });
  
  return new Response(JSON.stringify(await response.json()), {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
}
```

#### B. Frontend Integration
```typescript
// services/apiSetuService.ts
import { blink } from '../lib/blink';

export class ApiSetuService {
  private static baseUrl = 'https://your-function-url.deno.dev';

  static async verifyPAN(panNumber: string) {
    try {
      const response = await fetch(`${this.baseUrl}/api-setu`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          service: 'pan_verification',
          action: 'verify',
          data: { panNumber }
        })
      });

      return await response.json();
    } catch (error) {
      console.error('PAN verification failed:', error);
      throw error;
    }
  }

  static async verifyDrivingLicense(licenseNumber: string, dob: string) {
    try {
      const response = await fetch(`${this.baseUrl}/api-setu`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          service: 'driving_license',
          action: 'verify',
          data: { licenseNumber, dob }
        })
      });

      return await response.json();
    } catch (error) {
      console.error('Driving license verification failed:', error);
      throw error;
    }
  }
}
```

## Required Environment Variables

Add these secrets to your Blink project:

```env
# API Setu Credentials
API_SETU_CLIENT_ID=your_client_id
API_SETU_CLIENT_SECRET=your_client_secret
API_SETU_TOKEN=your_access_token

# Specific Service Keys
PAN_API_KEY=your_pan_api_key
DRIVING_LICENSE_API_KEY=your_dl_api_key
EPFO_API_KEY=your_epfo_api_key
TRANSPORT_API_KEY=your_transport_api_key
```

## Implementation Priority

### Phase 1: Core Identity Services
1. **PAN Verification** - Most requested feature
2. **Driving License Verification** - High utility
3. **Vehicle Registration** - Transport integration

### Phase 2: Government Services
1. **EPFO Services** - Employment verification
2. **Government Scheme APIs** - Citizen services
3. **Document verification** - Multiple departments

### Phase 3: Utility & Financial
1. **GST Verification** - Business services
2. **Utility Bill APIs** - Bill payment integration
3. **Banking APIs** - Financial services

## Error Handling & Fallbacks

### 1. API Rate Limiting
- Implement exponential backoff
- Cache responses for repeated requests
- Show user-friendly error messages

### 2. Service Unavailability
- Maintain fallback to mock data
- Display service status to users
- Implement retry mechanisms

### 3. Authentication Failures
- Automatic token refresh
- Graceful degradation
- User notification system

## Testing Strategy

### 1. Sandbox Environment
- Use API Setu sandbox: https://sandbox.api-setu.in/
- Test all API integrations
- Validate response formats

### 2. Mock Data Fallbacks
- Maintain current mock responses
- Switch between real and mock data
- A/B testing capabilities

### 3. User Acceptance Testing
- Test with real government documents
- Validate accuracy of responses
- Performance testing under load

## Compliance & Security

### 1. Data Privacy
- Follow API Setu data usage policies
- Implement proper consent mechanisms
- Secure data transmission (HTTPS only)

### 2. Government Compliance
- Adhere to Digital India guidelines
- Follow API Setu terms of service
- Implement proper audit logging

### 3. Security Best Practices
- Store API keys securely
- Implement request signing
- Use proper authentication flows

## Next Steps

1. **Register with API Setu** - Create developer account
2. **Subscribe to Priority APIs** - PAN, DL, Vehicle Registration
3. **Implement Edge Functions** - Secure API integration layer
4. **Update Frontend Services** - Replace mock data with real APIs
5. **Testing & Validation** - Comprehensive testing with real data
6. **User Documentation** - Guide users on new features

## Resources

- **API Setu Directory**: https://directory.apisetu.gov.in/
- **Developer Portal**: https://partners.apisetu.gov.in/
- **Documentation**: https://docs.apisetu.gov.in/
- **Sandbox**: https://sandbox.api-setu.in/
- **Support**: Contact API Setu support team

---

This integration will transform our India Helper app from a prototype to a fully functional government services platform with real-time data and verification capabilities.