// Design System for India Helper App
// Based on the app design blueprint

export const Colors = {
  // Primary Colors
  primary: '#003366',
  primaryLight: '#004080',
  primaryDark: '#002244',
  
  // Accent Colors
  accent: '#00A86B',
  accentLight: '#26C281',
  accentDark: '#008A5A',
  
  // Secondary Colors
  secondary: '#FFD700',
  secondaryLight: '#FFF176',
  secondaryDark: '#FFC107',
  
  // Tertiary Colors
  tertiary: '#9C27B0',
  tertiaryLight: '#BA68C8',
  tertiaryDark: '#7B1FA2',
  
  // Background Colors
  background: '#FAFAFA',
  backgroundLight: '#FFFFFF',
  backgroundDark: '#F5F5F5',
  
  // Surface Colors
  surface: '#FFFFFF',
  surfaceLight: '#F8F9FA',
  surfaceDark: '#E5E5E5',
  
  // Text Colors
  textPrimary: '#003366',
  textSecondary: '#333333',
  textTertiary: '#666666',
  textDisabled: '#999999',
  textOnPrimary: '#FFFFFF',
  textOnAccent: '#FFFFFF',
  
  // Status Colors
  success: '#00A86B',
  successLight: '#26C281',
  warning: '#FF9800',
  warningLight: '#FFB74D',
  error: '#F44336',
  errorLight: '#EF5350',
  info: '#4285F4',
  infoLight: '#5A9BF8',
  
  // Transport Colors
  train: '#4285F4',
  trainLight: '#5A9BF8',
  bus: '#00A86B',
  busLight: '#26C281',
  flight: '#FF6B35',
  flightLight: '#FF8A65',
  taxi: '#9C27B0',
  taxiLight: '#BA68C8',
  
  // Utility Colors
  border: '#E5E5E5',
  borderLight: '#F0F0F0',
  borderDark: '#CCCCCC',
  shadow: '#000000',
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
  
  // Gradient Colors
  gradients: {
    primary: ['#003366', '#004080'],
    accent: ['#00A86B', '#26C281'],
    secondary: ['#FFD700', '#FFF176'],
    tertiary: ['#9C27B0', '#BA68C8'],
    train: ['#4285F4', '#5A9BF8'],
    bus: ['#00A86B', '#26C281'],
    flight: ['#FF6B35', '#FF8A65'],
    taxi: ['#9C27B0', '#BA68C8'],
    emergency: ['#F44336', '#EF5350'],
    success: ['#00A86B', '#26C281'],
    warning: ['#FF9800', '#FFB74D'],
    error: ['#F44336', '#EF5350'],
    info: ['#4285F4', '#5A9BF8'],
  },
};

export const Typography = {
  // Font Families
  fontFamily: {
    regular: 'Inter',
    medium: 'Inter Medium',
    bold: 'Inter Bold',
  },
  
  // Font Sizes
  fontSize: {
    xs: 10,
    sm: 12,
    base: 14,
    lg: 16,
    xl: 18,
    '2xl': 20,
    '3xl': 24,
    '4xl': 28,
    '5xl': 32,
    '6xl': 36,
  },
  
  // Font Weights
  fontWeight: {
    normal: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
  
  // Line Heights
  lineHeight: {
    tight: 1.2,
    normal: 1.4,
    relaxed: 1.6,
    loose: 1.8,
  },
  
  // Text Styles
  styles: {
    // Headers
    h1: {
      fontSize: 32,
      fontWeight: '700',
      lineHeight: 38,
      color: Colors.textPrimary,
    },
    h2: {
      fontSize: 28,
      fontWeight: '700',
      lineHeight: 34,
      color: Colors.textPrimary,
    },
    h3: {
      fontSize: 24,
      fontWeight: '600',
      lineHeight: 30,
      color: Colors.textPrimary,
    },
    h4: {
      fontSize: 20,
      fontWeight: '600',
      lineHeight: 26,
      color: Colors.textPrimary,
    },
    h5: {
      fontSize: 18,
      fontWeight: '600',
      lineHeight: 24,
      color: Colors.textPrimary,
    },
    h6: {
      fontSize: 16,
      fontWeight: '600',
      lineHeight: 22,
      color: Colors.textPrimary,
    },
    
    // Body Text
    bodyLarge: {
      fontSize: 16,
      fontWeight: '400',
      lineHeight: 24,
      color: Colors.textSecondary,
    },
    body: {
      fontSize: 14,
      fontWeight: '400',
      lineHeight: 20,
      color: Colors.textSecondary,
    },
    bodySmall: {
      fontSize: 12,
      fontWeight: '400',
      lineHeight: 18,
      color: Colors.textTertiary,
    },
    
    // Labels
    labelLarge: {
      fontSize: 14,
      fontWeight: '600',
      lineHeight: 20,
      color: Colors.textSecondary,
    },
    label: {
      fontSize: 12,
      fontWeight: '600',
      lineHeight: 16,
      color: Colors.textSecondary,
    },
    labelSmall: {
      fontSize: 10,
      fontWeight: '600',
      lineHeight: 14,
      color: Colors.textTertiary,
    },
    
    // Buttons
    buttonLarge: {
      fontSize: 16,
      fontWeight: '600',
      lineHeight: 20,
      color: Colors.textOnPrimary,
    },
    button: {
      fontSize: 14,
      fontWeight: '600',
      lineHeight: 18,
      color: Colors.textOnPrimary,
    },
    buttonSmall: {
      fontSize: 12,
      fontWeight: '600',
      lineHeight: 16,
      color: Colors.textOnPrimary,
    },
    
    // Captions
    caption: {
      fontSize: 12,
      fontWeight: '400',
      lineHeight: 16,
      color: Colors.textTertiary,
    },
    captionSmall: {
      fontSize: 10,
      fontWeight: '400',
      lineHeight: 14,
      color: Colors.textDisabled,
    },
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  '2xl': 24,
  '3xl': 32,
  '4xl': 40,
  '5xl': 48,
  '6xl': 64,
  '7xl': 80,
  '8xl': 96,
};

export const BorderRadius = {
  none: 0,
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  '2xl': 20,
  '3xl': 24,
  '4xl': 28,
  full: 9999,
};

export const Shadows = {
  none: {
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0,
    shadowRadius: 0,
    elevation: 0,
  },
  sm: {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  md: {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  xl: {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  '2xl': {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
  },
};

export const Layout = {
  // Screen padding
  screenPadding: Spacing.xl,
  
  // Section spacing
  sectionSpacing: Spacing['2xl'],
  
  // Card padding
  cardPadding: Spacing.xl,
  cardPaddingSmall: Spacing.lg,
  
  // Button padding
  buttonPadding: {
    horizontal: Spacing.xl,
    vertical: Spacing.lg,
  },
  buttonPaddingSmall: {
    horizontal: Spacing.lg,
    vertical: Spacing.md,
  },
  
  // Input padding
  inputPadding: {
    horizontal: Spacing.lg,
    vertical: Spacing.md,
  },
  
  // Icon sizes
  iconSize: {
    xs: 12,
    sm: 16,
    md: 20,
    lg: 24,
    xl: 28,
    '2xl': 32,
    '3xl': 40,
    '4xl': 48,
    '5xl': 56,
    '6xl': 64,
  },
  
  // Avatar sizes
  avatarSize: {
    xs: 24,
    sm: 32,
    md: 40,
    lg: 48,
    xl: 56,
    '2xl': 64,
    '3xl': 80,
    '4xl': 96,
  },
};

export const Animation = {
  // Duration
  duration: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
  
  // Easing
  easing: {
    linear: 'linear',
    ease: 'ease',
    easeIn: 'ease-in',
    easeOut: 'ease-out',
    easeInOut: 'ease-in-out',
  },
};

// Component-specific styles
export const ComponentStyles = {
  card: {
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.xl,
    padding: Layout.cardPadding,
    ...Shadows.md,
  },
  
  cardSmall: {
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Layout.cardPaddingSmall,
    ...Shadows.sm,
  },
  
  button: {
    borderRadius: BorderRadius['2xl'],
    paddingHorizontal: Layout.buttonPadding.horizontal,
    paddingVertical: Layout.buttonPadding.vertical,
    ...Shadows.sm,
  },
  
  buttonSmall: {
    borderRadius: BorderRadius.xl,
    paddingHorizontal: Layout.buttonPaddingSmall.horizontal,
    paddingVertical: Layout.buttonPaddingSmall.vertical,
  },
  
  input: {
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Layout.inputPadding.horizontal,
    paddingVertical: Layout.inputPadding.vertical,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  
  modal: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: BorderRadius['2xl'],
    borderTopRightRadius: BorderRadius['2xl'],
    ...Shadows.xl,
  },
  
  header: {
    paddingHorizontal: Layout.screenPadding,
    paddingVertical: Spacing['2xl'],
    borderBottomLeftRadius: BorderRadius['2xl'],
    borderBottomRightRadius: BorderRadius['2xl'],
  },
  
  section: {
    paddingHorizontal: Layout.screenPadding,
    paddingVertical: Layout.sectionSpacing,
  },
};