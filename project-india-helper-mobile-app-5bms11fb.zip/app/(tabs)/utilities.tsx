import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Zap,
  Droplets,
  Flame,
  Smartphone,
  Wifi,
  Tv,
  CreditCard,
  Clock,
  CheckCircle,
  AlertTriangle,
  Plus,
  Car,
  Fuel,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { blink } from '@/lib/blink';
import BillManager from '@/components/BillManager';
import UtilityServices from '@/components/UtilityServices';
import DatabaseTest from '@/components/DatabaseTest';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function UtilitiesScreen() {
  const { user, isAuthenticated, login } = useAuth();
  const [refreshKey, setRefreshKey] = useState(0);
  const [activeTab, setActiveTab] = useState<'bills' | 'services' | 'test'>('bills');

  const handleBillAdded = () => {
    setRefreshKey(prev => prev + 1);
  };

  const handleBillPaid = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#00A86B', '#00C878']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold', textAlign: 'center' }}>
          Utility Services
        </Text>
        <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, textAlign: 'center', marginTop: 5 }}>
          Check bills, pay utilities, and get provider info
        </Text>
        
        {/* Tab Navigation */}
        <View style={{ 
          flexDirection: 'row', 
          marginTop: 20, 
          backgroundColor: 'rgba(255,255,255,0.2)', 
          borderRadius: 25, 
          padding: 4 
        }}>
          <TouchableOpacity
            onPress={() => setActiveTab('bills')}
            style={{
              flex: 1,
              paddingVertical: 10,
              borderRadius: 20,
              backgroundColor: activeTab === 'bills' ? 'white' : 'transparent',
            }}
          >
            <Text style={{
              textAlign: 'center',
              fontWeight: '600',
              color: activeTab === 'bills' ? '#00A86B' : 'white',
              fontSize: 12,
            }}>
              My Bills
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setActiveTab('services')}
            style={{
              flex: 1,
              paddingVertical: 10,
              borderRadius: 20,
              backgroundColor: activeTab === 'services' ? 'white' : 'transparent',
            }}
          >
            <Text style={{
              textAlign: 'center',
              fontWeight: '600',
              color: activeTab === 'services' ? '#00A86B' : 'white',
              fontSize: 12,
            }}>
              Services
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setActiveTab('test')}
            style={{
              flex: 1,
              paddingVertical: 10,
              borderRadius: 20,
              backgroundColor: activeTab === 'test' ? 'white' : 'transparent',
            }}
          >
            <Text style={{
              textAlign: 'center',
              fontWeight: '600',
              color: activeTab === 'test' ? '#00A86B' : 'white',
              fontSize: 12,
            }}>
              Test
            </Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {activeTab === 'bills' ? (
        isAuthenticated ? (
          <BillManager 
            key={refreshKey}
            onBillAdded={handleBillAdded}
            onBillPaid={handleBillPaid}
          />
        ) : (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View
            style={{
              backgroundColor: 'white',
              borderRadius: 15,
              padding: 30,
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
              width: '100%',
            }}
          >
            <CreditCard size={48} color="#00A86B" />
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#003366', marginTop: 15, marginBottom: 10 }}>
              Sign In to Manage Bills
            </Text>
            <Text style={{ fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 25 }}>
              Add your utility bills, set payment reminders, and pay securely all in one place
            </Text>
            <TouchableOpacity
              onPress={() => login()}
              style={{
                backgroundColor: '#00A86B',
                paddingHorizontal: 40,
                paddingVertical: 15,
                borderRadius: 25,
              }}
            >
              <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                Sign In Now
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        )
      ) : activeTab === 'services' ? (
        <UtilityServices />
      ) : (
        <DatabaseTest />
      )}
    </SafeAreaView>
  );
}