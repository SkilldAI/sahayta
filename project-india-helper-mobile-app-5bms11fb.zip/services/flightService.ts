export interface FlightInfo {
  flightNumber: string;
  airline: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  status: string;
  gate?: string;
  terminal?: string;
  delay?: string;
}

export interface FlightSearchResult {
  flightNumber: string;
  airline: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  stops: number;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class FlightService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=flight&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Flight Service Error (${action}):`, error);
      throw error;
    }
  }

  async getFlightStatus(flightNumber: string, date?: string): Promise<FlightInfo> {
    if (!flightNumber) {
      throw new Error('Flight number is required');
    }

    return await this.makeRequest('status', { flightNumber, date });
  }

  async searchFlights(
    from: string, 
    to: string, 
    date: string, 
    returnDate?: string
  ): Promise<FlightSearchResult[]> {
    if (!from || !to || !date) {
      throw new Error('From, to, and date are required');
    }

    return await this.makeRequest('search', { from, to, date, returnDate });
  }

  // Utility methods
  validateFlightNumber(flightNumber: string): boolean {
    // Flight number format: 2-3 letter airline code + 3-4 digit number
    return /^[A-Z]{2,3}[-\s]?\d{3,4}$/i.test(flightNumber);
  }

  validateAirportCode(code: string): boolean {
    // IATA airport codes are 3 letters
    return /^[A-Z]{3}$/i.test(code);
  }

  validateDate(date: string): boolean {
    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return selectedDate >= today;
  }

  formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  // Major Indian airports
  getMajorAirports(): Array<{ code: string; name: string; city: string; state: string }> {
    return [
      { code: "DEL", name: "Indira Gandhi International Airport", city: "New Delhi", state: "Delhi" },
      { code: "BOM", name: "Chhatrapati Shivaji Maharaj International Airport", city: "Mumbai", state: "Maharashtra" },
      { code: "BLR", name: "Kempegowda International Airport", city: "Bangalore", state: "Karnataka" },
      { code: "MAA", name: "Chennai International Airport", city: "Chennai", state: "Tamil Nadu" },
      { code: "CCU", name: "Netaji Subhash Chandra Bose International Airport", city: "Kolkata", state: "West Bengal" },
      { code: "HYD", name: "Rajiv Gandhi International Airport", city: "Hyderabad", state: "Telangana" },
      { code: "AMD", name: "Sardar Vallabhbhai Patel International Airport", city: "Ahmedabad", state: "Gujarat" },
      { code: "PNQ", name: "Pune Airport", city: "Pune", state: "Maharashtra" },
      { code: "GOI", name: "Goa International Airport", city: "Goa", state: "Goa" },
      { code: "COK", name: "Cochin International Airport", city: "Kochi", state: "Kerala" },
      { code: "JAI", name: "Jaipur International Airport", city: "Jaipur", state: "Rajasthan" },
      { code: "LKO", name: "Chaudhary Charan Singh International Airport", city: "Lucknow", state: "Uttar Pradesh" },
      { code: "IXC", name: "Chandigarh Airport", city: "Chandigarh", state: "Chandigarh" },
      { code: "GAU", name: "Lokpriya Gopinath Bordoloi International Airport", city: "Guwahati", state: "Assam" },
      { code: "TRV", name: "Trivandrum International Airport", city: "Thiruvananthapuram", state: "Kerala" }
    ];
  }

  // Major Indian airlines
  getIndianAirlines(): Array<{ code: string; name: string; type: string; hub: string }> {
    return [
      { code: "6E", name: "IndiGo", type: "Low Cost", hub: "Delhi, Mumbai" },
      { code: "AI", name: "Air India", type: "Full Service", hub: "Delhi, Mumbai" },
      { code: "SG", name: "SpiceJet", type: "Low Cost", hub: "Delhi, Mumbai" },
      { code: "UK", name: "Vistara", type: "Full Service", hub: "Delhi" },
      { code: "G8", name: "GoAir", type: "Low Cost", hub: "Mumbai" },
      { code: "IX", name: "Air India Express", type: "Low Cost", hub: "Kochi, Bangalore" },
      { code: "I5", name: "AirAsia India", type: "Low Cost", hub: "Bangalore" },
      { code: "2T", name: "Trujet", type: "Regional", hub: "Hyderabad" }
    ];
  }

  // Popular domestic routes
  getPopularRoutes(): Array<{ from: string; to: string; duration: string; frequency: string }> {
    return [
      { from: "DEL", to: "BOM", duration: "2h 15m", frequency: "50+ daily" },
      { from: "DEL", to: "BLR", duration: "2h 45m", frequency: "40+ daily" },
      { from: "BOM", to: "BLR", duration: "1h 30m", frequency: "35+ daily" },
      { from: "DEL", to: "MAA", duration: "2h 30m", frequency: "25+ daily" },
      { from: "BOM", to: "MAA", duration: "1h 45m", frequency: "20+ daily" },
      { from: "DEL", to: "CCU", duration: "2h 10m", frequency: "15+ daily" },
      { from: "BOM", to: "GOI", duration: "1h 15m", frequency: "10+ daily" },
      { from: "BLR", to: "MAA", duration: "1h 10m", frequency: "15+ daily" },
      { from: "DEL", to: "AMD", duration: "1h 30m", frequency: "12+ daily" },
      { from: "BOM", to: "PNQ", duration: "45m", frequency: "8+ daily" }
    ];
  }

  // Flight status meanings
  getFlightStatusMeanings(): Array<{ status: string; meaning: string; color: string }> {
    return [
      { status: "On Time", meaning: "Flight is scheduled to depart/arrive as planned", color: "#00A86B" },
      { status: "Delayed", meaning: "Flight departure/arrival is delayed", color: "#FF9800" },
      { status: "Cancelled", meaning: "Flight has been cancelled", color: "#F44336" },
      { status: "Boarding", meaning: "Passengers are boarding the aircraft", color: "#2196F3" },
      { status: "Departed", meaning: "Flight has left the departure airport", color: "#9C27B0" },
      { status: "In Air", meaning: "Flight is currently airborne", color: "#607D8B" },
      { status: "Landed", meaning: "Flight has arrived at destination", color: "#4CAF50" },
      { status: "Gate Change", meaning: "Departure gate has been changed", color: "#FF5722" },
      { status: "Check-in", meaning: "Check-in is open for this flight", color: "#795548" },
      { status: "Final Call", meaning: "Last call for boarding", color: "#E91E63" }
    ];
  }

  // Travel tips
  getTravelTips(): string[] {
    return [
      "Arrive at airport 2 hours early for domestic flights",
      "Check-in online to save time at the airport",
      "Keep ID proof and boarding pass ready",
      "Check baggage allowance before packing",
      "Download airline app for real-time updates",
      "Consider travel insurance for protection",
      "Keep emergency contacts handy",
      "Charge your devices before travel",
      "Carry essential medicines in hand baggage",
      "Check weather conditions at destination",
      "Keep digital copies of important documents",
      "Follow airline's COVID-19 guidelines"
    ];
  }

  // Booking tips
  getBookingTips(): string[] {
    return [
      "Book flights 2-8 weeks in advance for best prices",
      "Compare prices across multiple platforms",
      "Be flexible with dates for better deals",
      "Consider nearby airports for cheaper options",
      "Clear browser cookies before booking",
      "Book round-trip tickets for better rates",
      "Avoid booking on weekends when prices are higher",
      "Sign up for airline newsletters for deals",
      "Use incognito mode while searching",
      "Consider budget airlines for short routes"
    ];
  }
}

// Export singleton instance
export const flightService = new FlightService();