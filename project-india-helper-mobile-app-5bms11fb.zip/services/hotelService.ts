export interface HotelSearchResult {
  hotelId: string;
  name: string;
  location: string;
  rating: number;
  pricePerNight: number;
  currency: string;
  amenities: string[];
  images: string[];
  description: string;
  availability: boolean;
  roomTypes: RoomType[];
  distance?: string;
  landmark?: string;
}

export interface RoomType {
  type: string;
  price: number;
  capacity: number;
  amenities: string[];
  availability: number;
}

export interface HotelBooking {
  bookingId: string;
  hotelId: string;
  hotelName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  rooms: number;
  totalAmount: number;
  status: 'confirmed' | 'pending' | 'cancelled';
  bookingDate: string;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class HotelService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=hotel&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Hotel Service Error (${action}):`, error);
      throw error;
    }
  }

  async searchHotels(
    location: string,
    checkIn: string,
    checkOut: string,
    guests: number = 2,
    rooms: number = 1
  ): Promise<HotelSearchResult[]> {
    if (!location || !checkIn || !checkOut) {
      throw new Error('Location, check-in, and check-out dates are required');
    }

    return await this.makeRequest('search', {
      location,
      checkIn,
      checkOut,
      guests,
      rooms,
    });
  }

  async getHotelDetails(hotelId: string): Promise<HotelSearchResult> {
    if (!hotelId) {
      throw new Error('Hotel ID is required');
    }

    return await this.makeRequest('details', { hotelId });
  }

  // Utility methods
  validateDates(checkIn: string, checkOut: string): boolean {
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return checkInDate >= today && checkOutDate > checkInDate;
  }

  calculateNights(checkIn: string, checkOut: string): number {
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const diffTime = checkOutDate.getTime() - checkInDate.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  // Popular destinations in India
  getPopularDestinations(): Array<{
    name: string;
    state: string;
    type: string;
    description: string;
    bestTime: string;
  }> {
    return [
      {
        name: 'Goa',
        state: 'Goa',
        type: 'Beach',
        description: 'Beautiful beaches, Portuguese architecture, vibrant nightlife',
        bestTime: 'November to March'
      },
      {
        name: 'Manali',
        state: 'Himachal Pradesh',
        type: 'Hill Station',
        description: 'Snow-capped mountains, adventure sports, scenic valleys',
        bestTime: 'March to June, October to February'
      },
      {
        name: 'Jaipur',
        state: 'Rajasthan',
        type: 'Heritage',
        description: 'Pink City, royal palaces, rich culture and history',
        bestTime: 'October to March'
      },
      {
        name: 'Kerala Backwaters',
        state: 'Kerala',
        type: 'Nature',
        description: 'Serene backwaters, houseboats, lush greenery',
        bestTime: 'September to March'
      },
      {
        name: 'Agra',
        state: 'Uttar Pradesh',
        type: 'Heritage',
        description: 'Taj Mahal, Mughal architecture, historical monuments',
        bestTime: 'October to March'
      },
      {
        name: 'Rishikesh',
        state: 'Uttarakhand',
        type: 'Spiritual/Adventure',
        description: 'Yoga capital, river rafting, spiritual retreats',
        bestTime: 'February to May, September to November'
      },
      {
        name: 'Udaipur',
        state: 'Rajasthan',
        type: 'Heritage',
        description: 'City of Lakes, royal palaces, romantic ambiance',
        bestTime: 'September to March'
      },
      {
        name: 'Shimla',
        state: 'Himachal Pradesh',
        type: 'Hill Station',
        description: 'Colonial architecture, toy train, pleasant weather',
        bestTime: 'March to June, December to January'
      },
      {
        name: 'Mysore',
        state: 'Karnataka',
        type: 'Heritage',
        description: 'Royal palace, silk sarees, Dasara festival',
        bestTime: 'October to March'
      },
      {
        name: 'Darjeeling',
        state: 'West Bengal',
        type: 'Hill Station',
        description: 'Tea gardens, toy train, Himalayan views',
        bestTime: 'April to June, September to November'
      }
    ];
  }

  // Hotel categories and their typical amenities
  getHotelCategories(): Array<{
    category: string;
    stars: number;
    priceRange: string;
    amenities: string[];
    description: string;
  }> {
    return [
      {
        category: 'Budget',
        stars: 1,
        priceRange: '₹500-1500',
        amenities: ['Basic Room', 'Attached Bathroom', 'Fan/AC', 'Room Service'],
        description: 'Basic accommodation with essential amenities'
      },
      {
        category: 'Economy',
        stars: 2,
        priceRange: '₹1500-3000',
        amenities: ['AC Room', 'TV', 'WiFi', 'Restaurant', 'Room Service'],
        description: 'Comfortable stay with standard amenities'
      },
      {
        category: 'Mid-Range',
        stars: 3,
        priceRange: '₹3000-6000',
        amenities: ['AC Room', 'TV', 'WiFi', 'Restaurant', 'Gym', 'Swimming Pool'],
        description: 'Good quality accommodation with additional facilities'
      },
      {
        category: 'Premium',
        stars: 4,
        priceRange: '₹6000-12000',
        amenities: ['Luxury Room', 'Multiple Restaurants', 'Spa', 'Gym', 'Pool', 'Concierge'],
        description: 'High-end accommodation with luxury amenities'
      },
      {
        category: 'Luxury',
        stars: 5,
        priceRange: '₹12000+',
        amenities: ['Suite Rooms', 'Fine Dining', 'Spa', 'Butler Service', 'Premium Facilities'],
        description: 'Ultra-luxury accommodation with world-class amenities'
      }
    ];
  }

  // Popular hotel chains in India
  getPopularHotelChains(): Array<{
    name: string;
    category: string;
    presence: string[];
    speciality: string;
  }> {
    return [
      {
        name: 'Taj Hotels',
        category: 'Luxury',
        presence: ['Major Cities', 'Tourist Destinations'],
        speciality: 'Heritage luxury and world-class hospitality'
      },
      {
        name: 'ITC Hotels',
        category: 'Luxury',
        presence: ['Metro Cities', 'Business Centers'],
        speciality: 'Sustainable luxury and fine dining'
      },
      {
        name: 'Oberoi Hotels',
        category: 'Luxury',
        presence: ['Premium Locations'],
        speciality: 'Personalized service and elegant ambiance'
      },
      {
        name: 'Marriott',
        category: 'Premium',
        presence: ['Major Cities'],
        speciality: 'International standards and business facilities'
      },
      {
        name: 'Hyatt',
        category: 'Premium',
        presence: ['Metro Cities'],
        speciality: 'Modern amenities and excellent service'
      },
      {
        name: 'Lemon Tree Hotels',
        category: 'Mid-Range',
        presence: ['Tier 1 & 2 Cities'],
        speciality: 'Fresh and vibrant hospitality'
      },
      {
        name: 'Ginger Hotels',
        category: 'Economy',
        presence: ['Pan India'],
        speciality: 'Smart basics and efficient service'
      },
      {
        name: 'OYO',
        category: 'Budget-Economy',
        presence: ['Pan India'],
        speciality: 'Standardized budget accommodation'
      },
      {
        name: 'Treebo',
        category: 'Budget-Economy',
        presence: ['Major Cities'],
        speciality: 'Quality assured budget stays'
      },
      {
        name: 'FabHotels',
        category: 'Budget-Economy',
        presence: ['Metro Cities'],
        speciality: 'Comfortable and affordable stays'
      }
    ];
  }

  // Booking tips for hotels
  getBookingTips(): string[] {
    return [
      'Book in advance for better rates and availability',
      'Compare prices across multiple platforms',
      'Read recent guest reviews and ratings',
      'Check cancellation policy before booking',
      'Verify hotel location and nearby attractions',
      'Look for package deals including meals',
      'Check for hidden charges and taxes',
      'Consider booking directly with hotel for perks',
      'Use loyalty programs for additional benefits',
      'Book refundable rates for flexibility',
      'Check-in and check-out times',
      'Verify amenities and facilities included'
    ];
  }

  // Travel seasons and pricing
  getTravelSeasons(): Array<{
    season: string;
    months: string;
    pricing: string;
    characteristics: string[];
  }> {
    return [
      {
        season: 'Peak Season',
        months: 'December - February',
        pricing: 'Highest rates',
        characteristics: ['Pleasant weather', 'High demand', 'Festivals', 'Best time to visit']
      },
      {
        season: 'Shoulder Season',
        months: 'March - May, September - November',
        pricing: 'Moderate rates',
        characteristics: ['Good weather', 'Moderate crowds', 'Better availability']
      },
      {
        season: 'Off Season',
        months: 'June - August',
        pricing: 'Lowest rates',
        characteristics: ['Monsoon season', 'Lower demand', 'Great deals', 'Lush greenery']
      }
    ];
  }

  // Room types and their features
  getRoomTypes(): Array<{
    type: string;
    capacity: string;
    features: string[];
    suitableFor: string;
  }> {
    return [
      {
        type: 'Standard Room',
        capacity: '1-2 guests',
        features: ['Queen/Twin bed', 'Basic amenities', 'Ensuite bathroom'],
        suitableFor: 'Solo travelers, couples'
      },
      {
        type: 'Deluxe Room',
        capacity: '2-3 guests',
        features: ['King bed', 'Better view', 'Premium amenities', 'Seating area'],
        suitableFor: 'Couples, small families'
      },
      {
        type: 'Suite',
        capacity: '2-4 guests',
        features: ['Separate living area', 'Premium location', 'Enhanced amenities'],
        suitableFor: 'Families, business travelers'
      },
      {
        type: 'Family Room',
        capacity: '4-6 guests',
        features: ['Multiple beds', 'Extra space', 'Family-friendly amenities'],
        suitableFor: 'Large families, groups'
      },
      {
        type: 'Presidential Suite',
        capacity: '4-8 guests',
        features: ['Multiple rooms', 'Luxury amenities', 'Butler service', 'Premium location'],
        suitableFor: 'VIP guests, special occasions'
      }
    ];
  }

  // Hotel amenities and their importance
  getAmenityCategories(): Array<{
    category: string;
    amenities: Array<{ name: string; importance: string; description: string }>;
  }> {
    return [
      {
        category: 'Essential',
        amenities: [
          { name: 'WiFi', importance: 'High', description: 'Internet connectivity for work and communication' },
          { name: 'Air Conditioning', importance: 'High', description: 'Climate control for comfort' },
          { name: 'Room Service', importance: 'Medium', description: 'In-room dining and assistance' },
          { name: 'Housekeeping', importance: 'High', description: 'Daily cleaning and maintenance' }
        ]
      },
      {
        category: 'Dining',
        amenities: [
          { name: 'Restaurant', importance: 'High', description: 'On-site dining options' },
          { name: 'Bar/Lounge', importance: 'Medium', description: 'Beverages and social space' },
          { name: 'Breakfast', importance: 'High', description: 'Complimentary or paid breakfast service' },
          { name: 'Mini Bar', importance: 'Low', description: 'In-room refreshments' }
        ]
      },
      {
        category: 'Recreation',
        amenities: [
          { name: 'Swimming Pool', importance: 'Medium', description: 'Relaxation and exercise facility' },
          { name: 'Fitness Center', importance: 'Medium', description: 'Exercise equipment and facilities' },
          { name: 'Spa', importance: 'Low', description: 'Wellness and relaxation treatments' },
          { name: 'Game Room', importance: 'Low', description: 'Entertainment and recreation' }
        ]
      },
      {
        category: 'Business',
        amenities: [
          { name: 'Business Center', importance: 'Medium', description: 'Office facilities and services' },
          { name: 'Meeting Rooms', importance: 'Medium', description: 'Conference and meeting facilities' },
          { name: 'Concierge', importance: 'Medium', description: 'Guest assistance and local information' },
          { name: 'Laundry Service', importance: 'Medium', description: 'Clothing cleaning and pressing' }
        ]
      }
    ];
  }
}

// Export singleton instance
export const hotelService = new HotelService();