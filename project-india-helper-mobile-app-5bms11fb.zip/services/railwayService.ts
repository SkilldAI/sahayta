export interface PNRStatus {
  pnrNumber: string;
  trainNumber: string;
  trainName: string;
  dateOfJourney: string;
  from: string;
  to: string;
  boardingPoint: string;
  reservationUpto: string;
  passengers: Array<{
    passengerNumber: number;
    bookingStatus: string;
    currentStatus: string;
    coach: string;
    berth: string;
  }>;
  chartStatus: string;
  distance: string;
  quota: string;
}

export interface TrainSchedule {
  trainNumber: string;
  trainName: string;
  stations: Array<{
    stationCode: string;
    stationName: string;
    arrivalTime: string;
    departureTime: string;
    haltTime: string;
    distance: string;
    day: number;
  }>;
}

export interface SeatAvailability {
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  date: string;
  classes: Array<{
    className: string;
    classCode: string;
    availability: string;
    fare: string;
  }>;
}

export interface TrainSearchResult {
  trainNumber: string;
  trainName: string;
  fromStation: string;
  toStation: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  runsOn: string[];
  classes: string[];
}

const IRCTC_SCRAPER_URL = 'https://5bms11fb--irctc-scraper.functions.blink.new';

export class RailwayService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${IRCTC_SCRAPER_URL}?action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Request failed');
      }

      return await response.json();
    } catch (error) {
      console.error(`Railway Service Error (${action}):`, error);
      throw error;
    }
  }

  async getPNRStatus(pnrNumber: string): Promise<PNRStatus> {
    if (!pnrNumber || pnrNumber.length !== 10) {
      throw new Error('PNR number must be exactly 10 digits');
    }

    return await this.makeRequest('pnr-status', { pnrNumber });
  }

  async getTrainSchedule(trainNumber: string): Promise<TrainSchedule> {
    if (!trainNumber) {
      throw new Error('Train number is required');
    }

    return await this.makeRequest('train-schedule', { trainNumber });
  }

  async getSeatAvailability(
    trainNumber: string,
    from: string,
    to: string,
    date: string,
    classType?: string
  ): Promise<SeatAvailability> {
    if (!trainNumber || !from || !to || !date) {
      throw new Error('Train number, from, to, and date are required');
    }

    return await this.makeRequest('seat-availability', {
      trainNumber,
      from,
      to,
      date,
      classType,
    });
  }

  async searchTrains(
    from: string,
    to: string,
    date: string
  ): Promise<TrainSearchResult[]> {
    if (!from || !to || !date) {
      throw new Error('From, to, and date are required');
    }

    const result = await this.makeRequest('train-search', {
      from,
      to,
      date,
    });

    // Transform the response to match our interface
    return result.trainBtwnStnsList?.map((train: any) => ({
      trainNumber: train.trainNumber || '',
      trainName: train.trainName || '',
      fromStation: train.fromStnCode || from,
      toStation: train.toStnCode || to,
      departureTime: train.departureTime || '',
      arrivalTime: train.arrivalTime || '',
      duration: train.duration || '',
      runsOn: train.runsOn || [],
      classes: train.avlClasses || [],
    })) || [];
  }

  // Utility methods
  validatePNR(pnr: string): boolean {
    return /^\d{10}$/.test(pnr);
  }

  validateTrainNumber(trainNumber: string): boolean {
    return /^\d{5}$/.test(trainNumber);
  }

  validateStationCode(stationCode: string): boolean {
    return /^[A-Z]{2,5}$/.test(stationCode);
  }

  formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  // Common Indian railway station codes
  getPopularStations(): Array<{ code: string; name: string; city: string }> {
    return [
      { code: 'NDLS', name: 'New Delhi', city: 'Delhi' },
      { code: 'BCT', name: 'Mumbai Central', city: 'Mumbai' },
      { code: 'HWH', name: 'Howrah Junction', city: 'Kolkata' },
      { code: 'MAS', name: 'Chennai Central', city: 'Chennai' },
      { code: 'SBC', name: 'Bangalore City', city: 'Bangalore' },
      { code: 'PUNE', name: 'Pune Junction', city: 'Pune' },
      { code: 'ADI', name: 'Ahmedabad Junction', city: 'Ahmedabad' },
      { code: 'JP', name: 'Jaipur Junction', city: 'Jaipur' },
      { code: 'LKO', name: 'Lucknow', city: 'Lucknow' },
      { code: 'BBS', name: 'Bhubaneswar', city: 'Bhubaneswar' },
      { code: 'HYB', name: 'Hyderabad Deccan', city: 'Hyderabad' },
      { code: 'TVC', name: 'Trivandrum Central', city: 'Thiruvananthapuram' },
      { code: 'GHY', name: 'Guwahati', city: 'Guwahati' },
      { code: 'JAT', name: 'Jammu Tawi', city: 'Jammu' },
      { code: 'VSKP', name: 'Visakhapatnam', city: 'Visakhapatnam' },
    ];
  }

  // Train class information
  getTrainClasses(): Array<{ code: string; name: string; description: string }> {
    return [
      { code: '1A', name: 'First AC', description: 'Air Conditioned First Class' },
      { code: '2A', name: 'Second AC', description: 'Air Conditioned 2 Tier' },
      { code: '3A', name: 'Third AC', description: 'Air Conditioned 3 Tier' },
      { code: 'CC', name: 'AC Chair Car', description: 'Air Conditioned Chair Car' },
      { code: 'EC', name: 'Executive Chair Car', description: 'Executive Class' },
      { code: 'SL', name: 'Sleeper', description: 'Sleeper Class' },
      { code: '2S', name: 'Second Sitting', description: 'Second Class Sitting' },
      { code: 'GN', name: 'General', description: 'General/Unreserved' },
    ];
  }
}

// Export singleton instance
export const railwayService = new RailwayService();