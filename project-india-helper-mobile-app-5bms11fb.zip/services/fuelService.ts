export interface FuelPrice {
  fuelType: 'Petrol' | 'Diesel' | 'CNG' | 'LPG';
  price: number;
  currency: string;
  city: string;
  state: string;
  lastUpdated: string;
  priceChange: {
    amount: number;
    direction: 'up' | 'down' | 'same';
    date: string;
  };
}

export interface PetrolPump {
  id: string;
  name: string;
  brand: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  facilities: string[];
  operatingHours: string;
  contactNumber?: string;
  fuelTypes: string[];
  services: string[];
  rating: number;
  isOpen24Hours: boolean;
}

export interface FuelConsumptionTip {
  category: string;
  tips: Array<{
    tip: string;
    savings: string;
    difficulty: 'Easy' | 'Medium' | 'Hard';
  }>;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class FuelService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=fuel&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Fuel Service Error (${action}):`, error);
      throw error;
    }
  }

  async getFuelPrices(city: string, state?: string): Promise<FuelPrice[]> {
    if (!city) {
      throw new Error('City is required');
    }

    return await this.makeRequest('prices', { city, state });
  }

  async getNearbyPetrolPumps(
    latitude: number,
    longitude: number,
    radius: number = 5
  ): Promise<PetrolPump[]> {
    if (!latitude || !longitude) {
      throw new Error('Latitude and longitude are required');
    }

    return await this.makeRequest('nearby-pumps', { latitude, longitude, radius });
  }

  async searchPetrolPumps(location: string, brand?: string): Promise<PetrolPump[]> {
    if (!location) {
      throw new Error('Location is required');
    }

    return await this.makeRequest('search-pumps', { location, brand });
  }

  async getPriceHistory(city: string, fuelType: string, days: number = 30): Promise<Array<{
    date: string;
    price: number;
  }>> {
    if (!city || !fuelType) {
      throw new Error('City and fuel type are required');
    }

    return await this.makeRequest('price-history', { city, fuelType, days });
  }

  // Utility methods
  formatPrice(price: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 2
    }).format(price);
  }

  calculateFuelCost(distance: number, mileage: number, pricePerLiter: number): number {
    const litersNeeded = distance / mileage;
    return litersNeeded * pricePerLiter;
  }

  calculateMonthlyCost(dailyDistance: number, mileage: number, pricePerLiter: number): number {
    const monthlyDistance = dailyDistance * 30;
    return this.calculateFuelCost(monthlyDistance, mileage, pricePerLiter);
  }

  // Major fuel brands in India
  getFuelBrands(): Array<{
    name: string;
    fullName: string;
    type: 'Public' | 'Private';
    marketShare: string;
    specialFeatures: string[];
  }> {
    return [
      {
        name: 'IOCL',
        fullName: 'Indian Oil Corporation Limited',
        type: 'Public',
        marketShare: '~45%',
        specialFeatures: ['Servo Fuels', 'XtraGreen', 'XtraPremium', 'Loyalty Program']
      },
      {
        name: 'HPCL',
        fullName: 'Hindustan Petroleum Corporation Limited',
        type: 'Public',
        marketShare: '~25%',
        specialFeatures: ['Power Petrol', 'Power Diesel', 'Club HP', 'Poorna Fuels']
      },
      {
        name: 'BPCL',
        fullName: 'Bharat Petroleum Corporation Limited',
        type: 'Public',
        marketShare: '~22%',
        specialFeatures: ['Speed Petrol', 'MAK Lubricants', 'PetroCard', 'Smart Fleet']
      },
      {
        name: 'Reliance',
        fullName: 'Reliance Industries Limited',
        type: 'Private',
        marketShare: '~5%',
        specialFeatures: ['Premium Fuels', 'Convenience Stores', 'Digital Payments']
      },
      {
        name: 'Essar',
        fullName: 'Essar Oil',
        type: 'Private',
        marketShare: '~2%',
        specialFeatures: ['Quality Fuels', 'Customer Service', 'Modern Facilities']
      },
      {
        name: 'Shell',
        fullName: 'Shell India',
        type: 'Private',
        marketShare: '~1%',
        specialFeatures: ['V-Power Fuels', 'International Standards', 'Premium Service']
      }
    ];
  }

  // Current fuel prices by major cities (sample data - in real app, this would be fetched)
  getCurrentPrices(): Array<FuelPrice> {
    return [
      {
        fuelType: 'Petrol',
        price: 103.94,
        currency: 'INR',
        city: 'Mumbai',
        state: 'Maharashtra',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.50, direction: 'up', date: new Date().toISOString() }
      },
      {
        fuelType: 'Diesel',
        price: 89.83,
        currency: 'INR',
        city: 'Mumbai',
        state: 'Maharashtra',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.30, direction: 'up', date: new Date().toISOString() }
      },
      {
        fuelType: 'Petrol',
        price: 96.72,
        currency: 'INR',
        city: 'Delhi',
        state: 'Delhi',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.25, direction: 'down', date: new Date().toISOString() }
      },
      {
        fuelType: 'Diesel',
        price: 89.62,
        currency: 'INR',
        city: 'Delhi',
        state: 'Delhi',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.15, direction: 'up', date: new Date().toISOString() }
      },
      {
        fuelType: 'Petrol',
        price: 102.63,
        currency: 'INR',
        city: 'Bangalore',
        state: 'Karnataka',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.40, direction: 'up', date: new Date().toISOString() }
      },
      {
        fuelType: 'Diesel',
        price: 88.94,
        currency: 'INR',
        city: 'Bangalore',
        state: 'Karnataka',
        lastUpdated: new Date().toISOString(),
        priceChange: { amount: 0.20, direction: 'same', date: new Date().toISOString() }
      }
    ];
  }

  // Fuel efficiency tips
  getFuelEfficiencyTips(): FuelConsumptionTip[] {
    return [
      {
        category: 'Driving Habits',
        tips: [
          {
            tip: 'Maintain steady speed and avoid sudden acceleration',
            savings: '10-15% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Use cruise control on highways when possible',
            savings: '5-10% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Avoid excessive idling - turn off engine if stopped for more than 30 seconds',
            savings: '5-8% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Plan routes to avoid traffic congestion',
            savings: '8-12% fuel savings',
            difficulty: 'Medium'
          },
          {
            tip: 'Combine multiple errands into one trip',
            savings: '15-20% fuel savings',
            difficulty: 'Easy'
          }
        ]
      },
      {
        category: 'Vehicle Maintenance',
        tips: [
          {
            tip: 'Keep tires properly inflated to recommended pressure',
            savings: '3-5% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Regular engine tune-ups and oil changes',
            savings: '5-10% fuel savings',
            difficulty: 'Medium'
          },
          {
            tip: 'Replace air filter when dirty',
            savings: '2-4% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Use recommended grade of motor oil',
            savings: '1-2% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Fix any engine issues promptly',
            savings: '10-40% fuel savings',
            difficulty: 'Hard'
          }
        ]
      },
      {
        category: 'Vehicle Usage',
        tips: [
          {
            tip: 'Remove excess weight from vehicle',
            savings: '1-2% per 100 lbs removed',
            difficulty: 'Easy'
          },
          {
            tip: 'Remove roof racks/carriers when not in use',
            savings: '2-8% fuel savings',
            difficulty: 'Easy'
          },
          {
            tip: 'Use air conditioning efficiently - windows down at low speeds, AC at high speeds',
            savings: '5-10% fuel savings',
            difficulty: 'Medium'
          },
          {
            tip: 'Consider carpooling or public transport for regular commutes',
            savings: '50% fuel cost reduction',
            difficulty: 'Medium'
          }
        ]
      },
      {
        category: 'Alternative Options',
        tips: [
          {
            tip: 'Consider CNG conversion for high-usage vehicles',
            savings: '40-50% fuel cost reduction',
            difficulty: 'Hard'
          },
          {
            tip: 'Explore electric or hybrid vehicle options',
            savings: '60-80% fuel cost reduction',
            difficulty: 'Hard'
          },
          {
            tip: 'Use bike or walk for short distances',
            savings: '100% fuel savings for those trips',
            difficulty: 'Easy'
          },
          {
            tip: 'Work from home when possible',
            savings: '100% commute fuel savings',
            difficulty: 'Medium'
          }
        ]
      }
    ];
  }

  // Fuel types and their characteristics
  getFuelTypes(): Array<{
    type: string;
    description: string;
    advantages: string[];
    disadvantages: string[];
    suitableFor: string[];
    avgPrice: string;
  }> {
    return [
      {
        type: 'Petrol',
        description: 'Refined petroleum product used in spark-ignition engines',
        advantages: [
          'Clean burning',
          'Good performance',
          'Widely available',
          'Suitable for high-speed driving'
        ],
        disadvantages: [
          'More expensive than diesel',
          'Lower fuel efficiency than diesel',
          'Higher CO2 emissions per liter'
        ],
        suitableFor: ['Cars', 'Motorcycles', 'Small vehicles', 'City driving'],
        avgPrice: '₹95-105 per liter'
      },
      {
        type: 'Diesel',
        description: 'Petroleum product used in compression-ignition engines',
        advantages: [
          'Better fuel efficiency',
          'More torque',
          'Longer engine life',
          'Lower CO2 emissions per km'
        ],
        disadvantages: [
          'Higher initial cost',
          'More maintenance required',
          'Noise and vibration',
          'Higher particulate emissions'
        ],
        suitableFor: ['Heavy vehicles', 'Long-distance travel', 'Commercial use'],
        avgPrice: '₹85-95 per liter'
      },
      {
        type: 'CNG',
        description: 'Compressed Natural Gas - cleaner alternative fuel',
        advantages: [
          'Much cheaper than petrol/diesel',
          'Environmentally friendly',
          'Lower maintenance costs',
          'Government incentives'
        ],
        disadvantages: [
          'Limited refueling stations',
          'Reduced boot space',
          'Lower power output',
          'Initial conversion cost'
        ],
        suitableFor: ['City taxis', 'Commercial vehicles', 'Daily commuters'],
        avgPrice: '₹50-70 per kg'
      },
      {
        type: 'LPG',
        description: 'Liquefied Petroleum Gas - alternative fuel option',
        advantages: [
          'Cheaper than petrol',
          'Cleaner emissions',
          'Good performance',
          'Dual fuel option available'
        ],
        disadvantages: [
          'Safety concerns',
          'Limited refueling infrastructure',
          'Reduced trunk space',
          'Regular safety inspections required'
        ],
        suitableFor: ['Personal vehicles', 'Fleet operators', 'Cost-conscious users'],
        avgPrice: '₹60-80 per liter'
      }
    ];
  }

  // Petrol pump services and facilities
  getPetrolPumpServices(): Array<{
    service: string;
    description: string;
    availability: string;
    cost: string;
  }> {
    return [
      {
        service: 'Fuel Filling',
        description: 'Petrol, diesel, and other fuel types',
        availability: 'All pumps',
        cost: 'Per liter rates'
      },
      {
        service: 'Air Filling',
        description: 'Tire pressure checking and air filling',
        availability: 'Most pumps',
        cost: 'Usually free'
      },
      {
        service: 'Car Wash',
        description: 'Vehicle cleaning services',
        availability: 'Many pumps',
        cost: '₹50-200'
      },
      {
        service: 'Oil Change',
        description: 'Engine oil and lubricant services',
        availability: 'Select pumps',
        cost: '₹500-2000'
      },
      {
        service: 'Convenience Store',
        description: 'Snacks, beverages, and basic items',
        availability: 'Major brand pumps',
        cost: 'Retail prices'
      },
      {
        service: 'ATM',
        description: 'Cash withdrawal facility',
        availability: 'Many pumps',
        cost: 'Bank charges apply'
      },
      {
        service: 'Restrooms',
        description: 'Clean toilet facilities',
        availability: 'Most highway pumps',
        cost: 'Usually free'
      },
      {
        service: 'Vehicle Inspection',
        description: 'Basic vehicle check-up services',
        availability: 'Select pumps',
        cost: '₹100-500'
      }
    ];
  }

  // Fuel price factors
  getPriceFactors(): Array<{
    factor: string;
    impact: string;
    description: string;
  }> {
    return [
      {
        factor: 'Crude Oil Prices',
        impact: 'High',
        description: 'International crude oil prices directly affect fuel costs'
      },
      {
        factor: 'Exchange Rate',
        impact: 'High',
        description: 'USD-INR exchange rate affects import costs'
      },
      {
        factor: 'Central Taxes',
        impact: 'High',
        description: 'Central excise duty and cess imposed by government'
      },
      {
        factor: 'State Taxes',
        impact: 'High',
        description: 'VAT/Sales tax varies by state, causing price differences'
      },
      {
        factor: 'Dealer Commission',
        impact: 'Medium',
        description: 'Margin for fuel station operators'
      },
      {
        factor: 'Transportation Cost',
        impact: 'Low',
        description: 'Cost of transporting fuel from refineries to pumps'
      },
      {
        factor: 'Refinery Processing',
        impact: 'Medium',
        description: 'Cost of refining crude oil into finished products'
      },
      {
        factor: 'Market Demand',
        impact: 'Medium',
        description: 'Supply and demand dynamics in the market'
      }
    ];
  }

  // Digital payment options at fuel stations
  getPaymentOptions(): Array<{
    method: string;
    description: string;
    benefits: string[];
    availability: string;
  }> {
    return [
      {
        method: 'UPI',
        description: 'Unified Payments Interface - instant bank transfers',
        benefits: ['Instant payment', 'No transaction fees', 'Secure', 'Widely accepted'],
        availability: 'Most modern pumps'
      },
      {
        method: 'Credit/Debit Cards',
        description: 'Bank cards with chip and PIN',
        benefits: ['Cashless', 'Reward points', 'Transaction history', 'Secure'],
        availability: 'Most pumps'
      },
      {
        method: 'Mobile Wallets',
        description: 'Paytm, PhonePe, Google Pay, etc.',
        benefits: ['Quick payment', 'Cashback offers', 'Easy to use', 'Transaction tracking'],
        availability: 'Many pumps'
      },
      {
        method: 'Fuel Cards',
        description: 'Brand-specific prepaid/credit cards',
        benefits: ['Fuel discounts', 'Fleet management', 'Detailed reports', 'Credit facility'],
        availability: 'Brand-specific pumps'
      },
      {
        method: 'RFID Tags',
        description: 'Radio frequency identification for quick payment',
        benefits: ['Very fast', 'No handling required', 'Automatic billing', 'Fleet friendly'],
        availability: 'Select modern pumps'
      },
      {
        method: 'Cash',
        description: 'Traditional currency notes and coins',
        benefits: ['Universal acceptance', 'No technology required', 'Immediate'],
        availability: 'All pumps'
      }
    ];
  }
}

// Export singleton instance
export const fuelService = new FuelService();