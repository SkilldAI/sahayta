export interface UtilityBillInfo {
  provider: string;
  accountNumber: string;
  billAmount: number;
  dueDate: string;
  billDate: string;
  unitsConsumed?: number;
  previousReading?: number;
  currentReading?: number;
  tariffRate?: number;
}

export interface UtilityProvider {
  name: string;
  fullName: string;
  state: string;
  type: 'Electricity' | 'Water' | 'Gas';
  website: string;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class UtilityService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=utility&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Utility Service Error (${action}):`, error);
      throw error;
    }
  }

  async getBillInfo(provider: string, accountNumber: string, state?: string): Promise<UtilityBillInfo> {
    if (!provider || !accountNumber) {
      throw new Error('Provider and account number are required');
    }

    return await this.makeRequest('bill-info', { provider, accountNumber, state });
  }

  async getUtilityProviders(): Promise<UtilityProvider[]> {
    return await this.makeRequest('providers', {});
  }

  // Utility methods
  validateAccountNumber(accountNumber: string, provider: string): boolean {
    // Basic validation - each provider has different formats
    switch (provider.toLowerCase()) {
      case 'bescom':
        return /^\d{10,12}$/.test(accountNumber);
      case 'kseb':
        return /^\d{8,12}$/.test(accountNumber);
      case 'tneb':
        return /^\d{9,12}$/.test(accountNumber);
      case 'bwssb':
        return /^\d{8,10}$/.test(accountNumber);
      default:
        return accountNumber.length >= 6;
    }
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  calculateDaysUntilDue(dueDate: string): number {
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = due.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  getDueDateStatus(dueDate: string): { status: string; color: string; message: string } {
    const daysLeft = this.calculateDaysUntilDue(dueDate);
    
    if (daysLeft < 0) {
      return {
        status: 'overdue',
        color: '#F44336',
        message: `Overdue by ${Math.abs(daysLeft)} days`
      };
    } else if (daysLeft <= 3) {
      return {
        status: 'urgent',
        color: '#FF9800',
        message: `Due in ${daysLeft} days`
      };
    } else if (daysLeft <= 7) {
      return {
        status: 'warning',
        color: '#FFC107',
        message: `Due in ${daysLeft} days`
      };
    } else {
      return {
        status: 'normal',
        color: '#00A86B',
        message: `Due in ${daysLeft} days`
      };
    }
  }

  // Major utility providers by state
  getProvidersByState(): Record<string, UtilityProvider[]> {
    return {
      "Karnataka": [
        {
          name: "BESCOM",
          fullName: "Bangalore Electricity Supply Company",
          state: "Karnataka",
          type: "Electricity",
          website: "https://bescom.karnataka.gov.in"
        },
        {
          name: "MESCOM",
          fullName: "Mangalore Electricity Supply Company",
          state: "Karnataka",
          type: "Electricity",
          website: "https://mescom.karnataka.gov.in"
        },
        {
          name: "BWSSB",
          fullName: "Bangalore Water Supply and Sewerage Board",
          state: "Karnataka",
          type: "Water",
          website: "https://bwssb.gov.in"
        }
      ],
      "Kerala": [
        {
          name: "KSEB",
          fullName: "Kerala State Electricity Board",
          state: "Kerala",
          type: "Electricity",
          website: "https://kseb.in"
        },
        {
          name: "KWA",
          fullName: "Kerala Water Authority",
          state: "Kerala",
          type: "Water",
          website: "https://kwa.kerala.gov.in"
        }
      ],
      "Tamil Nadu": [
        {
          name: "TNEB",
          fullName: "Tamil Nadu Electricity Board",
          state: "Tamil Nadu",
          type: "Electricity",
          website: "https://tneb.in"
        },
        {
          name: "CMWSSB",
          fullName: "Chennai Metropolitan Water Supply and Sewerage Board",
          state: "Tamil Nadu",
          type: "Water",
          website: "https://chennaimetrowater.gov.in"
        }
      ],
      "Delhi": [
        {
          name: "BSES",
          fullName: "BSES Rajdhani Power Limited",
          state: "Delhi",
          type: "Electricity",
          website: "https://www.bsesdelhi.com"
        },
        {
          name: "TPDDL",
          fullName: "Tata Power Delhi Distribution Limited",
          state: "Delhi",
          type: "Electricity",
          website: "https://www.tatapower-ddl.com"
        },
        {
          name: "DJB",
          fullName: "Delhi Jal Board",
          state: "Delhi",
          type: "Water",
          website: "https://delhijalboard.nic.in"
        },
        {
          name: "IGL",
          fullName: "Indraprastha Gas Limited",
          state: "Delhi",
          type: "Gas",
          website: "https://iglonline.net"
        }
      ],
      "Maharashtra": [
        {
          name: "MSEDCL",
          fullName: "Maharashtra State Electricity Distribution Company Limited",
          state: "Maharashtra",
          type: "Electricity",
          website: "https://www.mahadiscom.in"
        },
        {
          name: "BMC",
          fullName: "Brihanmumbai Municipal Corporation",
          state: "Maharashtra",
          type: "Water",
          website: "https://portal.mcgm.gov.in"
        }
      ],
      "Gujarat": [
        {
          name: "PGVCL",
          fullName: "Paschim Gujarat Vij Company Limited",
          state: "Gujarat",
          type: "Electricity",
          website: "https://www.pgvcl.com"
        },
        {
          name: "UGVCL",
          fullName: "Uttar Gujarat Vij Company Limited",
          state: "Gujarat",
          type: "Electricity",
          website: "https://www.ugvcl.com"
        }
      ]
    };
  }

  // Bill payment tips
  getBillPaymentTips(): string[] {
    return [
      "Set up automatic bill payments to avoid late fees",
      "Keep digital copies of all paid bills",
      "Check bill details carefully before payment",
      "Use official websites or apps for payments",
      "Enable SMS/email alerts for due dates",
      "Pay bills a few days before due date",
      "Keep payment confirmation receipts",
      "Monitor your consumption patterns",
      "Report any billing discrepancies immediately",
      "Consider online payment for convenience and records"
    ];
  }

  // Energy saving tips
  getEnergySavingTips(): string[] {
    return [
      "Use LED bulbs instead of incandescent bulbs",
      "Unplug electronics when not in use",
      "Set AC temperature to 24°C or higher",
      "Use ceiling fans along with AC to feel cooler",
      "Seal gaps around doors and windows",
      "Use natural light during daytime",
      "Regular maintenance of appliances",
      "Use energy-efficient appliances (5-star rated)",
      "Avoid using multiple high-power appliances simultaneously",
      "Install solar water heater if possible"
    ];
  }

  // Water conservation tips
  getWaterSavingTips(): string[] {
    return [
      "Fix leaky taps and pipes immediately",
      "Use bucket instead of shower for bathing",
      "Install low-flow showerheads and faucets",
      "Collect rainwater for gardening",
      "Reuse water from washing machines for cleaning",
      "Turn off tap while brushing teeth or shaving",
      "Use dishwasher and washing machine with full loads",
      "Install dual-flush toilets",
      "Water plants early morning or evening",
      "Use drip irrigation for gardens"
    ];
  }

  // Common bill issues and solutions
  getBillIssuesAndSolutions(): Array<{ issue: string; solution: string }> {
    return [
      {
        issue: "High electricity bill",
        solution: "Check for faulty appliances, meter reading errors, or increased usage patterns"
      },
      {
        issue: "Bill not received",
        solution: "Contact utility provider, check registered address, or access online bill"
      },
      {
        issue: "Incorrect meter reading",
        solution: "Take photo of meter, contact customer service, request re-reading"
      },
      {
        issue: "Payment not reflected",
        solution: "Keep payment receipt, contact customer service with transaction details"
      },
      {
        issue: "Duplicate billing",
        solution: "Check payment history, contact billing department with proof of payment"
      },
      {
        issue: "Connection issues",
        solution: "Report outage through official channels, check for local maintenance work"
      }
    ];
  }

  // Emergency contact numbers by utility type
  getEmergencyContacts(): Record<string, Array<{ service: string; number: string; available: string }>> {
    return {
      "Electricity": [
        { service: "Power Outage", number: "1912", available: "24/7" },
        { service: "Electrical Emergency", number: "1800-425-1912", available: "24/7" },
        { service: "BESCOM Helpline", number: "1912", available: "24/7" }
      ],
      "Water": [
        { service: "Water Supply Issues", number: "1916", available: "24/7" },
        { service: "Sewage Problems", number: "1916", available: "24/7" },
        { service: "BWSSB Emergency", number: "080-22294444", available: "24/7" }
      ],
      "Gas": [
        { service: "Gas Leak Emergency", number: "1906", available: "24/7" },
        { service: "IGL Emergency", number: "1800-425-3333", available: "24/7" },
        { service: "Gas Connection Issues", number: "1906", available: "9 AM - 6 PM" }
      ]
    };
  }
}

// Export singleton instance
export const utilityService = new UtilityService();