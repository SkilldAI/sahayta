export interface Pharmacy {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  pincode?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  phone?: string;
  isOpen24Hours?: boolean;
  services?: string[]; // home delivery, online order, covid meds, etc.
  rating?: number;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

class PharmacyService {
  private async makeRequest(action: string, data: any): Promise<any> {
    const response = await fetch(`${SCRAPER_URL}?service=pharmacy&action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Pharmacy request failed');
    }
    const result = await response.json();
    if (!result.success) throw new Error(result.error || 'Pharmacy scraping failed');
    return result.data;
  }

  async searchPharmacies(location: string): Promise<Pharmacy[]> {
    if (!location) throw new Error('Location is required');
    return this.makeRequest('search', { location });
  }

  async getNearbyPharmacies(latitude: number, longitude: number, radius: number = 5): Promise<Pharmacy[]> {
    if (!latitude || !longitude) throw new Error('Latitude and longitude are required');
    return this.makeRequest('nearby', { latitude, longitude, radius });
  }
}

export const pharmacyService = new PharmacyService();
