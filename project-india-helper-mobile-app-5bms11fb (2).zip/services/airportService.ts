export interface AirportInfo {
  code: string;
  name: string;
  city: string;
  state: string;
  country: string;
  type: 'International' | 'Domestic';
  terminals: Terminal[];
  facilities: string[];
  transportation: TransportOption[];
  contact: ContactInfo;
  coordinates: {
    latitude: number;
    longitude: number;
  };
}

export interface Terminal {
  name: string;
  type: 'Domestic' | 'International';
  airlines: string[];
  facilities: string[];
  shops: string[];
  restaurants: string[];
}

export interface TransportOption {
  type: string;
  name: string;
  cost: string;
  duration: string;
  availability: string;
  description: string;
}

export interface ContactInfo {
  phone: string;
  email: string;
  website: string;
  address: string;
}

export interface FlightStatus {
  flightNumber: string;
  airline: string;
  status: string;
  scheduledTime: string;
  actualTime?: string;
  terminal: string;
  gate?: string;
  delay?: string;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class AirportService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=airport&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Airport Service Error (${action}):`, error);
      throw error;
    }
  }

  async getAirportInfo(airportCode: string): Promise<AirportInfo> {
    if (!airportCode || airportCode.length !== 3) {
      throw new Error('Valid 3-letter airport code is required');
    }

    return await this.makeRequest('info', { airportCode: airportCode.toUpperCase() });
  }

  async getFlightStatus(flightNumber: string, date?: string): Promise<FlightStatus> {
    if (!flightNumber) {
      throw new Error('Flight number is required');
    }

    return await this.makeRequest('flight-status', { flightNumber, date });
  }

  async getAirportDelays(airportCode: string): Promise<{
    departures: FlightStatus[];
    arrivals: FlightStatus[];
  }> {
    if (!airportCode) {
      throw new Error('Airport code is required');
    }

    return await this.makeRequest('delays', { airportCode: airportCode.toUpperCase() });
  }

  // Utility methods
  validateAirportCode(code: string): boolean {
    return /^[A-Z]{3}$/.test(code.toUpperCase());
  }

  validateFlightNumber(flightNumber: string): boolean {
    return /^[A-Z]{2,3}[-\s]?\d{3,4}$/i.test(flightNumber);
  }

  formatFlightNumber(flightNumber: string): string {
    return flightNumber.toUpperCase().replace(/[-\s]/g, '');
  }

  // Major Indian airports with detailed information
  getIndianAirports(): AirportInfo[] {
    return [
      {
        code: 'DEL',
        name: 'Indira Gandhi International Airport',
        city: 'New Delhi',
        state: 'Delhi',
        country: 'India',
        type: 'International',
        coordinates: { latitude: 28.5562, longitude: 77.1000 },
        terminals: [
          {
            name: 'Terminal 1',
            type: 'Domestic',
            airlines: ['IndiGo', 'SpiceJet', 'GoAir'],
            facilities: ['WiFi', 'Food Court', 'Shopping', 'Lounges'],
            shops: ['Duty Free', 'Souvenirs', 'Books', 'Electronics'],
            restaurants: ['McDonald\'s', 'Subway', 'Local Cuisine', 'Coffee Shops']
          },
          {
            name: 'Terminal 2',
            type: 'Domestic',
            airlines: ['Air India', 'Vistara'],
            facilities: ['WiFi', 'Premium Lounges', 'Spa', 'Business Center'],
            shops: ['Luxury Brands', 'Duty Free', 'Handicrafts'],
            restaurants: ['Fine Dining', 'Quick Service', 'Bar']
          },
          {
            name: 'Terminal 3',
            type: 'International',
            airlines: ['International Airlines', 'Air India International'],
            facilities: ['WiFi', 'Duty Free', 'Lounges', 'Hotel', 'Spa'],
            shops: ['Luxury Shopping', 'Electronics', 'Fashion', 'Souvenirs'],
            restaurants: ['International Cuisine', 'Indian Cuisine', 'Bars', 'Cafes']
          }
        ],
        facilities: [
          'Free WiFi', 'Currency Exchange', 'ATMs', 'Medical Center',
          'Pharmacy', 'Lost & Found', 'Baggage Storage', 'Car Rental',
          'Hotel Booking', 'Tourist Information', 'Prayer Room', 'Smoking Zone'
        ],
        transportation: [
          {
            type: 'Metro',
            name: 'Airport Express Line',
            cost: '₹60-80',
            duration: '20-25 minutes to city center',
            availability: '24/7',
            description: 'Direct metro connection to New Delhi Railway Station'
          },
          {
            type: 'Taxi',
            name: 'Prepaid Taxi',
            cost: '₹400-800',
            duration: '45-90 minutes',
            availability: '24/7',
            description: 'Government authorized prepaid taxi service'
          },
          {
            type: 'App Cab',
            name: 'Uber/Ola',
            cost: '₹300-600',
            duration: '45-90 minutes',
            availability: '24/7',
            description: 'App-based cab services with multiple options'
          },
          {
            type: 'Bus',
            name: 'Airport Shuttle',
            cost: '₹50-100',
            duration: '60-120 minutes',
            availability: '5 AM - 11 PM',
            description: 'AC bus service to various parts of Delhi'
          }
        ],
        contact: {
          phone: '+91-124-3376000',
          email: 'feedback@newdelhiairport.in',
          website: 'https://www.newdelhiairport.in',
          address: 'New Delhi 110037, India'
        }
      },
      {
        code: 'BOM',
        name: 'Chhatrapati Shivaji Maharaj International Airport',
        city: 'Mumbai',
        state: 'Maharashtra',
        country: 'India',
        type: 'International',
        coordinates: { latitude: 19.0896, longitude: 72.8656 },
        terminals: [
          {
            name: 'Terminal 1',
            type: 'Domestic',
            airlines: ['IndiGo', 'SpiceJet', 'GoAir', 'AirAsia'],
            facilities: ['WiFi', 'Food Court', 'Shopping', 'Lounges'],
            shops: ['Retail Stores', 'Books', 'Souvenirs'],
            restaurants: ['Food Court', 'Cafes', 'Quick Bites']
          },
          {
            name: 'Terminal 2',
            type: 'International',
            airlines: ['Air India', 'Vistara', 'International Airlines'],
            facilities: ['WiFi', 'Duty Free', 'Lounges', 'Spa', 'Hotel'],
            shops: ['Luxury Shopping', 'Duty Free', 'Electronics', 'Fashion'],
            restaurants: ['Fine Dining', 'International Cuisine', 'Bars']
          }
        ],
        facilities: [
          'Free WiFi', 'Currency Exchange', 'ATMs', 'Medical Center',
          'Pharmacy', 'Lost & Found', 'Baggage Storage', 'Car Rental',
          'Hotel Booking', 'Tourist Information', 'Prayer Room'
        ],
        transportation: [
          {
            type: 'Taxi',
            name: 'Prepaid Taxi',
            cost: '₹500-1000',
            duration: '45-90 minutes',
            availability: '24/7',
            description: 'Government authorized prepaid taxi service'
          },
          {
            type: 'App Cab',
            name: 'Uber/Ola',
            cost: '₹400-800',
            duration: '45-90 minutes',
            availability: '24/7',
            description: 'App-based cab services'
          },
          {
            type: 'Bus',
            name: 'BEST Bus',
            cost: '₹25-50',
            duration: '90-120 minutes',
            availability: '5 AM - 11 PM',
            description: 'Public bus service to various parts of Mumbai'
          },
          {
            type: 'Auto Rickshaw',
            name: 'Auto',
            cost: '₹200-400',
            duration: '60-90 minutes',
            availability: '24/7',
            description: 'Three-wheeler auto rickshaw service'
          }
        ],
        contact: {
          phone: '+91-22-66851010',
          email: 'customercare@csia.in',
          website: 'https://www.csia.in',
          address: 'Mumbai 400099, Maharashtra, India'
        }
      },
      {
        code: 'BLR',
        name: 'Kempegowda International Airport',
        city: 'Bangalore',
        state: 'Karnataka',
        country: 'India',
        type: 'International',
        coordinates: { latitude: 13.1986, longitude: 77.7066 },
        terminals: [
          {
            name: 'Terminal 1',
            type: 'Domestic',
            airlines: ['IndiGo', 'SpiceJet', 'Air India', 'Vistara'],
            facilities: ['WiFi', 'Food Court', 'Shopping', 'Lounges'],
            shops: ['Retail Stores', 'Books', 'Electronics', 'Souvenirs'],
            restaurants: ['Food Court', 'Cafes', 'Local Cuisine']
          },
          {
            name: 'Terminal 2',
            type: 'International',
            airlines: ['International Airlines', 'Air India International'],
            facilities: ['WiFi', 'Duty Free', 'Lounges', 'Spa'],
            shops: ['Duty Free', 'Luxury Brands', 'Electronics'],
            restaurants: ['International Cuisine', 'Fine Dining', 'Bars']
          }
        ],
        facilities: [
          'Free WiFi', 'Currency Exchange', 'ATMs', 'Medical Center',
          'Pharmacy', 'Lost & Found', 'Car Rental', 'Hotel Booking',
          'Tourist Information', 'Prayer Room', 'Smoking Zone'
        ],
        transportation: [
          {
            type: 'Taxi',
            name: 'Prepaid Taxi',
            cost: '₹800-1200',
            duration: '60-90 minutes',
            availability: '24/7',
            description: 'Government authorized prepaid taxi service'
          },
          {
            type: 'App Cab',
            name: 'Uber/Ola',
            cost: '₹600-1000',
            duration: '60-90 minutes',
            availability: '24/7',
            description: 'App-based cab services'
          },
          {
            type: 'Bus',
            name: 'Vayu Vajra',
            cost: '₹100-200',
            duration: '90-120 minutes',
            availability: '5 AM - 12 AM',
            description: 'AC bus service to various parts of Bangalore'
          }
        ],
        contact: {
          phone: '+91-80-22052425',
          email: 'feedback@bengaluruairport.com',
          website: 'https://www.bengaluruairport.com',
          address: 'Devanahalli, Bangalore 560300, Karnataka, India'
        }
      }
    ];
  }

  // Get airport by code
  getAirportByCode(code: string): AirportInfo | null {
    const airports = this.getIndianAirports();
    return airports.find(airport => airport.code === code.toUpperCase()) || null;
  }

  // Get airports by city
  getAirportsByCity(city: string): AirportInfo[] {
    const airports = this.getIndianAirports();
    return airports.filter(airport => 
      airport.city.toLowerCase().includes(city.toLowerCase())
    );
  }

  // Get airports by state
  getAirportsByState(state: string): AirportInfo[] {
    const airports = this.getIndianAirports();
    return airports.filter(airport => 
      airport.state.toLowerCase().includes(state.toLowerCase())
    );
  }

  // Airport facilities categories
  getFacilityCategories(): Array<{
    category: string;
    facilities: Array<{ name: string; description: string; availability: string }>;
  }> {
    return [
      {
        category: 'Basic Services',
        facilities: [
          { name: 'Free WiFi', description: 'Complimentary internet access', availability: 'All terminals' },
          { name: 'ATMs', description: 'Cash withdrawal machines', availability: 'Multiple locations' },
          { name: 'Currency Exchange', description: 'Foreign exchange services', availability: 'International terminals' },
          { name: 'Information Desk', description: 'Tourist and flight information', availability: 'All terminals' }
        ]
      },
      {
        category: 'Comfort & Convenience',
        facilities: [
          { name: 'Lounges', description: 'Premium waiting areas', availability: 'All terminals' },
          { name: 'Sleeping Pods', description: 'Rest areas for passengers', availability: 'Select airports' },
          { name: 'Baggage Storage', description: 'Temporary luggage storage', availability: 'Most airports' },
          { name: 'Lost & Found', description: 'Lost item recovery service', availability: 'All airports' }
        ]
      },
      {
        category: 'Health & Wellness',
        facilities: [
          { name: 'Medical Center', description: 'Emergency medical services', availability: 'All major airports' },
          { name: 'Pharmacy', description: 'Medicine and health products', availability: 'Most airports' },
          { name: 'Spa Services', description: 'Relaxation and wellness treatments', availability: 'Premium airports' },
          { name: 'Fitness Center', description: 'Exercise facilities', availability: 'Select airports' }
        ]
      },
      {
        category: 'Shopping & Dining',
        facilities: [
          { name: 'Duty Free', description: 'Tax-free shopping', availability: 'International terminals' },
          { name: 'Restaurants', description: 'Various dining options', availability: 'All terminals' },
          { name: 'Retail Stores', description: 'Shopping outlets', availability: 'All terminals' },
          { name: 'Food Courts', description: 'Multiple food vendors', availability: 'Most terminals' }
        ]
      }
    ];
  }

  // Transportation options from airports
  getTransportationGuide(): Array<{
    type: string;
    description: string;
    pros: string[];
    cons: string[];
    bestFor: string;
  }> {
    return [
      {
        type: 'Metro/Train',
        description: 'Rail-based public transportation',
        pros: ['Cost-effective', 'Avoids traffic', 'Reliable timing', 'Eco-friendly'],
        cons: ['Limited routes', 'Crowded during peak hours', 'May require transfers'],
        bestFor: 'Budget travelers, avoiding traffic'
      },
      {
        type: 'Prepaid Taxi',
        description: 'Government authorized taxi service',
        pros: ['Fixed rates', 'No haggling', 'Safe and reliable', 'Available 24/7'],
        cons: ['More expensive than public transport', 'Traffic delays'],
        bestFor: 'First-time visitors, safety-conscious travelers'
      },
      {
        type: 'App-based Cabs',
        description: 'Uber, Ola, and similar services',
        pros: ['Transparent pricing', 'GPS tracking', 'Multiple vehicle options', 'Cashless payment'],
        cons: ['Surge pricing', 'Cancellation issues', 'Traffic delays'],
        bestFor: 'Tech-savvy travelers, convenience seekers'
      },
      {
        type: 'Public Bus',
        description: 'City bus services to airport',
        pros: ['Very economical', 'Extensive network', 'Regular service'],
        cons: ['Slower journey', 'Limited luggage space', 'Less comfortable'],
        bestFor: 'Budget travelers, light luggage'
      },
      {
        type: 'Private Car/Rental',
        description: 'Personal or rental vehicle',
        pros: ['Complete flexibility', 'Privacy', 'Direct route', 'Luggage space'],
        cons: ['Parking fees', 'Traffic stress', 'Higher cost'],
        bestFor: 'Business travelers, families with lots of luggage'
      }
    ];
  }

  // Airport security guidelines
  getSecurityGuidelines(): Array<{
    category: string;
    guidelines: string[];
  }> {
    return [
      {
        category: 'Check-in & Baggage',
        guidelines: [
          'Arrive 2 hours early for domestic flights, 3 hours for international',
          'Check baggage weight limits and restrictions',
          'Keep important documents easily accessible',
          'Pack liquids in containers of 100ml or less for carry-on',
          'Remove electronics larger than phone from carry-on for screening'
        ]
      },
      {
        category: 'Security Screening',
        guidelines: [
          'Have boarding pass and ID ready',
          'Remove shoes, belt, and jacket if required',
          'Place laptops and large electronics in separate bins',
          'Follow liquid restrictions (3-1-1 rule)',
          'Cooperate with security personnel'
        ]
      },
      {
        category: 'Prohibited Items',
        guidelines: [
          'No sharp objects (knives, scissors over 6cm)',
          'No liquids over 100ml in carry-on',
          'No firearms or weapons',
          'No flammable materials',
          'Check airline-specific restrictions'
        ]
      },
      {
        category: 'Health & Safety',
        guidelines: [
          'Follow current health protocols (masks, vaccination)',
          'Carry hand sanitizer (under 100ml for carry-on)',
          'Keep emergency contacts handy',
          'Take necessary medications in original containers',
          'Stay hydrated and move regularly during long flights'
        ]
      }
    ];
  }

  // Airport services and amenities
  getAirportServices(): Array<{
    service: string;
    description: string;
    availability: string;
    cost: string;
  }> {
    return [
      {
        service: 'Porter Service',
        description: 'Assistance with luggage handling',
        availability: 'All major airports',
        cost: '₹50-100 per bag'
      },
      {
        service: 'Wheelchair Assistance',
        description: 'Mobility assistance for passengers',
        availability: 'All airports',
        cost: 'Free (advance booking recommended)'
      },
      {
        service: 'VIP Services',
        description: 'Fast-track check-in and security',
        availability: 'Major airports',
        cost: '₹2000-5000'
      },
      {
        service: 'Lounge Access',
        description: 'Premium waiting areas with amenities',
        availability: 'All major airports',
        cost: '₹1000-3000 or membership'
      },
      {
        service: 'Hotel Booking',
        description: 'Accommodation booking assistance',
        availability: 'Most airports',
        cost: 'Service charges may apply'
      },
      {
        service: 'Car Rental',
        description: 'Vehicle rental services',
        availability: 'Major airports',
        cost: 'Varies by provider and duration'
      }
    ];
  }
}

// Export singleton instance
export const airportService = new AirportService();