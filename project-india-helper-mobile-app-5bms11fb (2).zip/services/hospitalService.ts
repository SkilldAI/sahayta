export interface Hospital {
  id: string;
  name: string;
  type: 'Government' | 'Private' | 'Trust' | 'Corporate';
  specialties: string[];
  address: string;
  city: string;
  state: string;
  pincode: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  contactInfo: {
    phone: string;
    emergency: string;
    email?: string;
    website?: string;
  };
  facilities: string[];
  services: string[];
  operatingHours: {
    opd: string;
    emergency: string;
    pharmacy: string;
  };
  rating: number;
  bedCapacity: number;
  hasEmergency: boolean;
  hasAmbulance: boolean;
  acceptsInsurance: boolean;
  insuranceProviders: string[];
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  qualification: string;
  experience: number;
  hospitalId: string;
  hospitalName: string;
  consultationFee: number;
  availableDays: string[];
  availableHours: string;
  rating: number;
  languages: string[];
}

export interface MedicalService {
  id: string;
  name: string;
  category: string;
  description: string;
  avgCost: string;
  duration: string;
  preparation?: string;
  availability: string;
}

export interface EmergencyContact {
  service: string;
  number: string;
  description: string;
  availability: string;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class HospitalService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=hospital&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Hospital Service Error (${action}):`, error);
      throw error;
    }
  }

  async searchHospitals(
    location: string,
    specialty?: string,
    type?: string
  ): Promise<Hospital[]> {
    if (!location) {
      throw new Error('Location is required');
    }

    return await this.makeRequest('search', { location, specialty, type });
  }

  async getNearbyHospitals(
    latitude: number,
    longitude: number,
    radius: number = 10
  ): Promise<Hospital[]> {
    if (!latitude || !longitude) {
      throw new Error('Latitude and longitude are required');
    }

    return await this.makeRequest('nearby', { latitude, longitude, radius });
  }

  async getHospitalDetails(hospitalId: string): Promise<Hospital> {
    if (!hospitalId) {
      throw new Error('Hospital ID is required');
    }

    return await this.makeRequest('details', { hospitalId });
  }

  async searchDoctors(
    location: string,
    specialization?: string,
    hospitalId?: string
  ): Promise<Doctor[]> {
    if (!location) {
      throw new Error('Location is required');
    }

    return await this.makeRequest('doctors', { location, specialization, hospitalId });
  }

  // Utility methods
  calculateDistance(
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  // Medical specialties available in India
  getMedicalSpecialties(): Array<{
    name: string;
    description: string;
    commonConditions: string[];
    whenToConsult: string[];
  }> {
    return [
      {
        name: 'Cardiology',
        description: 'Heart and cardiovascular system disorders',
        commonConditions: ['Heart Attack', 'Hypertension', 'Arrhythmia', 'Heart Failure'],
        whenToConsult: ['Chest pain', 'Shortness of breath', 'Irregular heartbeat', 'High blood pressure']
      },
      {
        name: 'Orthopedics',
        description: 'Bone, joint, and musculoskeletal system',
        commonConditions: ['Fractures', 'Arthritis', 'Back Pain', 'Sports Injuries'],
        whenToConsult: ['Bone fractures', 'Joint pain', 'Back problems', 'Sports injuries']
      },
      {
        name: 'Neurology',
        description: 'Brain, spinal cord, and nervous system',
        commonConditions: ['Stroke', 'Epilepsy', 'Migraine', 'Parkinson\'s Disease'],
        whenToConsult: ['Severe headaches', 'Memory problems', 'Seizures', 'Numbness']
      },
      {
        name: 'Gastroenterology',
        description: 'Digestive system and liver disorders',
        commonConditions: ['Ulcers', 'IBS', 'Liver Disease', 'Gallstones'],
        whenToConsult: ['Stomach pain', 'Digestive issues', 'Liver problems', 'Bowel disorders']
      },
      {
        name: 'Dermatology',
        description: 'Skin, hair, and nail conditions',
        commonConditions: ['Acne', 'Eczema', 'Psoriasis', 'Skin Cancer'],
        whenToConsult: ['Skin rashes', 'Hair loss', 'Moles changes', 'Persistent skin issues']
      },
      {
        name: 'Gynecology',
        description: 'Women\'s reproductive health',
        commonConditions: ['PCOS', 'Menstrual Disorders', 'Pregnancy Care', 'Menopause'],
        whenToConsult: ['Irregular periods', 'Pregnancy planning', 'Reproductive issues', 'Menopause symptoms']
      },
      {
        name: 'Pediatrics',
        description: 'Children\'s health and development',
        commonConditions: ['Childhood Infections', 'Growth Issues', 'Vaccination', 'Developmental Delays'],
        whenToConsult: ['Child illness', 'Growth concerns', 'Vaccination schedule', 'Behavioral issues']
      },
      {
        name: 'Ophthalmology',
        description: 'Eye and vision disorders',
        commonConditions: ['Cataract', 'Glaucoma', 'Refractive Errors', 'Diabetic Retinopathy'],
        whenToConsult: ['Vision problems', 'Eye pain', 'Sudden vision loss', 'Regular eye checkup']
      },
      {
        name: 'ENT',
        description: 'Ear, Nose, and Throat disorders',
        commonConditions: ['Hearing Loss', 'Sinusitis', 'Throat Infections', 'Tonsillitis'],
        whenToConsult: ['Hearing problems', 'Sinus issues', 'Throat pain', 'Ear infections']
      },
      {
        name: 'Psychiatry',
        description: 'Mental health and behavioral disorders',
        commonConditions: ['Depression', 'Anxiety', 'Bipolar Disorder', 'Schizophrenia'],
        whenToConsult: ['Persistent sadness', 'Anxiety attacks', 'Behavioral changes', 'Sleep disorders']
      }
    ];
  }

  // Hospital types and their characteristics
  getHospitalTypes(): Array<{
    type: string;
    description: string;
    advantages: string[];
    disadvantages: string[];
    costRange: string;
  }> {
    return [
      {
        type: 'Government',
        description: 'Public hospitals run by government',
        advantages: [
          'Very affordable/free treatment',
          'Qualified doctors',
          'Emergency services',
          'No profit motive'
        ],
        disadvantages: [
          'Long waiting times',
          'Overcrowded',
          'Limited amenities',
          'Bureaucratic processes'
        ],
        costRange: 'Free to ₹500'
      },
      {
        type: 'Private',
        description: 'Privately owned healthcare facilities',
        advantages: [
          'Quick service',
          'Better amenities',
          'Advanced equipment',
          'Personalized care'
        ],
        disadvantages: [
          'Expensive treatment',
          'Profit-driven',
          'May oversell services',
          'Insurance may not cover all'
        ],
        costRange: '₹1000-10000+'
      },
      {
        type: 'Trust/NGO',
        description: 'Non-profit charitable hospitals',
        advantages: [
          'Affordable treatment',
          'Quality care',
          'Social service focus',
          'Good facilities'
        ],
        disadvantages: [
          'Limited locations',
          'May have waiting lists',
          'Funding dependent',
          'Limited specialties'
        ],
        costRange: '₹200-2000'
      },
      {
        type: 'Corporate',
        description: 'Large hospital chains and networks',
        advantages: [
          'Standardized quality',
          'Multiple locations',
          'Advanced technology',
          'Comprehensive services'
        ],
        disadvantages: [
          'High costs',
          'Commercial approach',
          'May lack personal touch',
          'Insurance complications'
        ],
        costRange: '₹2000-15000+'
      }
    ];
  }

  // Emergency services and contact numbers
  getEmergencyContacts(): EmergencyContact[] {
    return [
      {
        service: 'Ambulance',
        number: '108',
        description: 'Free emergency ambulance service across India',
        availability: '24/7'
      },
      {
        service: 'Police',
        number: '100',
        description: 'Police emergency helpline',
        availability: '24/7'
      },
      {
        service: 'Fire Brigade',
        number: '101',
        description: 'Fire emergency services',
        availability: '24/7'
      },
      {
        service: 'Disaster Management',
        number: '108',
        description: 'Natural disaster and emergency response',
        availability: '24/7'
      },
      {
        service: 'Women Helpline',
        number: '1091',
        description: 'Women in distress helpline',
        availability: '24/7'
      },
      {
        service: 'Child Helpline',
        number: '1098',
        description: 'Child emergency and abuse helpline',
        availability: '24/7'
      },
      {
        service: 'Senior Citizen Helpline',
        number: '14567',
        description: 'Elderly care and emergency helpline',
        availability: '24/7'
      },
      {
        service: 'Mental Health Helpline',
        number: '9152987821',
        description: 'Mental health crisis support',
        availability: '24/7'
      },
      {
        service: 'Poison Control',
        number: '1066',
        description: 'Poison control and toxicology helpline',
        availability: '24/7'
      },
      {
        service: 'Blood Bank',
        number: '104',
        description: 'Blood donation and requirement helpline',
        availability: '24/7'
      }
    ];
  }

  // Common medical services and their details
  getMedicalServices(): MedicalService[] {
    return [
      {
        id: 'general_checkup',
        name: 'General Health Checkup',
        category: 'Preventive',
        description: 'Comprehensive health screening and examination',
        avgCost: '₹1500-5000',
        duration: '2-3 hours',
        preparation: 'Fasting for 12 hours if blood tests included',
        availability: 'All hospitals'
      },
      {
        id: 'blood_test',
        name: 'Blood Tests',
        category: 'Diagnostic',
        description: 'Various blood investigations and pathology tests',
        avgCost: '₹200-2000',
        duration: '15-30 minutes',
        preparation: 'Fasting may be required for some tests',
        availability: 'All hospitals and labs'
      },
      {
        id: 'xray',
        name: 'X-Ray',
        category: 'Imaging',
        description: 'Radiographic imaging for bones and organs',
        avgCost: '₹300-800',
        duration: '10-15 minutes',
        preparation: 'Remove metal objects, may need to change clothes',
        availability: 'Most hospitals'
      },
      {
        id: 'ct_scan',
        name: 'CT Scan',
        category: 'Imaging',
        description: 'Detailed cross-sectional imaging',
        avgCost: '₹3000-8000',
        duration: '30-60 minutes',
        preparation: 'Fasting may be required, contrast agent may be used',
        availability: 'Major hospitals'
      },
      {
        id: 'mri',
        name: 'MRI Scan',
        category: 'Imaging',
        description: 'Magnetic resonance imaging for detailed soft tissue images',
        avgCost: '₹5000-15000',
        duration: '45-90 minutes',
        preparation: 'Remove all metal objects, inform about implants',
        availability: 'Major hospitals'
      },
      {
        id: 'ultrasound',
        name: 'Ultrasound',
        category: 'Imaging',
        description: 'Sound wave imaging for organs and pregnancy',
        avgCost: '₹500-1500',
        duration: '20-30 minutes',
        preparation: 'Full bladder may be required for some scans',
        availability: 'Most hospitals'
      },
      {
        id: 'ecg',
        name: 'ECG/EKG',
        category: 'Cardiac',
        description: 'Heart rhythm and electrical activity test',
        avgCost: '₹200-500',
        duration: '10-15 minutes',
        preparation: 'No special preparation needed',
        availability: 'All hospitals'
      },
      {
        id: 'echo',
        name: 'Echocardiogram',
        category: 'Cardiac',
        description: 'Ultrasound of the heart',
        avgCost: '₹1500-3000',
        duration: '30-45 minutes',
        preparation: 'No special preparation needed',
        availability: 'Most hospitals'
      }
    ];
  }

  // Health insurance providers in India
  getInsuranceProviders(): Array<{
    name: string;
    type: 'Public' | 'Private';
    coverage: string;
    networkHospitals: string;
    specialFeatures: string[];
  }> {
    return [
      {
        name: 'ESIC',
        type: 'Public',
        coverage: 'Basic medical care for employees',
        networkHospitals: 'ESIC hospitals and empaneled private hospitals',
        specialFeatures: ['Free treatment', 'Maternity benefits', 'Disability benefits']
      },
      {
        name: 'CGHS',
        type: 'Public',
        coverage: 'Central government employees and pensioners',
        networkHospitals: 'CGHS dispensaries and empaneled hospitals',
        specialFeatures: ['Comprehensive coverage', 'Cashless treatment', 'Family coverage']
      },
      {
        name: 'Ayushman Bharat',
        type: 'Public',
        coverage: '₹5 lakh per family per year',
        networkHospitals: 'Empaneled public and private hospitals',
        specialFeatures: ['Free for eligible families', 'Cashless treatment', 'Portable across India']
      },
      {
        name: 'Star Health',
        type: 'Private',
        coverage: 'Various plans from ₹1 lakh to ₹1 crore',
        networkHospitals: '9000+ hospitals across India',
        specialFeatures: ['Comprehensive coverage', 'Pre and post hospitalization', 'Day care procedures']
      },
      {
        name: 'HDFC ERGO',
        type: 'Private',
        coverage: 'Flexible plans with various sum insured options',
        networkHospitals: '10000+ hospitals',
        specialFeatures: ['Cashless treatment', 'Health checkups', 'Wellness programs']
      },
      {
        name: 'ICICI Lombard',
        type: 'Private',
        coverage: 'Individual and family floater plans',
        networkHospitals: '6500+ hospitals',
        specialFeatures: ['Instant policy issuance', 'Health checkups', 'Wellness rewards']
      }
    ];
  }

  // Health tips and preventive care
  getHealthTips(): Array<{
    category: string;
    tips: Array<{
      tip: string;
      benefit: string;
      difficulty: 'Easy' | 'Medium' | 'Hard';
    }>;
  }> {
    return [
      {
        category: 'Daily Habits',
        tips: [
          {
            tip: 'Drink 8-10 glasses of water daily',
            benefit: 'Maintains hydration and kidney function',
            difficulty: 'Easy'
          },
          {
            tip: 'Get 7-8 hours of quality sleep',
            benefit: 'Improves immunity and mental health',
            difficulty: 'Medium'
          },
          {
            tip: 'Exercise for 30 minutes daily',
            benefit: 'Maintains cardiovascular health and weight',
            difficulty: 'Medium'
          },
          {
            tip: 'Eat 5 servings of fruits and vegetables',
            benefit: 'Provides essential nutrients and fiber',
            difficulty: 'Medium'
          }
        ]
      },
      {
        category: 'Preventive Care',
        tips: [
          {
            tip: 'Get annual health checkups',
            benefit: 'Early detection of health issues',
            difficulty: 'Easy'
          },
          {
            tip: 'Keep vaccinations up to date',
            benefit: 'Prevents infectious diseases',
            difficulty: 'Easy'
          },
          {
            tip: 'Regular dental checkups every 6 months',
            benefit: 'Maintains oral health',
            difficulty: 'Easy'
          },
          {
            tip: 'Monitor blood pressure and sugar levels',
            benefit: 'Early detection of diabetes and hypertension',
            difficulty: 'Easy'
          }
        ]
      },
      {
        category: 'Mental Health',
        tips: [
          {
            tip: 'Practice meditation or mindfulness',
            benefit: 'Reduces stress and anxiety',
            difficulty: 'Medium'
          },
          {
            tip: 'Maintain social connections',
            benefit: 'Improves emotional well-being',
            difficulty: 'Easy'
          },
          {
            tip: 'Limit screen time before bed',
            benefit: 'Improves sleep quality',
            difficulty: 'Medium'
          },
          {
            tip: 'Seek help when feeling overwhelmed',
            benefit: 'Prevents mental health deterioration',
            difficulty: 'Hard'
          }
        ]
      },
      {
        category: 'Nutrition',
        tips: [
          {
            tip: 'Limit processed and junk food',
            benefit: 'Reduces risk of chronic diseases',
            difficulty: 'Medium'
          },
          {
            tip: 'Include whole grains in diet',
            benefit: 'Provides sustained energy and fiber',
            difficulty: 'Easy'
          },
          {
            tip: 'Reduce salt and sugar intake',
            benefit: 'Prevents hypertension and diabetes',
            difficulty: 'Medium'
          },
          {
            tip: 'Eat regular, balanced meals',
            benefit: 'Maintains stable blood sugar levels',
            difficulty: 'Easy'
          }
        ]
      }
    ];
  }

  // First aid tips for common emergencies
  getFirstAidTips(): Array<{
    emergency: string;
    steps: string[];
    whenToSeekHelp: string;
    whatNotToDo: string[];
  }> {
    return [
      {
        emergency: 'Heart Attack',
        steps: [
          'Call 108 immediately',
          'Help the person sit down and rest',
          'Loosen tight clothing',
          'Give aspirin if available and not allergic',
          'Be prepared to perform CPR if trained'
        ],
        whenToSeekHelp: 'Immediately - this is a medical emergency',
        whatNotToDo: [
          'Don\'t leave the person alone',
          'Don\'t give food or water',
          'Don\'t wait to see if symptoms improve'
        ]
      },
      {
        emergency: 'Choking',
        steps: [
          'Encourage coughing if person is conscious',
          'Give 5 back blows between shoulder blades',
          'Give 5 abdominal thrusts (Heimlich maneuver)',
          'Alternate between back blows and abdominal thrusts',
          'Call 108 if object doesn\'t dislodge'
        ],
        whenToSeekHelp: 'If the person becomes unconscious or object doesn\'t come out',
        whatNotToDo: [
          'Don\'t hit the back if person is coughing effectively',
          'Don\'t use abdominal thrusts on pregnant women or infants'
        ]
      },
      {
        emergency: 'Severe Bleeding',
        steps: [
          'Apply direct pressure to the wound',
          'Elevate the injured area above heart level',
          'Use clean cloth or bandage',
          'Don\'t remove embedded objects',
          'Call 108 for severe bleeding'
        ],
        whenToSeekHelp: 'If bleeding doesn\'t stop after 10 minutes of direct pressure',
        whatNotToDo: [
          'Don\'t remove blood-soaked bandages',
          'Don\'t apply tourniquet unless trained',
          'Don\'t give aspirin (increases bleeding)'
        ]
      },
      {
        emergency: 'Burns',
        steps: [
          'Cool the burn with running water for 10-20 minutes',
          'Remove jewelry and loose clothing from burned area',
          'Cover with sterile, non-adhesive bandage',
          'Take over-the-counter pain medication',
          'Seek medical attention for severe burns'
        ],
        whenToSeekHelp: 'For burns larger than palm size, on face/hands/genitals, or if blistering occurs',
        whatNotToDo: [
          'Don\'t use ice or very cold water',
          'Don\'t apply butter, oil, or home remedies',
          'Don\'t break blisters'
        ]
      }
    ];
  }
}

// Export singleton instance
export const hospitalService = new HospitalService();