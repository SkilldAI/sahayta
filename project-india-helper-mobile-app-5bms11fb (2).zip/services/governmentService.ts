import { blink } from '@/lib/blink';

export interface GovernmentService {
  id: string;
  userId: string;
  serviceType: string;
  serviceName: string;
  applicationNumber?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'rejected';
  appliedDate: string;
  expectedCompletionDate?: string;
  documentsRequired?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceCategory {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  services: ServiceItem[];
}

export interface ServiceItem {
  id: string;
  name: string;
  description: string;
  documentsRequired: string[];
  processingTime: string;
  fees: string;
  eligibility: string[];
  steps: string[];
  officialUrl?: string;
}

// Government service categories and their services
export const governmentServiceCategories: ServiceCategory[] = [
  {
    id: 'identity',
    title: 'Identity Documents',
    subtitle: 'Aadhaar, PAN, Passport',
    icon: 'FileText',
    color: '#FF6B35',
    services: [
      {
        id: 'aadhaar_new',
        name: 'New Aadhaar Card',
        description: 'Apply for new Aadhaar card enrollment',
        documentsRequired: ['Proof of Identity', 'Proof of Address', 'Date of Birth Proof'],
        processingTime: '90 days',
        fees: 'Free',
        eligibility: ['Indian Resident', 'Any Age'],
        steps: [
          'Visit nearest Aadhaar enrollment center',
          'Fill enrollment form',
          'Provide biometric data',
          'Submit required documents',
          'Collect acknowledgment slip'
        ],
        officialUrl: 'https://uidai.gov.in'
      },
      {
        id: 'aadhaar_update',
        name: 'Update Aadhaar Details',
        description: 'Update demographic or biometric information',
        documentsRequired: ['Existing Aadhaar', 'Supporting Documents for Changes'],
        processingTime: '90 days',
        fees: '₹50 per field',
        eligibility: ['Existing Aadhaar holder'],
        steps: [
          'Visit Aadhaar center or use online portal',
          'Fill update request form',
          'Submit supporting documents',
          'Pay applicable fees',
          'Collect acknowledgment'
        ],
        officialUrl: 'https://uidai.gov.in'
      },
      {
        id: 'pan_new',
        name: 'New PAN Card',
        description: 'Apply for new Permanent Account Number',
        documentsRequired: ['Identity Proof', 'Address Proof', 'Date of Birth Proof'],
        processingTime: '15-20 days',
        fees: '₹110 (Indian address), ₹1020 (Foreign address)',
        eligibility: ['Indian Citizen', 'Foreign National with Indian Income'],
        steps: [
          'Fill Form 49A online or offline',
          'Submit required documents',
          'Pay application fees',
          'Submit application',
          'Track application status'
        ],
        officialUrl: 'https://www.incometax.gov.in'
      },
      {
        id: 'passport_new',
        name: 'New Passport',
        description: 'Apply for fresh Indian passport',
        documentsRequired: ['Birth Certificate', 'Address Proof', 'Identity Proof'],
        processingTime: '30-45 days',
        fees: '₹1500 (36 pages), ₹2000 (60 pages)',
        eligibility: ['Indian Citizen'],
        steps: [
          'Register on Passport Seva portal',
          'Fill online application form',
          'Pay fees and book appointment',
          'Visit PSK with documents',
          'Police verification (if required)'
        ],
        officialUrl: 'https://passportindia.gov.in'
      }
    ]
  },
  {
    id: 'driving',
    title: 'Driving License',
    subtitle: 'Apply, renew, duplicate',
    icon: 'Car',
    color: '#9C27B0',
    services: [
      {
        id: 'dl_new',
        name: 'New Driving License',
        description: 'Apply for fresh driving license',
        documentsRequired: ['Learner License', 'Address Proof', 'Age Proof', 'Medical Certificate'],
        processingTime: '30 days',
        fees: '₹200 (2-wheeler), ₹500 (4-wheeler)',
        eligibility: ['Age 18+ for 2-wheeler', 'Age 20+ for 4-wheeler', 'Valid Learner License'],
        steps: [
          'Obtain learner license first',
          'Practice driving for minimum period',
          'Book slot for driving test',
          'Pass driving test',
          'Submit documents and fees'
        ],
        officialUrl: 'https://parivahan.gov.in'
      },
      {
        id: 'dl_renewal',
        name: 'Renew Driving License',
        description: 'Renew expired or expiring driving license',
        documentsRequired: ['Existing DL', 'Medical Certificate (if above 50)', 'Address Proof'],
        processingTime: '15 days',
        fees: '₹200',
        eligibility: ['Existing DL holder'],
        steps: [
          'Apply before expiry or within 1 year of expiry',
          'Fill renewal form online',
          'Upload required documents',
          'Pay renewal fees',
          'Visit RTO if required'
        ],
        officialUrl: 'https://parivahan.gov.in'
      }
    ]
  },
  {
    id: 'voter',
    title: 'Voter ID',
    subtitle: 'Register, download, corrections',
    icon: 'Vote',
    color: '#4285F4',
    services: [
      {
        id: 'voter_new',
        name: 'New Voter Registration',
        description: 'Register as new voter',
        documentsRequired: ['Age Proof', 'Address Proof', 'Identity Proof'],
        processingTime: '30 days',
        fees: 'Free',
        eligibility: ['Indian Citizen', 'Age 18+', 'Resident of constituency'],
        steps: [
          'Fill Form 6 online or offline',
          'Submit required documents',
          'BLO verification visit',
          'Objection period (if any)',
          'Name inclusion in electoral roll'
        ],
        officialUrl: 'https://voters.eci.gov.in'
      },
      {
        id: 'voter_correction',
        name: 'Voter ID Correction',
        description: 'Correct details in voter ID',
        documentsRequired: ['Existing Voter ID', 'Supporting Documents for Correction'],
        processingTime: '30 days',
        fees: 'Free',
        eligibility: ['Existing voter'],
        steps: [
          'Fill Form 8 for corrections',
          'Submit supporting documents',
          'BLO verification',
          'Approval and update',
          'Download updated EPIC'
        ],
        officialUrl: 'https://voters.eci.gov.in'
      }
    ]
  },
  {
    id: 'schemes',
    title: 'Government Schemes',
    subtitle: 'PM-KISAN, Ayushman Bharat',
    icon: 'Gift',
    color: '#FF9800',
    services: [
      {
        id: 'pm_kisan',
        name: 'PM-KISAN Scheme',
        description: 'Income support for small and marginal farmers',
        documentsRequired: ['Aadhaar', 'Bank Account Details', 'Land Records'],
        processingTime: '30-60 days',
        fees: 'Free',
        eligibility: ['Small/Marginal Farmer', 'Landholding up to 2 hectares'],
        steps: [
          'Visit PM-KISAN portal or CSC',
          'Fill registration form',
          'Upload required documents',
          'Aadhaar authentication',
          'Bank account verification'
        ],
        officialUrl: 'https://pmkisan.gov.in'
      },
      {
        id: 'ayushman_bharat',
        name: 'Ayushman Bharat',
        description: 'Health insurance scheme for poor families',
        documentsRequired: ['Aadhaar', 'Ration Card', 'SECC Database Verification'],
        processingTime: 'Immediate (if eligible)',
        fees: 'Free',
        eligibility: ['SECC 2011 beneficiary', 'Rural/Urban poor families'],
        steps: [
          'Check eligibility online',
          'Visit nearest CSC or hospital',
          'Aadhaar authentication',
          'Generate e-card',
          'Start using benefits'
        ],
        officialUrl: 'https://pmjay.gov.in'
      }
    ]
  }
];

export class GovernmentServiceManager {
  // Get user's government service applications
  static async getUserApplications(userId: string): Promise<GovernmentService[]> {
    try {
      const applications = await blink.db.governmentServices.list({
        where: { userId },
        orderBy: { createdAt: 'desc' },
      });
      return applications as GovernmentService[];
    } catch (error) {
      console.error('Error fetching user applications:', error);
      throw new Error('Failed to fetch applications');
    }
  }

  // Submit new government service application
  static async submitApplication(applicationData: Omit<GovernmentService, 'id' | 'createdAt' | 'updatedAt'>): Promise<GovernmentService> {
    try {
      const newApplication = await blink.db.governmentServices.create({
        id: `gov_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...applicationData,
        applicationNumber: this.generateApplicationNumber(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      return newApplication as GovernmentService;
    } catch (error) {
      console.error('Error submitting application:', error);
      throw new Error('Failed to submit application');
    }
  }

  // Update application status
  static async updateApplicationStatus(applicationId: string, status: string, notes?: string): Promise<GovernmentService> {
    try {
      const updatedApplication = await blink.db.governmentServices.update(applicationId, {
        status,
        notes,
        updatedAt: new Date().toISOString(),
      });
      return updatedApplication as GovernmentService;
    } catch (error) {
      console.error('Error updating application status:', error);
      throw new Error('Failed to update application');
    }
  }

  // Get applications by status
  static async getApplicationsByStatus(userId: string, status: string): Promise<GovernmentService[]> {
    try {
      const applications = await blink.db.governmentServices.list({
        where: { 
          userId,
          status 
        },
        orderBy: { createdAt: 'desc' },
      });
      return applications as GovernmentService[];
    } catch (error) {
      console.error('Error fetching applications by status:', error);
      throw new Error('Failed to fetch applications');
    }
  }

  // Delete application
  static async deleteApplication(applicationId: string): Promise<void> {
    try {
      await blink.db.governmentServices.delete(applicationId);
    } catch (error) {
      console.error('Error deleting application:', error);
      throw new Error('Failed to delete application');
    }
  }

  // Get service details by ID
  static getServiceById(serviceId: string): ServiceItem | null {
    for (const category of governmentServiceCategories) {
      const service = category.services.find(s => s.id === serviceId);
      if (service) return service;
    }
    return null;
  }

  // Get services by category
  static getServicesByCategory(categoryId: string): ServiceItem[] {
    const category = governmentServiceCategories.find(c => c.id === categoryId);
    return category ? category.services : [];
  }

  // Generate application number
  private static generateApplicationNumber(): string {
    const prefix = 'GOV';
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}${timestamp}${random}`;
  }

  // Simulate application status check (in real app, this would call government APIs)
  static async checkApplicationStatus(applicationNumber: string): Promise<{
    status: string;
    lastUpdated: string;
    remarks?: string;
  }> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Generate mock status
    const statuses = ['pending', 'in_progress', 'completed', 'rejected'];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
    
    return {
      status: randomStatus,
      lastUpdated: new Date().toISOString(),
      remarks: randomStatus === 'rejected' ? 'Document verification failed' : 
               randomStatus === 'completed' ? 'Application approved successfully' :
               'Application is being processed'
    };
  }

  // Get required documents for a service
  static getRequiredDocuments(serviceId: string): string[] {
    const service = this.getServiceById(serviceId);
    return service ? service.documentsRequired : [];
  }

  // Get processing time for a service
  static getProcessingTime(serviceId: string): string {
    const service = this.getServiceById(serviceId);
    return service ? service.processingTime : 'Not available';
  }

  // Get fees for a service
  static getFees(serviceId: string): string {
    const service = this.getServiceById(serviceId);
    return service ? service.fees : 'Not available';
  }
}