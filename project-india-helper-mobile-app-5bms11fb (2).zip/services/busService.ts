export interface BusSearchResult {
  busOperator: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  fare: number;
  seatsAvailable: number;
  amenities: string[];
  rating: number;
  boardingPoints: string[];
  droppingPoints: string[];
}

export interface BusOperator {
  name: string;
  routes: string[];
  rating: number;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

export class BusService {
  private async makeRequest(action: string, data: any): Promise<any> {
    try {
      const response = await fetch(`${SCRAPER_URL}?service=bus&action=${action}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Request failed');
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Scraping failed');
      }

      return result.data;
    } catch (error) {
      console.error(`Bus Service Error (${action}):`, error);
      throw error;
    }
  }

  async searchBuses(from: string, to: string, date: string): Promise<BusSearchResult[]> {
    if (!from || !to || !date) {
      throw new Error('From, to, and date are required');
    }

    return await this.makeRequest('search', { from, to, date });
  }

  async getBusOperators(): Promise<BusOperator[]> {
    return await this.makeRequest('operators', {});
  }

  // Utility methods
  validateRoute(from: string, to: string): boolean {
    return from.trim().length > 0 && to.trim().length > 0 && from !== to;
  }

  validateDate(date: string): boolean {
    const selectedDate = new Date(date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return selectedDate >= today;
  }

  formatDate(date: Date): string {
    return date.toISOString().split('T')[0];
  }

  // Popular bus routes in India
  getPopularRoutes(): Array<{ from: string; to: string; duration: string }> {
    return [
      { from: "Bangalore", to: "Chennai", duration: "7h" },
      { from: "Mumbai", to: "Pune", duration: "3h" },
      { from: "Delhi", to: "Jaipur", duration: "5h" },
      { from: "Hyderabad", to: "Bangalore", duration: "8h" },
      { from: "Bangalore", to: "Goa", duration: "12h" },
      { from: "Chennai", to: "Coimbatore", duration: "6h" },
      { from: "Mumbai", to: "Goa", duration: "10h" },
      { from: "Delhi", to: "Chandigarh", duration: "4h" },
      { from: "Kolkata", to: "Bhubaneswar", duration: "6h" },
      { from: "Ahmedabad", to: "Mumbai", duration: "8h" }
    ];
  }

  // Bus types and their features
  getBusTypes(): Array<{ type: string; features: string[]; priceRange: string }> {
    return [
      {
        type: "AC Sleeper (2+1)",
        features: ["Air Conditioning", "Individual Berths", "Blanket", "Pillow", "Charging Point"],
        priceRange: "₹800-1500"
      },
      {
        type: "Non-AC Sleeper (2+1)",
        features: ["Individual Berths", "Blanket", "Pillow", "Charging Point"],
        priceRange: "₹500-900"
      },
      {
        type: "AC Seater (2+2)",
        features: ["Air Conditioning", "Pushback Seats", "Charging Point", "Water Bottle"],
        priceRange: "₹400-800"
      },
      {
        type: "Non-AC Seater (2+2)",
        features: ["Pushback Seats", "Charging Point"],
        priceRange: "₹200-500"
      },
      {
        type: "Volvo Multi-Axle",
        features: ["Premium AC", "Extra Legroom", "Entertainment", "Snacks"],
        priceRange: "₹1000-2000"
      }
    ];
  }

  // Major bus operators in India
  getMajorOperators(): Array<{ name: string; coverage: string[]; speciality: string }> {
    return [
      {
        name: "VRL Travels",
        coverage: ["Karnataka", "Goa", "Maharashtra", "Andhra Pradesh"],
        speciality: "Luxury sleeper buses"
      },
      {
        name: "SRS Travels",
        coverage: ["Karnataka", "Tamil Nadu", "Andhra Pradesh", "Kerala"],
        speciality: "Multi-axle Volvo buses"
      },
      {
        name: "Orange Travels",
        coverage: ["South India", "Maharashtra"],
        speciality: "Premium AC services"
      },
      {
        name: "KSRTC",
        coverage: ["Karnataka", "Kerala", "Tamil Nadu"],
        speciality: "State transport with Airavat services"
      },
      {
        name: "APSRTC",
        coverage: ["Andhra Pradesh", "Telangana"],
        speciality: "Garuda and Indra services"
      },
      {
        name: "TNSTC",
        coverage: ["Tamil Nadu", "Karnataka", "Kerala"],
        speciality: "State transport services"
      }
    ];
  }

  // Booking tips
  getBookingTips(): string[] {
    return [
      "Book in advance for better prices and seat selection",
      "Check cancellation policy before booking",
      "Verify boarding point location and timing",
      "Keep a copy of your ticket (digital or physical)",
      "Arrive at boarding point 15 minutes early",
      "Check bus operator reviews and ratings",
      "Consider travel insurance for long journeys",
      "Pack light snacks and water for the journey",
      "Keep emergency contact numbers handy",
      "Check if the bus has GPS tracking facility"
    ];
  }
}

// Export singleton instance
export const busService = new BusService();