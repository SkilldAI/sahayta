export interface ATM {
  id: string;
  bank: string;
  name?: string;
  address: string;
  city: string;
  state: string;
  pincode?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  isOpen24Hours?: boolean;
  services?: string[]; // e.g., cash deposit, cardless, currency exchange
  contactNumber?: string;
  rating?: number;
}

const SCRAPER_URL = 'https://5bms11fb--universal-scraper.functions.blink.new';

class ATMService {
  private async makeRequest(action: string, data: any): Promise<any> {
    const response = await fetch(`${SCRAPER_URL}?service=atm&action=${action}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'ATM request failed');
    }
    const result = await response.json();
    if (!result.success) throw new Error(result.error || 'ATM scraping failed');
    return result.data;
  }

  async searchATMs(location: string, bank?: string): Promise<ATM[]> {
    if (!location) throw new Error('Location is required');
    return this.makeRequest('search', { location, bank });
  }

  async getNearbyATMs(latitude: number, longitude: number, radius: number = 5): Promise<ATM[]> {
    if (!latitude || !longitude) throw new Error('Latitude and longitude are required');
    return this.makeRequest('nearby', { latitude, longitude, radius });
  }
}

export const atmService = new ATMService();
