import { blink } from '@/lib/blink';

export interface Bill {
  id: string;
  userId: string;
  billType: string;
  providerName: string;
  accountNumber?: string;
  amount: string;
  dueDate: string;
  paymentStatus: 'pending' | 'paid' | 'overdue';
  paymentDate?: string;
  paymentMethod?: string;
  reminderEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface BillProvider {
  id: string;
  name: string;
  type: string;
  logo?: string;
  supportedStates: string[];
}

// Sample bill providers for different utilities
export const billProviders: Record<string, BillProvider[]> = {
  electricity: [
    { id: 'bescom', name: 'BESCOM', type: 'electricity', supportedStates: ['Karnataka'] },
    { id: 'msedcl', name: 'MSEDCL', type: 'electricity', supportedStates: ['Maharashtra'] },
    { id: 'tneb', name: 'TNEB', type: 'electricity', supportedStates: ['Tamil Nadu'] },
    { id: 'wbsedcl', name: 'WBSEDCL', type: 'electricity', supportedStates: ['West Bengal'] },
    { id: 'pspcl', name: 'PSPCL', type: 'electricity', supportedStates: ['Punjab'] },
  ],
  water: [
    { id: 'bwssb', name: 'BWSSB', type: 'water', supportedStates: ['Karnataka'] },
    { id: 'bmc_water', name: 'BMC Water', type: 'water', supportedStates: ['Maharashtra'] },
    { id: 'djb', name: 'Delhi Jal Board', type: 'water', supportedStates: ['Delhi'] },
    { id: 'hmwssb', name: 'HMWSSB', type: 'water', supportedStates: ['Telangana'] },
  ],
  gas: [
    { id: 'indane', name: 'Indane Gas', type: 'gas', supportedStates: ['All'] },
    { id: 'bharat_gas', name: 'Bharat Gas', type: 'gas', supportedStates: ['All'] },
    { id: 'hp_gas', name: 'HP Gas', type: 'gas', supportedStates: ['All'] },
    { id: 'reliance_gas', name: 'Reliance Gas', type: 'gas', supportedStates: ['All'] },
  ],
  mobile: [
    { id: 'airtel', name: 'Airtel', type: 'mobile', supportedStates: ['All'] },
    { id: 'jio', name: 'Jio', type: 'mobile', supportedStates: ['All'] },
    { id: 'vi', name: 'Vi (Vodafone Idea)', type: 'mobile', supportedStates: ['All'] },
    { id: 'bsnl', name: 'BSNL', type: 'mobile', supportedStates: ['All'] },
  ],
  broadband: [
    { id: 'airtel_fiber', name: 'Airtel Fiber', type: 'broadband', supportedStates: ['All'] },
    { id: 'jio_fiber', name: 'Jio Fiber', type: 'broadband', supportedStates: ['All'] },
    { id: 'act', name: 'ACT Fibernet', type: 'broadband', supportedStates: ['Karnataka', 'Telangana', 'Tamil Nadu'] },
    { id: 'hathway', name: 'Hathway', type: 'broadband', supportedStates: ['Maharashtra', 'Gujarat'] },
  ],
  dth: [
    { id: 'tata_sky', name: 'Tata Play', type: 'dth', supportedStates: ['All'] },
    { id: 'airtel_dth', name: 'Airtel Digital TV', type: 'dth', supportedStates: ['All'] },
    { id: 'dish_tv', name: 'Dish TV', type: 'dth', supportedStates: ['All'] },
    { id: 'sun_direct', name: 'Sun Direct', type: 'dth', supportedStates: ['All'] },
  ],
};

export class BillService {
  // Get user's bills
  static async getUserBills(userId: string): Promise<Bill[]> {
    try {
      const bills = await blink.db.bills.list({
        where: { userId },
        orderBy: { dueDate: 'asc' },
      });
      return bills as Bill[];
    } catch (error) {
      console.error('Error fetching user bills:', error);
      throw new Error('Failed to fetch bills');
    }
  }

  // Add a new bill
  static async addBill(billData: Omit<Bill, 'id' | 'createdAt' | 'updatedAt'>): Promise<Bill> {
    try {
      const newBill = await blink.db.bills.create({
        id: `bill_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...billData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      return newBill as Bill;
    } catch (error) {
      console.error('Error adding bill:', error);
      throw new Error('Failed to add bill');
    }
  }

  // Update bill payment status
  static async payBill(billId: string, paymentMethod: string): Promise<Bill> {
    try {
      const updatedBill = await blink.db.bills.update(billId, {
        paymentStatus: 'paid',
        paymentDate: new Date().toISOString(),
        paymentMethod,
        updatedAt: new Date().toISOString(),
      });
      return updatedBill as Bill;
    } catch (error) {
      console.error('Error updating bill payment:', error);
      throw new Error('Failed to process payment');
    }
  }

  // Get bills by status
  static async getBillsByStatus(userId: string, status: string): Promise<Bill[]> {
    try {
      const bills = await blink.db.bills.list({
        where: { 
          userId,
          paymentStatus: status 
        },
        orderBy: { dueDate: 'asc' },
      });
      return bills as Bill[];
    } catch (error) {
      console.error('Error fetching bills by status:', error);
      throw new Error('Failed to fetch bills');
    }
  }

  // Get overdue bills
  static async getOverdueBills(userId: string): Promise<Bill[]> {
    try {
      const today = new Date().toISOString().split('T')[0];
      const bills = await blink.db.bills.list({
        where: { userId },
        orderBy: { dueDate: 'asc' },
      });
      
      // Filter overdue bills on client side
      const overdueBills = bills.filter((bill: any) => {
        return bill.paymentStatus === 'pending' && bill.dueDate < today;
      });
      
      return overdueBills as Bill[];
    } catch (error) {
      console.error('Error fetching overdue bills:', error);
      throw new Error('Failed to fetch overdue bills');
    }
  }

  // Delete a bill
  static async deleteBill(billId: string): Promise<void> {
    try {
      await blink.db.bills.delete(billId);
    } catch (error) {
      console.error('Error deleting bill:', error);
      throw new Error('Failed to delete bill');
    }
  }

  // Get providers by type
  static getProvidersByType(type: string): BillProvider[] {
    return billProviders[type] || [];
  }

  // Simulate bill fetch from provider (in real app, this would call actual APIs)
  static async fetchBillDetails(providerName: string, accountNumber: string): Promise<{
    amount: string;
    dueDate: string;
    billNumber: string;
  }> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Generate mock bill data
    const amount = (Math.random() * 5000 + 500).toFixed(2);
    const dueDate = new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const billNumber = `BILL${Date.now()}${Math.floor(Math.random() * 1000)}`;
    
    return {
      amount,
      dueDate,
      billNumber,
    };
  }

  // Process payment (in real app, integrate with payment gateway)
  static async processPayment(billId: string, amount: string, paymentMethod: string): Promise<{
    success: boolean;
    transactionId?: string;
    message: string;
  }> {
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate 95% success rate
    const success = Math.random() > 0.05;
    
    if (success) {
      const transactionId = `TXN${Date.now()}${Math.floor(Math.random() * 10000)}`;
      await this.payBill(billId, paymentMethod);
      
      return {
        success: true,
        transactionId,
        message: 'Payment processed successfully',
      };
    } else {
      return {
        success: false,
        message: 'Payment failed. Please try again.',
      };
    }
  }
}