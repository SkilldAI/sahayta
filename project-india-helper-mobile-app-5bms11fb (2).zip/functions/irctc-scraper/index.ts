import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

interface PNRStatusResponse {
  pnrNumber: string;
  trainNumber: string;
  trainName: string;
  dateOfJourney: string;
  from: string;
  to: string;
  boardingPoint: string;
  reservationUpto: string;
  passengers: Array<{
    passengerNumber: number;
    bookingStatus: string;
    currentStatus: string;
    coach: string;
    berth: string;
  }>;
  chartStatus: string;
  distance: string;
  quota: string;
}

interface TrainScheduleResponse {
  trainNumber: string;
  trainName: string;
  stations: Array<{
    stationCode: string;
    stationName: string;
    arrivalTime: string;
    departureTime: string;
    haltTime: string;
    distance: string;
    day: number;
  }>;
}

interface SeatAvailabilityResponse {
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  date: string;
  classes: Array<{
    className: string;
    classCode: string;
    availability: string;
    fare: string;
  }>;
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    switch (action) {
      case 'pnr-status':
        return await handlePNRStatus(req);
      case 'train-schedule':
        return await handleTrainSchedule(req);
      case 'seat-availability':
        return await handleSeatAvailability(req);
      case 'train-search':
        return await handleTrainSearch(req);
      default:
        return new Response(JSON.stringify({ error: 'Invalid action' }), {
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
        });
    }
  } catch (error) {
    console.error('IRCTC Scraper Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      message: error.message 
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
});

async function handlePNRStatus(req: Request): Promise<Response> {
  const { pnrNumber } = await req.json();
  
  if (!pnrNumber || pnrNumber.length !== 10) {
    return new Response(JSON.stringify({ 
      error: 'Invalid PNR number. Must be 10 digits.' 
    }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    // Use IRCTC's PNR status API endpoint
    const response = await fetch('https://www.irctc.co.in/eticketing/protected/mapps01/pnrstatusEnq', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.irctc.co.in/',
        'Accept': 'application/json, text/plain, */*',
      },
      body: JSON.stringify({
        pnrNumber: pnrNumber,
        captcha: '', // IRCTC sometimes requires captcha, we'll handle this
      }),
    });

    if (!response.ok) {
      // Fallback to web scraping if API fails
      return await scrapePNRStatus(pnrNumber);
    }

    const data = await response.json();
    
    const pnrStatus: PNRStatusResponse = {
      pnrNumber: data.pnrNumber || pnrNumber,
      trainNumber: data.trainNumber || '',
      trainName: data.trainName || '',
      dateOfJourney: data.dateOfJourney || '',
      from: data.fromStation || '',
      to: data.toStation || '',
      boardingPoint: data.boardingPoint || '',
      reservationUpto: data.reservationUpto || '',
      passengers: data.passengerList?.map((p: any, index: number) => ({
        passengerNumber: index + 1,
        bookingStatus: p.bookingStatusDetails || '',
        currentStatus: p.currentStatusDetails || '',
        coach: p.coach || '',
        berth: p.berth || '',
      })) || [],
      chartStatus: data.chartStatus || '',
      distance: data.distance || '',
      quota: data.quota || '',
    };

    return new Response(JSON.stringify(pnrStatus), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (error) {
    console.error('PNR Status Error:', error);
    return await scrapePNRStatus(pnrNumber);
  }
}

async function scrapePNRStatus(pnrNumber: string): Promise<Response> {
  try {
    // Scrape from alternative PNR checking websites
    const response = await fetch(`https://www.trainman.in/pnr/${pnrNumber}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    const html = await response.text();
    
    // Parse HTML to extract PNR information
    // This is a simplified parser - in production, you'd use a proper HTML parser
    const pnrStatus: PNRStatusResponse = {
      pnrNumber,
      trainNumber: extractFromHTML(html, 'train-number') || '',
      trainName: extractFromHTML(html, 'train-name') || '',
      dateOfJourney: extractFromHTML(html, 'journey-date') || '',
      from: extractFromHTML(html, 'from-station') || '',
      to: extractFromHTML(html, 'to-station') || '',
      boardingPoint: extractFromHTML(html, 'boarding-point') || '',
      reservationUpto: extractFromHTML(html, 'reservation-upto') || '',
      passengers: [], // Would parse passenger details from HTML
      chartStatus: extractFromHTML(html, 'chart-status') || '',
      distance: extractFromHTML(html, 'distance') || '',
      quota: extractFromHTML(html, 'quota') || '',
    };

    return new Response(JSON.stringify(pnrStatus), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (error) {
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch PNR status',
      message: 'Please try again later or check your PNR number'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
}

async function handleTrainSchedule(req: Request): Promise<Response> {
  const { trainNumber } = await req.json();
  
  if (!trainNumber) {
    return new Response(JSON.stringify({ 
      error: 'Train number is required' 
    }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    // Scrape train schedule from IRCTC or alternative sources
    const response = await fetch(`https://www.irctc.co.in/eticketing/protected/mapps01/altAvlEnq/${trainNumber}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.irctc.co.in/',
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch train schedule');
    }

    const data = await response.json();
    
    const schedule: TrainScheduleResponse = {
      trainNumber: data.trainNumber || trainNumber,
      trainName: data.trainName || '',
      stations: data.stationList?.map((station: any) => ({
        stationCode: station.stationCode || '',
        stationName: station.stationName || '',
        arrivalTime: station.arrivalTime || '',
        departureTime: station.departureTime || '',
        haltTime: station.haltTime || '',
        distance: station.distance || '',
        day: station.day || 1,
      })) || [],
    };

    return new Response(JSON.stringify(schedule), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (error) {
    console.error('Train Schedule Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch train schedule',
      message: 'Please check the train number and try again'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
}

async function handleSeatAvailability(req: Request): Promise<Response> {
  const { trainNumber, from, to, date, classType } = await req.json();
  
  if (!trainNumber || !from || !to || !date) {
    return new Response(JSON.stringify({ 
      error: 'Train number, from, to, and date are required' 
    }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    // Format date for IRCTC API
    const formattedDate = new Date(date).toISOString().split('T')[0];
    
    const response = await fetch('https://www.irctc.co.in/eticketing/protected/mapps01/altAvlEnq', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.irctc.co.in/',
      },
      body: JSON.stringify({
        trainNumber,
        fromStnCode: from,
        toStnCode: to,
        journeyDate: formattedDate,
        classType: classType || 'ALL',
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch seat availability');
    }

    const data = await response.json();
    
    const availability: SeatAvailabilityResponse = {
      trainNumber: data.trainNumber || trainNumber,
      trainName: data.trainName || '',
      from: data.fromStation || from,
      to: data.toStation || to,
      date: formattedDate,
      classes: data.avlDayList?.[0]?.availablityList?.map((cls: any) => ({
        className: cls.className || '',
        classCode: cls.classCode || '',
        availability: cls.availablityStatus || '',
        fare: cls.fare || '',
      })) || [],
    };

    return new Response(JSON.stringify(availability), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (error) {
    console.error('Seat Availability Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch seat availability',
      message: 'Please check your search parameters and try again'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
}

async function handleTrainSearch(req: Request): Promise<Response> {
  const { from, to, date } = await req.json();
  
  if (!from || !to || !date) {
    return new Response(JSON.stringify({ 
      error: 'From, to, and date are required' 
    }), {
      status: 400,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }

  try {
    const formattedDate = new Date(date).toISOString().split('T')[0];
    
    const response = await fetch('https://www.irctc.co.in/eticketing/protected/mapps01/trainbtwstn', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.irctc.co.in/',
      },
      body: JSON.stringify({
        fromStnCode: from,
        toStnCode: to,
        journeyDate: formattedDate,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to search trains');
    }

    const data = await response.json();
    
    return new Response(JSON.stringify(data), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (error) {
    console.error('Train Search Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to search trains',
      message: 'Please check your search parameters and try again'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
}

// Helper function to extract data from HTML
function extractFromHTML(html: string, selector: string): string | null {
  // This is a simplified HTML parser
  // In production, you'd use a proper HTML parsing library
  const regex = new RegExp(`class="${selector}"[^>]*>([^<]+)<`, 'i');
  const match = html.match(regex);
  return match ? match[1].trim() : null;
}