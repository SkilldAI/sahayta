import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "npm:@blinkdotnew/sdk";

// Initialize Blink client for database operations
const blink = createClient({
  projectId: Deno.env.get('BLINK_PROJECT_ID') || 'india-helper-mobile-app-5bms11fb',
  authRequired: false
});

interface ApiSetuRequest {
  service: string;
  action: string;
  data: any;
  userId?: string;
}

interface ApiSetuResponse {
  success: boolean;
  data?: any;
  error?: string;
  source: 'api_setu' | 'mock';
}

serve(async (req) => {
  // Handle CORS for frontend calls
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  try {
    const requestData: ApiSetuRequest = await req.json();
    const { service, action, data, userId } = requestData;

    console.log(`API Setu request: ${service}/${action}`, data);

    let result: ApiSetuResponse;

    // Route to specific API Setu services
    switch (service) {
      case 'pan_verification':
        result = await handlePANVerification(action, data);
        break;
      case 'driving_license':
        result = await handleDrivingLicenseVerification(action, data);
        break;
      case 'vehicle_registration':
        result = await handleVehicleRegistration(action, data);
        break;
      case 'epfo_services':
        result = await handleEPFOServices(action, data);
        break;
      case 'government_schemes':
        result = await handleGovernmentSchemes(action, data);
        break;
      case 'utility_bills':
        result = await handleUtilityBills(action, data);
        break;
      default:
        result = {
          success: false,
          error: `Service '${service}' not found`,
          source: 'mock'
        };
    }

    // Log the API call to database for analytics
    if (userId) {
      await logApiCall(userId, service, action, result.success);
    }

    return new Response(JSON.stringify(result), {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });

  } catch (error) {
    console.error('API Setu integration error:', error);
    
    return new Response(JSON.stringify({
      success: false,
      error: 'Internal server error',
      source: 'mock'
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  }
});

// PAN Verification Service
async function handlePANVerification(action: string, data: any): Promise<ApiSetuResponse> {
  const apiSetuToken = Deno.env.get('API_SETU_TOKEN');
  const panApiKey = Deno.env.get('PAN_API_KEY');

  if (!apiSetuToken || !panApiKey) {
    console.log('API Setu credentials not found, using mock data');
    return getMockPANResponse(data);
  }

  try {
    switch (action) {
      case 'verify':
        const response = await fetch('https://api.apisetu.gov.in/certificate/v3/pan', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiSetuToken}`,
            'X-API-Key': panApiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            txnId: generateTransactionId(),
            format: 'json',
            certificateParameters: {
              pan: data.panNumber,
              name: data.name || '',
              dob: data.dob || ''
            },
            consentArtifact: {
              consent: 'Y'
            }
          })
        });

        if (response.ok) {
          const result = await response.json();
          return {
            success: true,
            data: {
              panNumber: result.certificateParameters?.pan,
              name: result.certificateParameters?.name,
              isValid: result.status === 'VALID',
              verificationDate: new Date().toISOString(),
              source: 'Income Tax Department'
            },
            source: 'api_setu'
          };
        } else {
          console.log('API Setu PAN verification failed, using mock data');
          return getMockPANResponse(data);
        }

      default:
        return {
          success: false,
          error: `Action '${action}' not supported for PAN verification`,
          source: 'mock'
        };
    }
  } catch (error) {
    console.error('PAN verification error:', error);
    return getMockPANResponse(data);
  }
}

// Driving License Verification Service
async function handleDrivingLicenseVerification(action: string, data: any): Promise<ApiSetuResponse> {
  const apiSetuToken = Deno.env.get('API_SETU_TOKEN');
  const dlApiKey = Deno.env.get('DRIVING_LICENSE_API_KEY');

  if (!apiSetuToken || !dlApiKey) {
    console.log('Driving License API credentials not found, using mock data');
    return getMockDLResponse(data);
  }

  try {
    switch (action) {
      case 'verify':
        const response = await fetch('https://api.apisetu.gov.in/certificate/v3/dl', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiSetuToken}`,
            'X-API-Key': dlApiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            txnId: generateTransactionId(),
            format: 'json',
            certificateParameters: {
              dlno: data.licenseNumber,
              dob: data.dob
            },
            consentArtifact: {
              consent: 'Y'
            }
          })
        });

        if (response.ok) {
          const result = await response.json();
          return {
            success: true,
            data: {
              licenseNumber: result.certificateParameters?.dlno,
              name: result.certificateParameters?.name,
              isValid: result.status === 'VALID',
              expiryDate: result.certificateParameters?.validity_upto,
              vehicleClass: result.certificateParameters?.cov_category,
              verificationDate: new Date().toISOString(),
              source: 'Ministry of Road Transport and Highways'
            },
            source: 'api_setu'
          };
        } else {
          console.log('API Setu DL verification failed, using mock data');
          return getMockDLResponse(data);
        }

      default:
        return {
          success: false,
          error: `Action '${action}' not supported for driving license verification`,
          source: 'mock'
        };
    }
  } catch (error) {
    console.error('Driving license verification error:', error);
    return getMockDLResponse(data);
  }
}

// Vehicle Registration Service
async function handleVehicleRegistration(action: string, data: any): Promise<ApiSetuResponse> {
  const apiSetuToken = Deno.env.get('API_SETU_TOKEN');
  const vehicleApiKey = Deno.env.get('VEHICLE_API_KEY');

  if (!apiSetuToken || !vehicleApiKey) {
    console.log('Vehicle Registration API credentials not found, using mock data');
    return getMockVehicleResponse(data);
  }

  try {
    switch (action) {
      case 'verify':
        const response = await fetch('https://api.apisetu.gov.in/certificate/v3/rc', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiSetuToken}`,
            'X-API-Key': vehicleApiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            txnId: generateTransactionId(),
            format: 'json',
            certificateParameters: {
              rc_number: data.registrationNumber
            },
            consentArtifact: {
              consent: 'Y'
            }
          })
        });

        if (response.ok) {
          const result = await response.json();
          return {
            success: true,
            data: {
              registrationNumber: result.certificateParameters?.rc_number,
              ownerName: result.certificateParameters?.owner_name,
              vehicleClass: result.certificateParameters?.vehicle_class,
              fuelType: result.certificateParameters?.fuel_type,
              registrationDate: result.certificateParameters?.registration_date,
              isValid: result.status === 'VALID',
              verificationDate: new Date().toISOString(),
              source: 'Ministry of Road Transport and Highways'
            },
            source: 'api_setu'
          };
        } else {
          console.log('API Setu Vehicle verification failed, using mock data');
          return getMockVehicleResponse(data);
        }

      default:
        return {
          success: false,
          error: `Action '${action}' not supported for vehicle registration`,
          source: 'mock'
        };
    }
  } catch (error) {
    console.error('Vehicle registration verification error:', error);
    return getMockVehicleResponse(data);
  }
}

// EPFO Services
async function handleEPFOServices(action: string, data: any): Promise<ApiSetuResponse> {
  // Mock implementation for now - will be updated when EPFO APIs are available
  return {
    success: true,
    data: {
      uanNumber: data.uanNumber,
      name: 'John Doe',
      pfBalance: '₹1,25,000',
      lastContribution: '₹2,500',
      employerName: 'Tech Solutions Pvt Ltd',
      status: 'Active',
      verificationDate: new Date().toISOString(),
      source: 'EPFO'
    },
    source: 'mock'
  };
}

// Government Schemes
async function handleGovernmentSchemes(action: string, data: any): Promise<ApiSetuResponse> {
  // Mock implementation for now
  return {
    success: true,
    data: {
      schemes: [
        {
          name: 'Pradhan Mantri Jan Dhan Yojana',
          status: 'Eligible',
          description: 'Financial inclusion program'
        },
        {
          name: 'Ayushman Bharat',
          status: 'Applied',
          description: 'Health insurance scheme'
        }
      ],
      verificationDate: new Date().toISOString()
    },
    source: 'mock'
  };
}

// Utility Bills
async function handleUtilityBills(action: string, data: any): Promise<ApiSetuResponse> {
  // Mock implementation for now
  return {
    success: true,
    data: {
      billType: data.billType,
      amount: '₹1,250',
      dueDate: '2024-09-15',
      status: 'Pending',
      consumerNumber: data.consumerNumber,
      verificationDate: new Date().toISOString()
    },
    source: 'mock'
  };
}

// Mock Response Functions
function getMockPANResponse(data: any): ApiSetuResponse {
  return {
    success: true,
    data: {
      panNumber: data.panNumber,
      name: 'RAJESH KUMAR',
      isValid: true,
      verificationDate: new Date().toISOString(),
      source: 'Mock Data - Income Tax Department'
    },
    source: 'mock'
  };
}

function getMockDLResponse(data: any): ApiSetuResponse {
  return {
    success: true,
    data: {
      licenseNumber: data.licenseNumber,
      name: 'RAJESH KUMAR',
      isValid: true,
      expiryDate: '2028-12-31',
      vehicleClass: 'LMV',
      verificationDate: new Date().toISOString(),
      source: 'Mock Data - Ministry of Road Transport and Highways'
    },
    source: 'mock'
  };
}

function getMockVehicleResponse(data: any): ApiSetuResponse {
  return {
    success: true,
    data: {
      registrationNumber: data.registrationNumber,
      ownerName: 'RAJESH KUMAR',
      vehicleClass: 'Motor Car',
      fuelType: 'Petrol',
      registrationDate: '2020-05-15',
      isValid: true,
      verificationDate: new Date().toISOString(),
      source: 'Mock Data - Ministry of Road Transport and Highways'
    },
    source: 'mock'
  };
}

// Utility Functions
function generateTransactionId(): string {
  return 'TXN' + Date.now() + Math.random().toString(36).substr(2, 9);
}

async function logApiCall(userId: string, service: string, action: string, success: boolean) {
  try {
    await blink.db.apiCallLogs.create({
      userId,
      service,
      action,
      success: success ? '1' : '0',
      timestamp: new Date().toISOString(),
      source: 'api_setu_integration'
    });
  } catch (error) {
    console.error('Failed to log API call:', error);
  }
}