import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

// Base interfaces for all scrapers
interface ScraperResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
  source: string;
}

interface BusSearchResult {
  busOperator: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  fare: number;
  seatsAvailable: number;
  amenities: string[];
  rating: number;
  boardingPoints: string[];
  droppingPoints: string[];
}

interface FlightInfo {
  flightNumber: string;
  airline: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  status: string;
  gate?: string;
  terminal?: string;
  delay?: string | null;
}

interface UtilityBillInfo {
  provider: string;
  accountNumber: string;
  billAmount: number;
  dueDate: string;
  billDate: string;
  unitsConsumed?: number;
  previousReading?: number;
  currentReading?: number;
  tariffRate?: number;
}

interface HotelInfo {
  name: string;
  location: string;
  rating: number;
  pricePerNight: number;
  amenities: string[];
  images: string[];
  availability: boolean;
  roomTypes: string[];
}

// New: Local services data types (kept lightweight for mock data)
interface Coordinates { latitude: number; longitude: number }

interface HospitalItem {
  id: string;
  name: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  coordinates?: Coordinates;
  contactInfo?: { phone?: string; emergency?: string; email?: string };
}

interface ATMItem {
  id: string;
  bank: string;
  name?: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  coordinates?: Coordinates;
  isOpen24Hours?: boolean;
  contactNumber?: string;
  rating?: number;
}

interface PharmacyItem {
  id: string;
  name: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  coordinates?: Coordinates;
  phone?: string;
  isOpen24Hours?: boolean;
  rating?: number;
}

interface PetrolPumpItem {
  id: string;
  name: string;
  brand: string;
  address: string;
  city: string;
  state?: string;
  pincode?: string;
  coordinates?: Coordinates;
  facilities?: string[];
  operatingHours?: string;
  contactNumber?: string;
  fuelTypes?: string[];
  services?: string[];
  rating?: number;
  isOpen24Hours?: boolean;
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      },
    });
  }

  try {
    const url = new URL(req.url);
    const service = url.searchParams.get('service');
    const action = url.searchParams.get('action');

    switch (service) {
      case 'bus':
        return await handleBusService(req, action);
      case 'flight':
        return await handleFlightService(req, action);
      case 'utility':
        return await handleUtilityService(req, action);
      case 'hotel':
        return await handleHotelService(req, action);
      // New: Local services
      case 'hospital':
        return await handleHospitalService(req, action);
      case 'atm':
        return await handleATMService(req, action);
      case 'pharmacy':
        return await handlePharmacyService(req, action);
      case 'fuel':
        return await handleFuelService(req, action);
      default:
        return createErrorResponse('Invalid service specified');
    }
  } catch (error: any) {
    console.error('Universal Scraper Error:', error);
    return createErrorResponse('Internal server error: ' + (error?.message || String(error)));
  }
});

// Bus Services
async function handleBusService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await searchBuses(req);
    case 'operators':
      return await getBusOperators(req);
    default:
      return createErrorResponse('Invalid bus action');
  }
}

async function searchBuses(req: Request): Promise<Response> {
  try {
    const { from, to, date } = await req.json();
    
    if (!from || !to || !date) {
      return createErrorResponse('From, to, and date are required');
    }

    // Scrape RedBus
    const redBusResults = await scrapeRedBus(from, to, date);
    
    // Scrape KSRTC (Karnataka State Road Transport Corporation)
    const ksrtcResults = await scrapeKSRTC(from, to, date);
    
    // Scrape APSRTC (Andhra Pradesh State Road Transport Corporation)
    const apsrtcResults = await scrapeAPSRTC(from, to, date);

    const allResults = [...redBusResults, ...ksrtcResults, ...apsrtcResults];

    return createSuccessResponse(allResults, 'bus-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search buses: ' + (error?.message || String(error)));
  }
}

async function scrapeRedBus(from: string, to: string, date: string): Promise<BusSearchResult[]> {
  try {
    // RedBus search URL format
    const searchUrl = `https://www.redbus.in/bus-tickets/${from.toLowerCase()}-to-${to.toLowerCase()}?fromCityName=${from}&fromCityId=&toCityName=${to}&toCityId=&onward=${date}`;
    
    const response = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
      },
    });

    if (!response.ok) {
      throw new Error(`RedBus request failed: ${response.status}`);
    }

    // Parse RedBus HTML structure (omitted). Using mock data for now.
    const mockResults: BusSearchResult[] = [
      {
        busOperator: "VRL Travels",
        busType: "AC Sleeper (2+1)",
        departureTime: "22:30",
        arrivalTime: "06:00+1",
        duration: "7h 30m",
        fare: 850,
        seatsAvailable: 12,
        amenities: ["AC", "Blanket", "Water Bottle", "Charging Point"],
        rating: 4.2,
        boardingPoints: ["Majestic", "Satellite Bus Station"],
        droppingPoints: ["Panaji", "Mapusa"]
      },
      {
        busOperator: "SRS Travels",
        busType: "Non AC Seater (2+2)",
        departureTime: "23:00",
        arrivalTime: "07:30+1",
        duration: "8h 30m",
        fare: 450,
        seatsAvailable: 8,
        amenities: ["Water Bottle", "Charging Point"],
        rating: 3.8,
        boardingPoints: ["Kempegowda Bus Station"],
        droppingPoints: ["Panaji Bus Stand"]
      }
    ];

    return mockResults;
  } catch (error) {
    console.error('RedBus scraping error:', error);
    return [];
  }
}

async function scrapeKSRTC(from: string, to: string, date: string): Promise<BusSearchResult[]> {
  try {
    const searchUrl = `https://ksrtc.in/oprs-web/guest/home.do?h=1`;
    
    const formData = new URLSearchParams({
      'fromPlaceName': from,
      'toPlaceName': to,
      'txtJourneyDate': date,
      'searchType': 'ONEWAY'
    });

    const response = await fetch(searchUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`KSRTC request failed: ${response.status}`);
    }

    const mockResults: BusSearchResult[] = [
      {
        busOperator: "KSRTC",
        busType: "Airavat Club Class",
        departureTime: "21:00",
        arrivalTime: "05:30+1",
        duration: "8h 30m",
        fare: 750,
        seatsAvailable: 15,
        amenities: ["AC", "Reclining Seats", "Entertainment", "Snacks"],
        rating: 4.0,
        boardingPoints: ["Bangalore City Railway Station"],
        droppingPoints: ["Mangalore Central Bus Stand"]
      }
    ];

    return mockResults;
  } catch (error) {
    console.error('KSRTC scraping error:', error);
    return [];
  }
}

async function scrapeAPSRTC(from: string, to: string, date: string): Promise<BusSearchResult[]> {
  try {
    const searchUrl = `https://www.apsrtconline.in/oprs-web/guest/home.do?h=1`;
    
    const mockResults: BusSearchResult[] = [
      {
        busOperator: "APSRTC",
        busType: "Garuda Plus",
        departureTime: "20:30",
        arrivalTime: "04:00+1",
        duration: "7h 30m",
        fare: 650,
        seatsAvailable: 20,
        amenities: ["AC", "Pushback Seats", "Water Bottle"],
        rating: 3.9,
        boardingPoints: ["Hyderabad Mahatma Gandhi Bus Station"],
        droppingPoints: ["Vijayawada Bus Station"]
      }
    ];

    return mockResults;
  } catch (error) {
    console.error('APSRTC scraping error:', error);
    return [];
  }
}

async function getBusOperators(_req: Request): Promise<Response> {
  const operators = [
    { name: "VRL Travels", routes: ["Bangalore-Goa", "Mumbai-Bangalore"], rating: 4.2 },
    { name: "SRS Travels", routes: ["Bangalore-Chennai", "Hyderabad-Bangalore"], rating: 3.8 },
    { name: "KSRTC", routes: ["Karnataka State Routes"], rating: 4.0 },
    { name: "APSRTC", routes: ["Andhra Pradesh State Routes"], rating: 3.9 },
    { name: "Orange Travels", routes: ["South India Routes"], rating: 4.1 },
    { name: "Jabbar Travels", routes: ["Bangalore-Hyderabad"], rating: 3.7 }
  ];

  return createSuccessResponse(operators, 'bus-operators');
}

// Flight Services
async function handleFlightService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'status':
      return await getFlightStatus(req);
    case 'search':
      return await searchFlights(req);
    default:
      return createErrorResponse('Invalid flight action');
  }
}

async function getFlightStatus(req: Request): Promise<Response> {
  try {
    const { flightNumber, date } = await req.json();
    
    if (!flightNumber) {
      return createErrorResponse('Flight number is required');
    }

    const flightInfo = await scrapeFlightStatus(flightNumber, date);
    
    return createSuccessResponse(flightInfo, 'flight-status');
  } catch (error: any) {
    return createErrorResponse('Failed to get flight status: ' + (error?.message || String(error)));
  }
}

async function scrapeFlightStatus(flightNumber: string, _date?: string): Promise<FlightInfo> {
  try {
    const searchUrl = `https://flightaware.com/live/flight/${flightNumber}`;
    
    const response = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    if (!response.ok) {
      throw new Error(`Flight status request failed: ${response.status}`);
    }

    const mockFlightInfo: FlightInfo = {
      flightNumber: flightNumber,
      airline: "IndiGo",
      from: "DEL",
      to: "BLR",
      departureTime: "14:30",
      arrivalTime: "17:15",
      status: "On Time",
      gate: "A12",
      terminal: "T3",
      delay: null
    };

    return mockFlightInfo;
  } catch (error) {
    console.error('Flight status scraping error:', error);
    throw error;
  }
}

async function searchFlights(req: Request): Promise<Response> {
  try {
    const { from, to, date, returnDate } = await req.json();
    
    if (!from || !to || !date) {
      return createErrorResponse('From, to, and date are required');
    }

    const flights = [
      {
        flightNumber: "6E-123",
        airline: "IndiGo",
        from: from,
        to: to,
        departureTime: "06:30",
        arrivalTime: "09:15",
        duration: "2h 45m",
        price: 4500,
        stops: 0
      },
      {
        flightNumber: "AI-456",
        airline: "Air India",
        from: from,
        to: to,
        departureTime: "14:20",
        arrivalTime: "17:05",
        duration: "2h 45m",
        price: 5200,
        stops: 0
      }
    ];

    return createSuccessResponse(flights, 'flight-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search flights: ' + (error?.message || String(error)));
  }
}

// Utility Services
async function handleUtilityService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'bill-info':
      return await getUtilityBillInfo(req);
    case 'providers':
      return await getUtilityProviders(req);
    default:
      return createErrorResponse('Invalid utility action');
  }
}

async function getUtilityBillInfo(req: Request): Promise<Response> {
  try {
    const { provider, accountNumber, state } = await req.json();
    
    if (!provider || !accountNumber) {
      return createErrorResponse('Provider and account number are required');
    }

    let billInfo: UtilityBillInfo;

    switch ((provider || '').toLowerCase()) {
      case 'bescom':
        billInfo = await scrapeBESCOM(accountNumber);
        break;
      case 'kseb':
        billInfo = await scrapeKSEB(accountNumber);
        break;
      case 'tneb':
        billInfo = await scrapeTNEB(accountNumber);
        break;
      case 'bwssb':
        billInfo = await scrapeBWSSB(accountNumber);
        break;
      default:
        return createErrorResponse('Unsupported utility provider');
    }

    return createSuccessResponse(billInfo, 'utility-bill');
  } catch (error: any) {
    return createErrorResponse('Failed to get utility bill info: ' + (error?.message || String(error)));
  }
}

async function scrapeBESCOM(accountNumber: string): Promise<UtilityBillInfo> {
  try {
    const searchUrl = `https://bescom.karnataka.gov.in/english`;
    
    const mockBillInfo: UtilityBillInfo = {
      provider: "BESCOM",
      accountNumber: accountNumber,
      billAmount: 1250.5,
      dueDate: "2024-02-15",
      billDate: "2024-01-15",
      unitsConsumed: 180,
      previousReading: 12450,
      currentReading: 12630,
      tariffRate: 6.95
    };

    return mockBillInfo;
  } catch (error) {
    console.error('BESCOM scraping error:', error);
    throw error;
  }
}

async function scrapeKSEB(accountNumber: string): Promise<UtilityBillInfo> {
  const mockBillInfo: UtilityBillInfo = {
    provider: "KSEB",
    accountNumber: accountNumber,
    billAmount: 980.25,
    dueDate: "2024-02-20",
    billDate: "2024-01-20",
    unitsConsumed: 145,
    previousReading: 8750,
    currentReading: 8895,
    tariffRate: 6.75
  };

  return mockBillInfo;
}

async function scrapeTNEB(accountNumber: string): Promise<UtilityBillInfo> {
  const mockBillInfo: UtilityBillInfo = {
    provider: "TNEB",
    accountNumber: accountNumber,
    billAmount: 1150.75,
    dueDate: "2024-02-18",
    billDate: "2024-01-18",
    unitsConsumed: 165,
    previousReading: 15200,
    currentReading: 15365,
    tariffRate: 6.98
  };

  return mockBillInfo;
}

async function scrapeBWSSB(accountNumber: string): Promise<UtilityBillInfo> {
  const mockBillInfo: UtilityBillInfo = {
    provider: "BWSSB",
    accountNumber: accountNumber,
    billAmount: 450.0,
    dueDate: "2024-02-25",
    billDate: "2024-01-25",
    unitsConsumed: 15000,
    previousReading: 125000,
    currentReading: 140000,
    tariffRate: 0.03
  };

  return mockBillInfo;
}

async function getUtilityProviders(_req: Request): Promise<Response> {
  const providers = [
    { 
      name: "BESCOM", 
      fullName: "Bangalore Electricity Supply Company",
      state: "Karnataka",
      type: "Electricity",
      website: "https://bescom.karnataka.gov.in"
    },
    { 
      name: "KSEB", 
      fullName: "Kerala State Electricity Board",
      state: "Kerala",
      type: "Electricity",
      website: "https://kseb.in"
    },
    { 
      name: "TNEB", 
      fullName: "Tamil Nadu Electricity Board",
      state: "Tamil Nadu",
      type: "Electricity",
      website: "https://tneb.in"
    },
    { 
      name: "BWSSB", 
      fullName: "Bangalore Water Supply and Sewerage Board",
      state: "Karnataka",
      type: "Water",
      website: "https://bwssb.gov.in"
    },
    { 
      name: "IGL", 
      fullName: "Indraprastha Gas Limited",
      state: "Delhi",
      type: "Gas",
      website: "https://iglonline.net"
    }
  ];

  return createSuccessResponse(providers, 'utility-providers');
}

// Hotel Services
async function handleHotelService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await searchHotels(req);
    default:
      return createErrorResponse('Invalid hotel action');
  }
}

async function searchHotels(req: Request): Promise<Response> {
  try {
    const { location, checkIn, checkOut, guests } = await req.json();
    
    if (!location || !checkIn || !checkOut) {
      return createErrorResponse('Location, check-in, and check-out dates are required');
    }

    const hotels: HotelInfo[] = [
      {
        name: "The Leela Palace Bangalore",
        location: "Bangalore",
        rating: 4.8,
        pricePerNight: 12000,
        amenities: ["Pool", "Spa", "Gym", "WiFi", "Restaurant", "Bar"],
        images: ["https://example.com/hotel1.jpg"],
        availability: true,
        roomTypes: ["Deluxe Room", "Executive Suite", "Presidential Suite"]
      },
      {
        name: "ITC Gardenia",
        location: "Bangalore",
        rating: 4.6,
        pricePerNight: 8500,
        amenities: ["Pool", "Spa", "Gym", "WiFi", "Restaurant"],
        images: ["https://example.com/hotel2.jpg"],
        availability: true,
        roomTypes: ["Superior Room", "Club Room", "Suite"]
      }
    ];

    return createSuccessResponse(hotels, 'hotel-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search hotels: ' + (error?.message || String(error)));
  }
}

// New: Hospital services
async function handleHospitalService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await hospitalSearch(req);
    case 'nearby':
      return await hospitalNearby(req);
    case 'details':
      return await hospitalDetails(req);
    case 'doctors':
      return await hospitalDoctors(req);
    default:
      return createErrorResponse('Invalid hospital action');
  }
}

async function hospitalSearch(req: Request): Promise<Response> {
  try {
    const { location, specialty, type } = await req.json();
    if (!location) return createErrorResponse('Location is required');
    const city = String(location);
    const data: HospitalItem[] = [
      {
        id: 'hsp_' + crypto.randomUUID(),
        name: `${city} General Hospital`,
        address: `Main Road, ${city}`,
        city,
        pincode: '400001',
        coordinates: { latitude: 19.076, longitude: 72.8777 },
        contactInfo: { phone: '022-12345678', emergency: '108' }
      },
      {
        id: 'hsp_' + crypto.randomUUID(),
        name: `${city} Heart Care Center`,
        address: `Health Street, ${city}`,
        city,
        pincode: '400002',
        coordinates: { latitude: 19.08, longitude: 72.88 },
        contactInfo: { phone: '022-87654321', emergency: '108' }
      }
    ];
    return createSuccessResponse<HospitalItem[]>(data, 'hospital-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search hospitals: ' + (error?.message || String(error)));
  }
}

async function hospitalNearby(req: Request): Promise<Response> {
  try {
    const { latitude, longitude, radius } = await req.json();
    if (typeof latitude !== 'number' || typeof longitude !== 'number') {
      return createErrorResponse('Latitude and longitude are required');
    }
    const data: HospitalItem[] = [
      {
        id: 'hsp_' + crypto.randomUUID(),
        name: 'City Care Hospital',
        address: 'Central Avenue',
        city: 'Nearby City',
        coordinates: { latitude, longitude },
        contactInfo: { phone: '1800-200-300', emergency: '108' }
      }
    ];
    return createSuccessResponse<HospitalItem[]>(data, 'hospital-nearby');
  } catch (error: any) {
    return createErrorResponse('Failed to get nearby hospitals: ' + (error?.message || String(error)));
  }
}

async function hospitalDetails(req: Request): Promise<Response> {
  try {
    const { hospitalId } = await req.json();
    if (!hospitalId) return createErrorResponse('Hospital ID is required');
    const data: HospitalItem = {
      id: hospitalId,
      name: 'Sample Hospital',
      address: '123 Health Lane',
      city: 'Sample City',
      coordinates: { latitude: 12.97, longitude: 77.59 },
      contactInfo: { phone: '080-555555', emergency: '108', email: 'info@hospital.in' }
    };
    return createSuccessResponse<HospitalItem>(data, 'hospital-details');
  } catch (error: any) {
    return createErrorResponse('Failed to get hospital details: ' + (error?.message || String(error)));
  }
}

async function hospitalDoctors(req: Request): Promise<Response> {
  try {
    const { location, specialization, hospitalId } = await req.json();
    if (!location && !hospitalId) return createErrorResponse('Location or hospitalId is required');
    const doctors = [
      {
        id: 'doc_' + crypto.randomUUID(),
        name: 'Dr. A Sharma',
        specialization: specialization || 'General Medicine',
        qualification: 'MBBS, MD',
        experience: 10,
        hospitalId: hospitalId || 'unknown',
        hospitalName: 'City Care Hospital',
        consultationFee: 500,
        availableDays: ['Mon', 'Wed', 'Fri'],
        availableHours: '10:00 - 13:00',
        rating: 4.5,
        languages: ['English', 'Hindi']
      }
    ];
    return createSuccessResponse(doctors, 'hospital-doctors');
  } catch (error: any) {
    return createErrorResponse('Failed to get doctors: ' + (error?.message || String(error)));
  }
}

// New: ATM services
async function handleATMService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await atmSearch(req);
    case 'nearby':
      return await atmNearby(req);
    default:
      return createErrorResponse('Invalid atm action');
  }
}

async function atmSearch(req: Request): Promise<Response> {
  try {
    const { location, bank } = await req.json();
    if (!location) return createErrorResponse('Location is required');
    const city = String(location);
    const data: ATMItem[] = [
      {
        id: 'atm_' + crypto.randomUUID(),
        bank: bank || 'HDFC Bank',
        name: `${bank || 'HDFC'} ATM - ${city} Central`,
        address: `High Street, ${city}`,
        city,
        pincode: '110001',
        coordinates: { latitude: 28.6139, longitude: 77.209 },
        isOpen24Hours: true,
        rating: 4.2
      },
      {
        id: 'atm_' + crypto.randomUUID(),
        bank: bank || 'SBI',
        name: `${bank || 'SBI'} ATM - ${city} West`,
        address: `Market Road, ${city}`,
        city,
        pincode: '110002',
        coordinates: { latitude: 28.61, longitude: 77.21 },
        isOpen24Hours: false,
        rating: 3.9
      }
    ];
    return createSuccessResponse<ATMItem[]>(data, 'atm-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search ATMs: ' + (error?.message || String(error)));
  }
}

async function atmNearby(req: Request): Promise<Response> {
  try {
    const { latitude, longitude, radius } = await req.json();
    if (typeof latitude !== 'number' || typeof longitude !== 'number') {
      return createErrorResponse('Latitude and longitude are required');
    }
    const data: ATMItem[] = [
      {
        id: 'atm_' + crypto.randomUUID(),
        bank: 'ICICI Bank',
        name: 'ICICI ATM',
        address: 'Nearby Street',
        city: 'Nearby City',
        coordinates: { latitude, longitude },
        isOpen24Hours: true,
        rating: 4.1
      }
    ];
    return createSuccessResponse<ATMItem[]>(data, 'atm-nearby');
  } catch (error: any) {
    return createErrorResponse('Failed to get nearby ATMs: ' + (error?.message || String(error)));
  }
}

// New: Pharmacy services
async function handlePharmacyService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await pharmacySearch(req);
    case 'nearby':
      return await pharmacyNearby(req);
    default:
      return createErrorResponse('Invalid pharmacy action');
  }
}

async function pharmacySearch(req: Request): Promise<Response> {
  try {
    const { location } = await req.json();
    if (!location) return createErrorResponse('Location is required');
    const city = String(location);
    const data: PharmacyItem[] = [
      {
        id: 'ph_' + crypto.randomUUID(),
        name: `${city} Medicals`,
        address: `Station Road, ${city}`,
        city,
        pincode: '560001',
        coordinates: { latitude: 12.9716, longitude: 77.5946 },
        phone: '080-123456'
      },
      {
        id: 'ph_' + crypto.randomUUID(),
        name: `24x7 Pharmacy ${city}`,
        address: `Ring Road, ${city}`,
        city,
        pincode: '560002',
        coordinates: { latitude: 12.975, longitude: 77.6 },
        phone: '080-987654',
        isOpen24Hours: true
      }
    ];
    return createSuccessResponse<PharmacyItem[]>(data, 'pharmacy-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search pharmacies: ' + (error?.message || String(error)));
  }
}

async function pharmacyNearby(req: Request): Promise<Response> {
  try {
    const { latitude, longitude, radius } = await req.json();
    if (typeof latitude !== 'number' || typeof longitude !== 'number') {
      return createErrorResponse('Latitude and longitude are required');
    }
    const data: PharmacyItem[] = [
      {
        id: 'ph_' + crypto.randomUUID(),
        name: 'City Pharmacy',
        address: 'Near Park',
        city: 'Nearby City',
        coordinates: { latitude, longitude },
        phone: '080-111222',
        isOpen24Hours: true
      }
    ];
    return createSuccessResponse<PharmacyItem[]>(data, 'pharmacy-nearby');
  } catch (error: any) {
    return createErrorResponse('Failed to get nearby pharmacies: ' + (error?.message || String(error)));
  }
}

// New: Fuel services
async function handleFuelService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'prices':
      return await fuelPrices(req);
    case 'nearby-pumps':
      return await fuelNearbyPumps(req);
    case 'search-pumps':
      return await fuelSearchPumps(req);
    case 'price-history':
      return await fuelPriceHistory(req);
    default:
      return createErrorResponse('Invalid fuel action');
  }
}

async function fuelPrices(req: Request): Promise<Response> {
  try {
    const { city, state } = await req.json();
    if (!city) return createErrorResponse('City is required');
    const data = [
      { fuelType: 'Petrol', price: 101.2, currency: 'INR', city, state: state || 'N/A', lastUpdated: new Date().toISOString(), priceChange: { amount: 0.2, direction: 'up', date: new Date().toISOString() } },
      { fuelType: 'Diesel', price: 89.5, currency: 'INR', city, state: state || 'N/A', lastUpdated: new Date().toISOString(), priceChange: { amount: 0.0, direction: 'same', date: new Date().toISOString() } }
    ];
    return createSuccessResponse(data, 'fuel-prices');
  } catch (error: any) {
    return createErrorResponse('Failed to get fuel prices: ' + (error?.message || String(error)));
  }
}

async function fuelNearbyPumps(req: Request): Promise<Response> {
  try {
    const { latitude, longitude, radius } = await req.json();
    if (typeof latitude !== 'number' || typeof longitude !== 'number') {
      return createErrorResponse('Latitude and longitude are required');
    }
    const data: PetrolPumpItem[] = [
      {
        id: 'pp_' + crypto.randomUUID(),
        name: 'IOCL Fuel Station',
        brand: 'IOCL',
        address: 'Highway 1',
        city: 'Nearby City',
        coordinates: { latitude, longitude },
        fuelTypes: ['Petrol', 'Diesel'],
        isOpen24Hours: true,
        rating: 4.0
      }
    ];
    return createSuccessResponse<PetrolPumpItem[]>(data, 'fuel-nearby');
  } catch (error: any) {
    return createErrorResponse('Failed to get nearby petrol pumps: ' + (error?.message || String(error)));
  }
}

async function fuelSearchPumps(req: Request): Promise<Response> {
  try {
    const { location, brand } = await req.json();
    if (!location) return createErrorResponse('Location is required');
    const city = String(location);
    const data: PetrolPumpItem[] = [
      {
        id: 'pp_' + crypto.randomUUID(),
        name: `${brand || 'BPCL'} Fuel Station ${city} Central`,
        brand: brand || 'BPCL',
        address: `Main Road, ${city}`,
        city,
        pincode: '560001',
        coordinates: { latitude: 12.9716, longitude: 77.5946 },
        fuelTypes: ['Petrol', 'Diesel'],
        isOpen24Hours: true,
        rating: 4.2
      },
      {
        id: 'pp_' + crypto.randomUUID(),
        name: `${brand || 'IOCL'} Petrol Pump ${city} East`,
        brand: brand || 'IOCL',
        address: `Ring Road, ${city}`,
        city,
        pincode: '560002',
        coordinates: { latitude: 12.975, longitude: 77.6 },
        fuelTypes: ['Petrol', 'Diesel', 'CNG'],
        isOpen24Hours: false,
        rating: 3.9
      }
    ];
    return createSuccessResponse<PetrolPumpItem[]>(data, 'fuel-search');
  } catch (error: any) {
    return createErrorResponse('Failed to search petrol pumps: ' + (error?.message || String(error)));
  }
}

async function fuelPriceHistory(req: Request): Promise<Response> {
  try {
    const { city, fuelType, days } = await req.json();
    if (!city || !fuelType) return createErrorResponse('City and fuel type are required');
    const today = new Date();
    const history = Array.from({ length: Math.min(30, Number(days) || 30) }).map((_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      return { date: d.toISOString().slice(0, 10), price: 100 + Math.sin(i / 3) * 1.5 };
    }).reverse();
    return createSuccessResponse(history, 'fuel-price-history');
  } catch (error: any) {
    return createErrorResponse('Failed to get price history: ' + (error?.message || String(error)));
  }
}

// Helper functions
function createSuccessResponse<T>(data: T, source: string): Response {
  const response: ScraperResponse<T> = {
    success: true,
    data,
    timestamp: new Date().toISOString(),
    source
  };

  return new Response(JSON.stringify(response), {
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
}

function createErrorResponse(error: string): Response {
  const response: ScraperResponse = {
    success: false,
    error,
    timestamp: new Date().toISOString(),
    source: 'universal-scraper'
  };

  return new Response(JSON.stringify(response), {
    status: 400,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
  });
}