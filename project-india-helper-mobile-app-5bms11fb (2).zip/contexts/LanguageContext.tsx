import React, { createContext, useContext, useState, useEffect } from 'react';
import { blink } from '@/lib/blink';

export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export const SUPPORTED_LANGUAGES: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flag: '🇮🇳' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', flag: '🇮🇳' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', flag: '🇮🇳' },
  { code: 'as', name: 'Assamese', nativeName: 'অসমীয়া', flag: '🇮🇳' },
];

interface LanguageContextType {
  currentLanguage: Language;
  setLanguage: (language: Language) => Promise<void>;
  t: (key: string, params?: Record<string, string>) => string;
  isLoading: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: React.ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(SUPPORTED_LANGUAGES[0]);
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUserLanguagePreference();
  }, []);

  const loadUserLanguagePreference = async () => {
    try {
      setIsLoading(true);
      
      // Try to get user's language preference from database
      if (blink.auth.isAuthenticated()) {
        const user = await blink.auth.me();
        const settings = await blink.db.userSettings.list({
          where: { userId: user.id },
          limit: 1,
        });
        
        if (settings.length > 0 && settings[0].languagePreference) {
          const savedLang = SUPPORTED_LANGUAGES.find(
            lang => lang.code === settings[0].languagePreference
          );
          if (savedLang) {
            await setLanguage(savedLang);
            return;
          }
        }
      }
      
      // Default to English and load translations
      await loadTranslations('en');
      setCurrentLanguage(SUPPORTED_LANGUAGES[0]);
    } catch (error) {
      console.error('Error loading language preference:', error);
      // Fallback to English
      await loadTranslations('en');
      setCurrentLanguage(SUPPORTED_LANGUAGES[0]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTranslations = async (languageCode: string) => {
    try {
      // Import translations using static imports
      let translationData;
      switch (languageCode) {
        case 'hi':
          translationData = require('@/translations/hi.json');
          break;
        case 'ta':
          translationData = require('@/translations/ta.json');
          break;
        case 'en':
        default:
          translationData = require('@/translations/en.json');
          break;
      }
      setTranslations(translationData);
    } catch (error) {
      console.error(`Error loading translations for ${languageCode}:`, error);
      // Fallback to English
      const englishData = require('@/translations/en.json');
      setTranslations(englishData);
    }
  };

  const setLanguage = async (language: Language) => {
    try {
      setIsLoading(true);
      
      // Load new translations
      await loadTranslations(language.code);
      
      // Update current language
      setCurrentLanguage(language);
      
      // Save to database if user is authenticated
      if (blink.auth.isAuthenticated()) {
        const user = await blink.auth.me();
        const settings = await blink.db.userSettings.list({
          where: { userId: user.id },
          limit: 1,
        });
        
        if (settings.length > 0) {
          await blink.db.userSettings.update(settings[0].id, {
            languagePreference: language.code,
            updatedAt: new Date().toISOString(),
          });
        } else {
          await blink.db.userSettings.create({
            userId: user.id,
            languagePreference: language.code,
            notificationEnabled: 'true',
            locationSharingEnabled: 'false',
            biometricEnabled: 'false',
            darkModeEnabled: 'false',
            currencyPreference: 'INR',
            dateFormat: 'DD/MM/YYYY',
            timeFormat: '24h',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        }
      }
    } catch (error) {
      console.error('Error setting language:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const t = (key: string, params?: Record<string, string>): string => {
    let translation = translations[key] || key;
    
    // Replace parameters in translation
    if (params) {
      Object.keys(params).forEach(param => {
        translation = translation.replace(`{{${param}}}`, params[param]);
      });
    }
    
    return translation;
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        setLanguage,
        t,
        isLoading,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};