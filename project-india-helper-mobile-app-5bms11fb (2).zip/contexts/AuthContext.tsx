import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { blink } from '@/lib/blink'

interface User {
  id: string
  email: string
  displayName?: string
  phoneNumber?: string
  preferredLanguage?: string
  locationState?: string
  locationCity?: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (redirectUrl?: string) => void
  logout: (redirectUrl?: string) => void
  updateProfile: (data: Partial<User>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Listen to auth state changes
    const unsubscribe = blink.auth.onAuthStateChanged((state) => {
      setUser(state.user)
      setIsLoading(state.isLoading)
      setIsAuthenticated(state.isAuthenticated)
      
      // If user is authenticated, sync with our database
      if (state.user && state.isAuthenticated) {
        syncUserToDatabase(state.user)
      }
    })

    return unsubscribe
  }, [])

  const syncUserToDatabase = async (authUser: any) => {
    try {
      // Check if user exists in our database
      const existingUsers = await blink.db.users.list({
        where: { id: authUser.id },
        limit: 1
      })

      if (existingUsers.length === 0) {
        // Create new user record
        await blink.db.users.create({
          id: authUser.id,
          email: authUser.email,
          displayName: authUser.displayName || authUser.email?.split('@')[0],
          preferredLanguage: 'en',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        })

        // Create default user settings
        await blink.db.userSettings.create({
          id: `settings_${authUser.id}`,
          userId: authUser.id,
          languagePreference: 'en',
          notificationEnabled: true,
          locationSharingEnabled: false,
          biometricEnabled: false,
          darkModeEnabled: false,
          currencyPreference: 'INR',
          dateFormat: 'DD/MM/YYYY',
          timeFormat: '24h',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        })
      }
    } catch (error) {
      console.error('Error syncing user to database:', error)
    }
  }

  const login = (redirectUrl?: string) => {
    blink.auth.login(redirectUrl)
  }

  const logout = (redirectUrl?: string) => {
    blink.auth.logout(redirectUrl)
  }

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return

    try {
      // Update in Blink auth
      await blink.auth.updateMe(data)
      
      // Update in our database
      await blink.db.users.update(user.id, {
        ...data,
        updatedAt: new Date().toISOString()
      })

      // Update local state
      setUser(prev => prev ? { ...prev, ...data } : null)
    } catch (error) {
      console.error('Error updating profile:', error)
      throw error
    }
  }

  const value: AuthContextType = {
    user,
    isLoading,
    isAuthenticated,
    login,
    logout,
    updateProfile
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}