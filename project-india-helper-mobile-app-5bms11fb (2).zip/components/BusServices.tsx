import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  Alert, 
  ActivityIndicator, 
  StyleSheet,
  Dimensions 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Bus, Search, Calendar, MapPin, Clock, Users, Star, ArrowRight } from 'lucide-react-native';
import { busService, BusSearchResult, BusOperator } from '../services/busService';
import { useLanguage } from '../contexts/LanguageContext';

const { width } = Dimensions.get('window');

interface BusServicesProps {
  onServiceSelect?: (service: string) => void;
}

export default function BusServices({ onServiceSelect }: BusServicesProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'search' | 'operators' | 'routes'>('search');
  const [loading, setLoading] = useState(false);

  // Search states
  const [searchFrom, setSearchFrom] = useState('');
  const [searchTo, setSearchTo] = useState('');
  const [searchDate, setSearchDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchResults, setSearchResults] = useState<BusSearchResult[]>([]);

  // Operators state
  const [operators, setOperators] = useState<BusOperator[]>([]);

  const handleBusSearch = async () => {
    if (!busService.validateRoute(searchFrom, searchTo)) {
      Alert.alert('Error', 'Please enter valid from and to locations');
      return;
    }

    if (!busService.validateDate(searchDate)) {
      Alert.alert('Error', 'Please select a valid future date');
      return;
    }

    setLoading(true);
    try {
      const results = await busService.searchBuses(searchFrom, searchTo, searchDate);
      setSearchResults(results);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to search buses');
    } finally {
      setLoading(false);
    }
  };

  const handleGetOperators = async () => {
    setLoading(true);
    try {
      const operatorsList = await busService.getBusOperators();
      setOperators(operatorsList);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to get operators');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { key: 'search', title: 'Search Buses', icon: Search, color: '#00A86B' },
    { key: 'operators', title: 'Operators', icon: Bus, color: '#4285F4' },
    { key: 'routes', title: 'Popular Routes', icon: MapPin, color: '#9C27B0' },
  ];

  const renderTabButton = (tab: any) => (
    <TouchableOpacity
      key={tab.key}
      onPress={() => setActiveTab(tab.key as any)}
      style={[
        styles.tabButton,
        activeTab === tab.key && { backgroundColor: tab.color }
      ]}
    >
      <tab.icon 
        size={18} 
        color={activeTab === tab.key ? 'white' : '#666'} 
      />
      <Text style={[
        styles.tabButtonText,
        activeTab === tab.key && styles.tabButtonTextActive
      ]}>
        {tab.title}
      </Text>
    </TouchableOpacity>
  );

  const renderInputField = (
    label: string, 
    value: string, 
    onChangeText: (text: string) => void, 
    placeholder: string,
    keyboardType: 'default' | 'numeric' = 'default'
  ) => (
    <View style={styles.inputContainer}>
      <Text style={styles.inputLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        style={styles.textInput}
        keyboardType={keyboardType}
        placeholderTextColor="#999"
      />
    </View>
  );

  const renderActionButton = (
    title: string, 
    onPress: () => void, 
    icon: React.ReactNode, 
    color: string,
    disabled: boolean = false
  ) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={[styles.actionButton, { backgroundColor: color }]}
    >
      {loading ? (
        <ActivityIndicator color="white" size="small" />
      ) : (
        <>
          {icon}
          <Text style={styles.actionButtonText}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );

  const renderSearchTab = () => (
    <View style={styles.tabContent}>
      <View style={styles.rowContainer}>
        <View style={styles.halfWidth}>
          {renderInputField('From City', searchFrom, setSearchFrom, 'e.g., Bangalore')}
        </View>
        <View style={styles.halfWidth}>
          {renderInputField('To City', searchTo, setSearchTo, 'e.g., Chennai')}
        </View>
      </View>

      {renderInputField('Journey Date', searchDate, setSearchDate, 'YYYY-MM-DD')}

      {renderActionButton(
        'Search Buses',
        handleBusSearch,
        <Search size={20} color="white" />,
        '#00A86B'
      )}

      {searchResults.length > 0 && (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Available Buses ({searchResults.length})</Text>
          {searchResults.map((bus, index) => (
            <View key={index} style={styles.busCard}>
              <View style={styles.busHeader}>
                <View>
                  <Text style={styles.busOperator}>{bus.busOperator}</Text>
                  <Text style={styles.busType}>{bus.busType}</Text>
                </View>
                <View style={styles.ratingContainer}>
                  <Star size={14} color="#FFD700" fill="#FFD700" />
                  <Text style={styles.rating}>{bus.rating}</Text>
                </View>
              </View>
              
              <View style={styles.busTiming}>
                <View style={styles.timeSection}>
                  <Text style={styles.timeValue}>{bus.departureTime}</Text>
                  <Text style={styles.timeLabel}>Departure</Text>
                </View>
                <View style={styles.durationContainer}>
                  <ArrowRight size={16} color="#666" />
                  <Text style={styles.duration}>{bus.duration}</Text>
                </View>
                <View style={styles.timeSection}>
                  <Text style={styles.timeValue}>{bus.arrivalTime}</Text>
                  <Text style={styles.timeLabel}>Arrival</Text>
                </View>
              </View>
              
              <View style={styles.busDetails}>
                <View style={styles.fareSection}>
                  <Text style={styles.fareLabel}>Starting from</Text>
                  <Text style={styles.fareValue}>₹{bus.fare}</Text>
                </View>
                <View style={styles.seatsSection}>
                  <Users size={16} color="#666" />
                  <Text style={styles.seatsText}>{bus.seatsAvailable} seats</Text>
                </View>
              </View>

              {bus.amenities.length > 0 && (
                <View style={styles.amenitiesSection}>
                  <Text style={styles.amenitiesLabel}>Amenities:</Text>
                  <Text style={styles.amenitiesText}>{bus.amenities.join(' • ')}</Text>
                </View>
              )}

              <TouchableOpacity style={styles.bookButton}>
                <Text style={styles.bookButtonText}>View Seats</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}

      {/* Popular Routes */}
      <View style={styles.popularSection}>
        <Text style={styles.sectionTitle}>Popular Routes</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {busService.getPopularRoutes().map((route, index) => (
            <TouchableOpacity 
              key={index} 
              style={styles.routeCard}
              onPress={() => {
                setSearchFrom(route.from);
                setSearchTo(route.to);
              }}
            >
              <Text style={styles.routeText}>{route.from} → {route.to}</Text>
              <Text style={styles.routeDuration}>{route.duration}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </View>
  );

  const renderOperatorsTab = () => (
    <View style={styles.tabContent}>
      {renderActionButton(
        'Load Bus Operators',
        handleGetOperators,
        <Bus size={20} color="white" />,
        '#4285F4'
      )}

      {operators.length > 0 ? (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Bus Operators ({operators.length})</Text>
          {operators.map((operator, index) => (
            <View key={index} style={styles.operatorCard}>
              <View style={styles.operatorHeader}>
                <Text style={styles.operatorName}>{operator.name}</Text>
                <View style={styles.ratingContainer}>
                  <Star size={14} color="#FFD700" fill="#FFD700" />
                  <Text style={styles.rating}>{operator.rating}</Text>
                </View>
              </View>
              <Text style={styles.operatorRoutes}>
                Routes: {operator.routes.join(', ')}
              </Text>
            </View>
          ))}
        </ScrollView>
      ) : (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Major Bus Operators</Text>
          {busService.getMajorOperators().map((operator, index) => (
            <View key={index} style={styles.operatorCard}>
              <Text style={styles.operatorName}>{operator.name}</Text>
              <Text style={styles.operatorSpeciality}>{operator.speciality}</Text>
              <Text style={styles.operatorCoverage}>
                Coverage: {operator.coverage.join(', ')}
              </Text>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );

  const renderRoutesTab = () => (
    <View style={styles.tabContent}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.resultsTitle}>Popular Bus Routes</Text>
        {busService.getPopularRoutes().map((route, index) => (
          <TouchableOpacity 
            key={index} 
            style={styles.routeDetailCard}
            onPress={() => {
              setActiveTab('search');
              setSearchFrom(route.from);
              setSearchTo(route.to);
            }}
          >
            <View style={styles.routeDetailHeader}>
              <Text style={styles.routeDetailText}>{route.from} → {route.to}</Text>
              <Text style={styles.routeDetailDuration}>{route.duration}</Text>
            </View>
            <Text style={styles.routeDetailAction}>Tap to search buses</Text>
          </TouchableOpacity>
        ))}

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Booking Tips</Text>
          {busService.getBookingTips().map((tip, index) => (
            <View key={index} style={styles.tipItem}>
              <Text style={styles.tipBullet}>•</Text>
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabScrollContainer}
        >
          {tabs.map(renderTabButton)}
        </ScrollView>
      </View>

      {/* Tab Content */}
      <ScrollView style={styles.contentContainer} showsVerticalScrollIndicator={false}>
        {activeTab === 'search' && renderSearchTab()}
        {activeTab === 'operators' && renderOperatorsTab()}
        {activeTab === 'routes' && renderRoutesTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  tabContainer: {
    backgroundColor: 'white',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  tabScrollContainer: {
    paddingHorizontal: 20,
    gap: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    minWidth: 120,
  },
  tabButtonText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  tabButtonTextActive: {
    color: 'white',
  },
  contentContainer: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E5E5E5',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    backgroundColor: 'white',
    color: '#333',
  },
  rowContainer: {
    flexDirection: 'row',
    gap: 15,
  },
  halfWidth: {
    flex: 1,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  resultsContainer: {
    maxHeight: 500,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  busCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  busHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  busOperator: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  busType: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  busTiming: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  timeSection: {
    alignItems: 'center',
    flex: 1,
  },
  timeValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  timeLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  durationContainer: {
    alignItems: 'center',
    gap: 8,
  },
  duration: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  busDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  fareSection: {
    alignItems: 'flex-start',
  },
  fareLabel: {
    fontSize: 12,
    color: '#666',
  },
  fareValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00A86B',
  },
  seatsSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  seatsText: {
    fontSize: 14,
    color: '#666',
  },
  amenitiesSection: {
    marginBottom: 16,
  },
  amenitiesLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  amenitiesText: {
    fontSize: 14,
    color: '#333',
  },
  bookButton: {
    backgroundColor: '#00A86B',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  bookButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  popularSection: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  routeCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginRight: 12,
    minWidth: 140,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  routeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  routeDuration: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  operatorCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  operatorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  operatorName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  operatorRoutes: {
    fontSize: 14,
    color: '#666',
  },
  operatorSpeciality: {
    fontSize: 14,
    color: '#00A86B',
    fontWeight: '600',
    marginBottom: 4,
  },
  operatorCoverage: {
    fontSize: 14,
    color: '#666',
  },
  routeDetailCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  routeDetailHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeDetailText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  routeDetailDuration: {
    fontSize: 14,
    color: '#00A86B',
    fontWeight: '600',
  },
  routeDetailAction: {
    fontSize: 12,
    color: '#666',
    fontStyle: 'italic',
  },
  tipsSection: {
    marginTop: 20,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  tipBullet: {
    fontSize: 16,
    color: '#00A86B',
    marginRight: 8,
    marginTop: 2,
  },
  tipText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 20,
  },
});