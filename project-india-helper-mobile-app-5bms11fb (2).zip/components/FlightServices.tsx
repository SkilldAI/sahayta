import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  Alert, 
  ActivityIndicator, 
  StyleSheet,
  Dimensions 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Plane, Search, Calendar, MapPin, Clock, Info, ArrowRight } from 'lucide-react-native';
import { flightService, FlightInfo, FlightSearchResult } from '../services/flightService';
import { useLanguage } from '../contexts/LanguageContext';

const { width } = Dimensions.get('window');

interface FlightServicesProps {
  onServiceSelect?: (service: string) => void;
}

export default function FlightServices({ onServiceSelect }: FlightServicesProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'status' | 'search' | 'airports'>('status');
  const [loading, setLoading] = useState(false);

  // Flight Status states
  const [flightNumber, setFlightNumber] = useState('');
  const [statusDate, setStatusDate] = useState(new Date().toISOString().split('T')[0]);
  const [flightStatus, setFlightStatus] = useState<FlightInfo | null>(null);

  // Flight Search states
  const [searchFrom, setSearchFrom] = useState('');
  const [searchTo, setSearchTo] = useState('');
  const [searchDate, setSearchDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchResults, setSearchResults] = useState<FlightSearchResult[]>([]);

  const handleFlightStatus = async () => {
    if (!flightService.validateFlightNumber(flightNumber)) {
      Alert.alert('Error', 'Please enter a valid flight number (e.g., 6E-123, AI-456)');
      return;
    }

    setLoading(true);
    try {
      const status = await flightService.getFlightStatus(flightNumber, statusDate);
      setFlightStatus(status);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to get flight status');
    } finally {
      setLoading(false);
    }
  };

  const handleFlightSearch = async () => {
    if (!flightService.validateAirportCode(searchFrom) || !flightService.validateAirportCode(searchTo)) {
      Alert.alert('Error', 'Please enter valid 3-letter airport codes (e.g., DEL, BOM)');
      return;
    }

    if (!flightService.validateDate(searchDate)) {
      Alert.alert('Error', 'Please select a valid future date');
      return;
    }

    setLoading(true);
    try {
      const results = await flightService.searchFlights(searchFrom, searchTo, searchDate);
      setSearchResults(results);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to search flights');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { key: 'status', title: 'Flight Status', icon: Info, color: '#4285F4' },
    { key: 'search', title: 'Search Flights', icon: Search, color: '#00A86B' },
    { key: 'airports', title: 'Airports', icon: MapPin, color: '#9C27B0' },
  ];

  const renderTabButton = (tab: any) => (
    <TouchableOpacity
      key={tab.key}
      onPress={() => setActiveTab(tab.key as any)}
      style={[
        styles.tabButton,
        activeTab === tab.key && { backgroundColor: tab.color }
      ]}
    >
      <tab.icon 
        size={18} 
        color={activeTab === tab.key ? 'white' : '#666'} 
      />
      <Text style={[
        styles.tabButtonText,
        activeTab === tab.key && styles.tabButtonTextActive
      ]}>
        {tab.title}
      </Text>
    </TouchableOpacity>
  );

  const renderInputField = (
    label: string, 
    value: string, 
    onChangeText: (text: string) => void, 
    placeholder: string,
    keyboardType: 'default' | 'numeric' = 'default',
    maxLength?: number
  ) => (
    <View style={styles.inputContainer}>
      <Text style={styles.inputLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        style={styles.textInput}
        keyboardType={keyboardType}
        maxLength={maxLength}
        placeholderTextColor="#999"
        autoCapitalize="characters"
      />
    </View>
  );

  const renderActionButton = (
    title: string, 
    onPress: () => void, 
    icon: React.ReactNode, 
    color: string,
    disabled: boolean = false
  ) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={[styles.actionButton, { backgroundColor: color }]}
    >
      {loading ? (
        <ActivityIndicator color="white" size="small" />
      ) : (
        <>
          {icon}
          <Text style={styles.actionButtonText}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );

  const getStatusColor = (status: string) => {
    const statusMeanings = flightService.getFlightStatusMeanings();
    const statusInfo = statusMeanings.find(s => s.status === status);
    return statusInfo?.color || '#666';
  };

  const renderStatusTab = () => (
    <View style={styles.tabContent}>
      {renderInputField(
        'Flight Number',
        flightNumber,
        setFlightNumber,
        'e.g., 6E-123, AI-456',
        'default',
        10
      )}

      {renderInputField('Date (Optional)', statusDate, setStatusDate, 'YYYY-MM-DD')}

      {renderActionButton(
        'Check Status',
        handleFlightStatus,
        <Info size={20} color="white" />,
        '#4285F4'
      )}

      {flightStatus && (
        <View style={styles.resultCard}>
          <LinearGradient
            colors={['#4285F4', '#5A9BF8']}
            style={styles.resultHeader}
          >
            <Text style={styles.resultTitle}>
              {flightStatus.airline} {flightStatus.flightNumber}
            </Text>
            <Text style={styles.resultSubtitle}>
              {flightStatus.from} → {flightStatus.to}
            </Text>
          </LinearGradient>
          
          <View style={styles.resultContent}>
            <View style={styles.flightTiming}>
              <View style={styles.timeSection}>
                <Text style={styles.timeLabel}>Departure</Text>
                <Text style={styles.timeValue}>{flightStatus.departureTime}</Text>
                {flightStatus.terminal && (
                  <Text style={styles.terminalText}>Terminal {flightStatus.terminal}</Text>
                )}
                {flightStatus.gate && (
                  <Text style={styles.gateText}>Gate {flightStatus.gate}</Text>
                )}
              </View>
              <ArrowRight size={20} color="#666" />
              <View style={styles.timeSection}>
                <Text style={styles.timeLabel}>Arrival</Text>
                <Text style={styles.timeValue}>{flightStatus.arrivalTime}</Text>
              </View>
            </View>

            <View style={styles.statusSection}>
              <Text style={styles.statusLabel}>Status</Text>
              <Text style={[
                styles.statusValue,
                { color: getStatusColor(flightStatus.status) }
              ]}>
                {flightStatus.status}
              </Text>
            </View>

            {flightStatus.delay && (
              <View style={styles.delaySection}>
                <Text style={styles.delayText}>Delayed by: {flightStatus.delay}</Text>
              </View>
            )}
          </View>
        </View>
      )}

      {/* Flight Status Meanings */}
      <View style={styles.statusMeaningsSection}>
        <Text style={styles.sectionTitle}>Status Meanings</Text>
        {flightService.getFlightStatusMeanings().slice(0, 6).map((status, index) => (
          <View key={index} style={styles.statusMeaningItem}>
            <View style={[styles.statusDot, { backgroundColor: status.color }]} />
            <View style={styles.statusMeaningText}>
              <Text style={styles.statusMeaningTitle}>{status.status}</Text>
              <Text style={styles.statusMeaningDesc}>{status.meaning}</Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );

  const renderSearchTab = () => (
    <View style={styles.tabContent}>
      <View style={styles.rowContainer}>
        <View style={styles.halfWidth}>
          {renderInputField('From Airport', searchFrom, setSearchFrom, 'DEL', 'default', 3)}
        </View>
        <View style={styles.halfWidth}>
          {renderInputField('To Airport', searchTo, setSearchTo, 'BOM', 'default', 3)}
        </View>
      </View>

      {renderInputField('Departure Date', searchDate, setSearchDate, 'YYYY-MM-DD')}

      {renderActionButton(
        'Search Flights',
        handleFlightSearch,
        <Search size={20} color="white" />,
        '#00A86B'
      )}

      {searchResults.length > 0 && (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsTitle}>Available Flights ({searchResults.length})</Text>
          {searchResults.map((flight, index) => (
            <View key={index} style={styles.flightCard}>
              <View style={styles.flightHeader}>
                <Text style={styles.flightAirline}>{flight.airline}</Text>
                <Text style={styles.flightNumber}>{flight.flightNumber}</Text>
              </View>
              
              <View style={styles.flightTiming}>
                <View style={styles.timeSection}>
                  <Text style={styles.timeValue}>{flight.departureTime}</Text>
                  <Text style={styles.timeLabel}>{flight.from}</Text>
                </View>
                <View style={styles.durationContainer}>
                  <ArrowRight size={16} color="#666" />
                  <Text style={styles.duration}>{flight.duration}</Text>
                  {flight.stops > 0 && (
                    <Text style={styles.stops}>{flight.stops} stop{flight.stops > 1 ? 's' : ''}</Text>
                  )}
                </View>
                <View style={styles.timeSection}>
                  <Text style={styles.timeValue}>{flight.arrivalTime}</Text>
                  <Text style={styles.timeLabel}>{flight.to}</Text>
                </View>
              </View>
              
              <View style={styles.flightDetails}>
                <Text style={styles.priceLabel}>Starting from</Text>
                <Text style={styles.priceValue}>₹{flight.price.toLocaleString()}</Text>
              </View>

              <TouchableOpacity style={styles.bookButton}>
                <Text style={styles.bookButtonText}>Book Now</Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}

      {/* Popular Routes */}
      <View style={styles.popularSection}>
        <Text style={styles.sectionTitle}>Popular Routes</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {flightService.getPopularRoutes().map((route, index) => (
            <TouchableOpacity 
              key={index} 
              style={styles.routeCard}
              onPress={() => {
                setSearchFrom(route.from);
                setSearchTo(route.to);
              }}
            >
              <Text style={styles.routeText}>{route.from} → {route.to}</Text>
              <Text style={styles.routeDuration}>{route.duration}</Text>
              <Text style={styles.routeFrequency}>{route.frequency}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </View>
  );

  const renderAirportsTab = () => (
    <View style={styles.tabContent}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={styles.resultsTitle}>Major Indian Airports</Text>
        {flightService.getMajorAirports().map((airport, index) => (
          <TouchableOpacity 
            key={index} 
            style={styles.airportCard}
            onPress={() => {
              // Could set as from/to airport
            }}
          >
            <View style={styles.airportHeader}>
              <Text style={styles.airportCode}>{airport.code}</Text>
              <Text style={styles.airportCity}>{airport.city}, {airport.state}</Text>
            </View>
            <Text style={styles.airportName}>{airport.name}</Text>
          </TouchableOpacity>
        ))}

        <View style={styles.airlinesSection}>
          <Text style={styles.sectionTitle}>Indian Airlines</Text>
          {flightService.getIndianAirlines().map((airline, index) => (
            <View key={index} style={styles.airlineCard}>
              <View style={styles.airlineHeader}>
                <Text style={styles.airlineCode}>{airline.code}</Text>
                <Text style={styles.airlineName}>{airline.name}</Text>
              </View>
              <Text style={styles.airlineType}>{airline.type} • Hub: {airline.hub}</Text>
            </View>
          ))}
        </View>

        <View style={styles.tipsSection}>
          <Text style={styles.sectionTitle}>Travel Tips</Text>
          {flightService.getTravelTips().map((tip, index) => (
            <View key={index} style={styles.tipItem}>
              <Text style={styles.tipBullet}>•</Text>
              <Text style={styles.tipText}>{tip}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabScrollContainer}
        >
          {tabs.map(renderTabButton)}
        </ScrollView>
      </View>

      {/* Tab Content */}
      <ScrollView style={styles.contentContainer} showsVerticalScrollIndicator={false}>
        {activeTab === 'status' && renderStatusTab()}
        {activeTab === 'search' && renderSearchTab()}
        {activeTab === 'airports' && renderAirportsTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  tabContainer: {
    backgroundColor: 'white',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  tabScrollContainer: {
    paddingHorizontal: 20,
    gap: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    minWidth: 120,
  },
  tabButtonText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  tabButtonTextActive: {
    color: 'white',
  },
  contentContainer: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E5E5E5',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    backgroundColor: 'white',
    color: '#333',
  },
  rowContainer: {
    flexDirection: 'row',
    gap: 15,
  },
  halfWidth: {
    flex: 1,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  resultCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  resultHeader: {
    padding: 20,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  resultSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
  },
  resultContent: {
    padding: 20,
    gap: 16,
  },
  flightTiming: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  timeSection: {
    alignItems: 'center',
    flex: 1,
  },
  timeLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  timeValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  terminalText: {
    fontSize: 10,
    color: '#666',
    marginTop: 2,
  },
  gateText: {
    fontSize: 10,
    color: '#666',
  },
  statusSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
  },
  statusValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  delaySection: {
    backgroundColor: '#FFF3E0',
    padding: 12,
    borderRadius: 8,
  },
  delayText: {
    fontSize: 14,
    color: '#FF9800',
    fontWeight: '600',
  },
  statusMeaningsSection: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  statusMeaningItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginTop: 6,
    marginRight: 12,
  },
  statusMeaningText: {
    flex: 1,
  },
  statusMeaningTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  statusMeaningDesc: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  resultsContainer: {
    maxHeight: 500,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  flightCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  flightHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  flightAirline: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  flightNumber: {
    fontSize: 14,
    color: '#666',
  },
  durationContainer: {
    alignItems: 'center',
    gap: 4,
  },
  duration: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  stops: {
    fontSize: 10,
    color: '#FF9800',
  },
  flightDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  priceLabel: {
    fontSize: 12,
    color: '#666',
  },
  priceValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00A86B',
  },
  bookButton: {
    backgroundColor: '#00A86B',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  bookButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  popularSection: {
    marginTop: 20,
  },
  routeCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginRight: 12,
    minWidth: 140,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  routeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  routeDuration: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  routeFrequency: {
    fontSize: 10,
    color: '#00A86B',
    marginTop: 2,
  },
  airportCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  airportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  airportCode: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4285F4',
  },
  airportCity: {
    fontSize: 14,
    color: '#666',
  },
  airportName: {
    fontSize: 14,
    color: '#333',
  },
  airlinesSection: {
    marginTop: 20,
  },
  airlineCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  airlineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  airlineCode: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4285F4',
    marginRight: 8,
  },
  airlineName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  airlineType: {
    fontSize: 12,
    color: '#666',
  },
  tipsSection: {
    marginTop: 20,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  tipBullet: {
    fontSize: 16,
    color: '#4285F4',
    marginRight: 8,
    marginTop: 2,
  },
  tipText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 20,
  },
});