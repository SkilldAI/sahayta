import React, { useState } from 'react';
import { Modal, View, Text, TextInput, TouchableOpacity, ActivityIndicator, ScrollView, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MapPin, Search, Navigation, Phone, Fuel } from 'lucide-react-native';
import { fuelService, type PetrolPump } from '@/services/fuelService';

interface PetrolFinderProps {
  visible: boolean;
  onClose: () => void;
}

export const PetrolFinder: React.FC<PetrolFinderProps> = ({ visible, onClose }) => {
  const [city, setCity] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<PetrolPump[]>([]);

  const openMaps = (item: PetrolPump) => {
    if (item.coordinates?.latitude && item.coordinates?.longitude) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${item.coordinates.latitude},${item.coordinates.longitude}`;
      Linking.openURL(url);
    } else {
      const q = encodeURIComponent(`${item.name}, ${item.address || ''} ${item.city || ''}`);
      Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${q}`);
    }
  };

  const handleSearch = async () => {
    setError(null);
    if (!city.trim()) {
      setError('Please enter a city name.');
      return;
    }
    setLoading(true);
    try {
      const data = await fuelService.searchPetrolPumps(city.trim());
      setResults(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setError(e?.message || 'Failed to fetch petrol pumps.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
        <LinearGradient colors={["#003366", "#004080"]} style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 18 }}>
                <Fuel size={22} color="white" />
              </View>
              <View>
                <Text style={{ color: 'white', fontSize: 18, fontWeight: '700' }}>Find Petrol Pumps</Text>
                <Text style={{ color: 'rgba(255,255,255,0.9)' }}>Search by city and get directions</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={{ padding: 8 }}>
              <Text style={{ color: 'white', fontSize: 16 }}>Close</Text>
            </TouchableOpacity>
          </View>

          <View style={{ backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 14, padding: 8, marginTop: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <MapPin size={18} color="white" />
            <TextInput
              style={{ flex: 1, fontSize: 16, color: 'white' }}
              placeholder="Enter city (e.g., Pune)"
              placeholderTextColor="rgba(255,255,255,0.7)"
              value={city}
              onChangeText={setCity}
              returnKeyType="search"
              onSubmitEditing={handleSearch}
            />
            <TouchableOpacity onPress={handleSearch} disabled={loading}>
              {loading ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <Search size={18} color="white" />
              )}
            </TouchableOpacity>
          </View>
        </LinearGradient>

        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
          {error && (
            <View style={{ backgroundColor: '#FEF2F2', borderColor: '#FECACA', borderWidth: 1, padding: 10, borderRadius: 10, marginBottom: 12 }}>
              <Text style={{ color: '#991B1B' }}>{error}</Text>
            </View>
          )}

          {!loading && results.length === 0 && !error && (
            <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#E5E7EB' }}>
              <Text style={{ color: '#111', fontSize: 16, fontWeight: '600', marginBottom: 6 }}>No petrol pumps yet</Text>
              <Text style={{ color: '#6B7280' }}>Try a different city.</Text>
            </View>
          )}

          {results.map((p) => (
            <View key={p.id} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' }}>
              <Text style={{ color: '#111827', fontSize: 16, fontWeight: '700' }}>{p.name} • {p.brand}</Text>
              <Text style={{ color: '#4B5563', marginTop: 6, fontSize: 12 }}>{p.address}</Text>
              <Text style={{ color: '#6B7280', marginTop: 2, fontSize: 12 }}>{p.city}{p.pincode ? ` • ${p.pincode}` : ''}</Text>

              <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                {p.isOpen24Hours && (
                  <View style={{ backgroundColor: '#E8F5E8', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 }}>
                    <Text style={{ color: '#00A86B', fontSize: 11, fontWeight: '600' }}>Open 24x7</Text>
                  </View>
                )}
                {!!p.rating && (
                  <View style={{ backgroundColor: '#FFF7ED', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 }}>
                    <Text style={{ color: '#F97316', fontSize: 11, fontWeight: '600' }}>★ {p.rating}</Text>
                  </View>
                )}
                {Array.isArray(p.fuelTypes) && p.fuelTypes.slice(0,3).map((ft, idx) => (
                  <View key={idx} style={{ backgroundColor: '#EFF6FF', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 }}>
                    <Text style={{ color: '#1D4ED8', fontSize: 11, fontWeight: '600' }}>{ft}</Text>
                  </View>
                ))}
              </View>

              <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
                {p.contactNumber && (
                  <TouchableOpacity onPress={() => Linking.openURL(`tel:${p.contactNumber}`)}>
                    <View style={{ backgroundColor: '#00A86B', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Phone size={16} color="white" />
                      <Text style={{ color: 'white', fontWeight: '600' }}>Call</Text>
                    </View>
                  </TouchableOpacity>
                )}
                <TouchableOpacity onPress={() => openMaps(p)}>
                  <View style={{ backgroundColor: '#003366', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Navigation size={16} color="white" />
                    <Text style={{ color: 'white', fontWeight: '600' }}>Directions</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          ))}

          {loading && (
            <View style={{ padding: 20 }}>
              <ActivityIndicator size="large" color="#003366" />
              <Text style={{ textAlign: 'center', marginTop: 8, color: '#6B7280' }}>Fetching petrol pumps…</Text>
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
};

export default PetrolFinder;
