import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { Globe, Check, X } from 'lucide-react-native';
import { useLanguage, SUPPORTED_LANGUAGES, Language } from '@/contexts/LanguageContext';

interface LanguageSelectorProps {
  showIcon?: boolean;
  showText?: boolean;
  style?: any;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  showIcon = true,
  showText = true,
  style,
}) => {
  const { currentLanguage, setLanguage, t } = useLanguage();
  const [modalVisible, setModalVisible] = useState(false);
  const [isChanging, setIsChanging] = useState(false);

  const handleLanguageChange = async (language: Language) => {
    if (language.code === currentLanguage.code) {
      setModalVisible(false);
      return;
    }

    try {
      setIsChanging(true);
      await setLanguage(language);
      setModalVisible(false);
      
      // Show success message
      setTimeout(() => {
        Alert.alert(
          t('success'),
          t('language_changed'),
          [{ text: t('ok') }]
        );
      }, 100);
    } catch (error) {
      console.error('Error changing language:', error);
      Alert.alert(
        t('error'),
        'Failed to change language',
        [{ text: t('ok') }]
      );
    } finally {
      setIsChanging(false);
    }
  };

  return (
    <>
      <TouchableOpacity
        onPress={() => setModalVisible(true)}
        style={[
          {
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: 'rgba(255,255,255,0.2)',
            paddingHorizontal: 12,
            paddingVertical: 8,
            borderRadius: 20,
            gap: 6,
          },
          style,
        ]}
      >
        {showIcon && <Globe size={16} color="white" />}
        {showText && (
          <Text style={{ color: 'white', fontSize: 12, fontWeight: '500' }}>
            {currentLanguage.code.toUpperCase()}
          </Text>
        )}
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View
          style={{
            flex: 1,
            justifyContent: 'flex-end',
            backgroundColor: 'rgba(0,0,0,0.5)',
          }}
        >
          <View
            style={{
              backgroundColor: 'white',
              borderTopLeftRadius: 20,
              borderTopRightRadius: 20,
              maxHeight: '80%',
            }}
          >
            {/* Header */}
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                paddingHorizontal: 20,
                paddingVertical: 15,
                borderBottomWidth: 1,
                borderBottomColor: '#F5F5F5',
              }}
            >
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366' }}>
                {t('select_language')}
              </Text>
              <TouchableOpacity
                onPress={() => setModalVisible(false)}
                style={{
                  padding: 5,
                }}
              >
                <X size={20} color="#666" />
              </TouchableOpacity>
            </View>

            {/* Language List */}
            <ScrollView
              style={{ maxHeight: 400 }}
              showsVerticalScrollIndicator={false}
            >
              {SUPPORTED_LANGUAGES.map((language) => (
                <TouchableOpacity
                  key={language.code}
                  onPress={() => handleLanguageChange(language)}
                  disabled={isChanging}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingHorizontal: 20,
                    paddingVertical: 15,
                    borderBottomWidth: 1,
                    borderBottomColor: '#F8F8F8',
                    opacity: isChanging ? 0.6 : 1,
                  }}
                >
                  <Text style={{ fontSize: 24, marginRight: 15 }}>
                    {language.flag}
                  </Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: '600', color: '#333' }}>
                      {language.nativeName}
                    </Text>
                    <Text style={{ fontSize: 14, color: '#666', marginTop: 2 }}>
                      {language.name}
                    </Text>
                  </View>
                  {currentLanguage.code === language.code && (
                    <Check size={20} color="#00A86B" />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Footer */}
            <View
              style={{
                paddingHorizontal: 20,
                paddingVertical: 15,
                borderTopWidth: 1,
                borderTopColor: '#F5F5F5',
              }}
            >
              <Text style={{ fontSize: 12, color: '#999', textAlign: 'center' }}>
                {t('change_language')}
              </Text>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
};