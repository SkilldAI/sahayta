import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Plus,
  X,
  Calendar,
  CreditCard,
  CheckCircle,
  Clock,
  AlertTriangle,
  Search,
  Trash2,
} from 'lucide-react-native';
import { BillService, Bill, billProviders } from '@/services/billService';
import { useAuth } from '@/contexts/AuthContext';

const { width } = Dimensions.get('window');

interface BillManagerProps {
  onBillAdded?: () => void;
  onBillPaid?: () => void;
}

export default function BillManager({ onBillAdded, onBillPaid }: BillManagerProps) {
  const { user } = useAuth();
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPayModal, setShowPayModal] = useState(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [paymentProcessing, setPaymentProcessing] = useState(false);

  // Add bill form state
  const [billType, setBillType] = useState('');
  const [providerName, setProviderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [fetchingBill, setFetchingBill] = useState(false);

  useEffect(() => {
    if (user) {
      loadBills();
    }
  }, [user]);

  const loadBills = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const userBills = await BillService.getUserBills(user.id);
      setBills(userBills);
    } catch (error) {
      Alert.alert('Error', 'Failed to load bills');
    } finally {
      setLoading(false);
    }
  };

  const handleAddBill = async () => {
    if (!user || !billType || !providerName || !accountNumber) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    try {
      setFetchingBill(true);
      
      // Fetch bill details from provider (simulated)
      const billDetails = await BillService.fetchBillDetails(providerName, accountNumber);
      
      const newBill = await BillService.addBill({
        userId: user.id,
        billType,
        providerName,
        accountNumber,
        amount: amount || billDetails.amount,
        dueDate: dueDate || billDetails.dueDate,
        paymentStatus: 'pending',
        reminderEnabled: true,
      });

      setBills(prev => [newBill, ...prev]);
      resetAddForm();
      setShowAddModal(false);
      onBillAdded?.();
      
      Alert.alert('Success', 'Bill added successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to add bill');
    } finally {
      setFetchingBill(false);
    }
  };

  const handlePayBill = async (paymentMethod: string) => {
    if (!selectedBill) return;

    try {
      setPaymentProcessing(true);
      
      const result = await BillService.processPayment(
        selectedBill.id,
        selectedBill.amount,
        paymentMethod
      );

      if (result.success) {
        // Update local state
        setBills(prev => prev.map(bill => 
          bill.id === selectedBill.id 
            ? { ...bill, paymentStatus: 'paid' as const, paymentDate: new Date().toISOString() }
            : bill
        ));
        
        setShowPayModal(false);
        setSelectedBill(null);
        onBillPaid?.();
        
        Alert.alert(
          'Payment Successful!',
          `Transaction ID: ${result.transactionId}`,
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert('Payment Failed', result.message);
      }
    } catch (error) {
      Alert.alert('Error', 'Payment processing failed');
    } finally {
      setPaymentProcessing(false);
    }
  };

  const handleDeleteBill = (bill: Bill) => {
    Alert.alert(
      'Delete Bill',
      `Are you sure you want to delete ${bill.providerName} bill?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await BillService.deleteBill(bill.id);
              setBills(prev => prev.filter(b => b.id !== bill.id));
              Alert.alert('Success', 'Bill deleted successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to delete bill');
            }
          },
        },
      ]
    );
  };

  const resetAddForm = () => {
    setBillType('');
    setProviderName('');
    setAccountNumber('');
    setAmount('');
    setDueDate('');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return '#00A86B';
      case 'pending': return '#FF9800';
      case 'overdue': return '#F44336';
      default: return '#666';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return CheckCircle;
      case 'pending': return Clock;
      case 'overdue': return AlertTriangle;
      default: return Clock;
    }
  };

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <ActivityIndicator size="large" color="#00A86B" />
        <Text style={{ marginTop: 10, color: '#666' }}>Loading bills...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      {/* Bills List */}
      <ScrollView showsVerticalScrollIndicator={false}>
        {bills.length === 0 ? (
          <View style={{ alignItems: 'center', padding: 40 }}>
            <CreditCard size={48} color="#ccc" />
            <Text style={{ fontSize: 18, color: '#666', marginTop: 15, textAlign: 'center' }}>
              No bills added yet
            </Text>
            <Text style={{ fontSize: 14, color: '#999', marginTop: 5, textAlign: 'center' }}>
              Add your first bill to get started
            </Text>
          </View>
        ) : (
          <View style={{ padding: 20 }}>
            {bills.map((bill) => {
              const StatusIcon = getStatusIcon(bill.paymentStatus);
              const daysUntilDue = getDaysUntilDue(bill.dueDate);
              
              return (
                <View
                  key={bill.id}
                  style={{
                    backgroundColor: 'white',
                    borderRadius: 12,
                    padding: 15,
                    marginBottom: 10,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 4,
                    elevation: 3,
                  }}
                >
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                        {bill.providerName}
                      </Text>
                      <Text style={{ fontSize: 14, color: '#00A86B', fontWeight: '600', marginBottom: 5 }}>
                        ₹{bill.amount}
                      </Text>
                      <Text style={{ fontSize: 12, color: '#666', marginBottom: 5 }}>
                        Account: {bill.accountNumber}
                      </Text>
                      <Text style={{ fontSize: 12, color: '#666' }}>
                        Due: {new Date(bill.dueDate).toLocaleDateString()}
                        {daysUntilDue >= 0 && bill.paymentStatus === 'pending' && (
                          <Text style={{ color: daysUntilDue <= 3 ? '#F44336' : '#666' }}>
                            {' '}({daysUntilDue} days)
                          </Text>
                        )}
                      </Text>
                    </View>
                    
                    <View style={{ alignItems: 'flex-end' }}>
                      <View style={{ alignItems: 'center', marginBottom: 10 }}>
                        <StatusIcon size={20} color={getStatusColor(bill.paymentStatus)} />
                        <Text style={{ fontSize: 12, color: getStatusColor(bill.paymentStatus), marginTop: 2 }}>
                          {bill.paymentStatus.charAt(0).toUpperCase() + bill.paymentStatus.slice(1)}
                        </Text>
                      </View>
                      
                      <View style={{ flexDirection: 'row', gap: 5 }}>
                        {bill.paymentStatus === 'pending' && (
                          <TouchableOpacity
                            onPress={() => {
                              setSelectedBill(bill);
                              setShowPayModal(true);
                            }}
                            style={{
                              backgroundColor: '#00A86B',
                              paddingHorizontal: 12,
                              paddingVertical: 6,
                              borderRadius: 15,
                            }}
                          >
                            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                              Pay
                            </Text>
                          </TouchableOpacity>
                        )}
                        
                        <TouchableOpacity
                          onPress={() => handleDeleteBill(bill)}
                          style={{
                            backgroundColor: '#F44336',
                            paddingHorizontal: 8,
                            paddingVertical: 6,
                            borderRadius: 15,
                          }}
                        >
                          <Trash2 size={12} color="white" />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>

      {/* Add Bill Button */}
      <TouchableOpacity
        onPress={() => setShowAddModal(true)}
        style={{
          position: 'absolute',
          bottom: 20,
          right: 20,
          backgroundColor: '#00A86B',
          width: 56,
          height: 56,
          borderRadius: 28,
          justifyContent: 'center',
          alignItems: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.3,
          shadowRadius: 8,
          elevation: 8,
        }}
      >
        <Plus size={24} color="white" />
      </TouchableOpacity>

      {/* Add Bill Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
          <LinearGradient
            colors={['#00A86B', '#00C878']}
            style={{
              paddingHorizontal: 20,
              paddingVertical: 20,
              paddingTop: 50,
            }}
          >
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ color: 'white', fontSize: 20, fontWeight: 'bold' }}>
                Add New Bill
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowAddModal(false);
                  resetAddForm();
                }}
              >
                <X size={24} color="white" />
              </TouchableOpacity>
            </View>
          </LinearGradient>

          <ScrollView style={{ flex: 1, padding: 20 }}>
            {/* Bill Type Selection */}
            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 10 }}>
                Bill Type *
              </Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View style={{ flexDirection: 'row', gap: 10 }}>
                  {Object.keys(billProviders).map((type) => (
                    <TouchableOpacity
                      key={type}
                      onPress={() => {
                        setBillType(type);
                        setProviderName('');
                      }}
                      style={{
                        paddingHorizontal: 20,
                        paddingVertical: 10,
                        borderRadius: 20,
                        backgroundColor: billType === type ? '#00A86B' : '#F5F5F5',
                        borderWidth: 1,
                        borderColor: billType === type ? '#00A86B' : '#E5E5E5',
                      }}
                    >
                      <Text
                        style={{
                          color: billType === type ? 'white' : '#333',
                          fontWeight: '600',
                          textTransform: 'capitalize',
                        }}
                      >
                        {type}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>
            </View>

            {/* Provider Selection */}
            {billType && (
              <View style={{ marginBottom: 20 }}>
                <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 10 }}>
                  Provider *
                </Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    {billProviders[billType]?.map((provider) => (
                      <TouchableOpacity
                        key={provider.id}
                        onPress={() => setProviderName(provider.name)}
                        style={{
                          paddingHorizontal: 15,
                          paddingVertical: 10,
                          borderRadius: 15,
                          backgroundColor: providerName === provider.name ? '#00A86B' : '#F5F5F5',
                          borderWidth: 1,
                          borderColor: providerName === provider.name ? '#00A86B' : '#E5E5E5',
                        }}
                      >
                        <Text
                          style={{
                            color: providerName === provider.name ? 'white' : '#333',
                            fontWeight: '600',
                            fontSize: 14,
                          }}
                        >
                          {provider.name}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              </View>
            )}

            {/* Account Number */}
            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 10 }}>
                Account/Consumer Number *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: '#E5E5E5',
                  borderRadius: 10,
                  paddingHorizontal: 15,
                  paddingVertical: 12,
                  fontSize: 16,
                  backgroundColor: 'white',
                }}
                placeholder="Enter account number"
                value={accountNumber}
                onChangeText={setAccountNumber}
              />
            </View>

            {/* Optional Amount */}
            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 10 }}>
                Amount (Optional)
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: '#E5E5E5',
                  borderRadius: 10,
                  paddingHorizontal: 15,
                  paddingVertical: 12,
                  fontSize: 16,
                  backgroundColor: 'white',
                }}
                placeholder="Will be fetched automatically"
                value={amount}
                onChangeText={setAmount}
                keyboardType="numeric"
              />
            </View>

            {/* Optional Due Date */}
            <View style={{ marginBottom: 30 }}>
              <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 10 }}>
                Due Date (Optional)
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: '#E5E5E5',
                  borderRadius: 10,
                  paddingHorizontal: 15,
                  paddingVertical: 12,
                  fontSize: 16,
                  backgroundColor: 'white',
                }}
                placeholder="YYYY-MM-DD (Will be fetched automatically)"
                value={dueDate}
                onChangeText={setDueDate}
              />
            </View>

            {/* Add Button */}
            <TouchableOpacity
              onPress={handleAddBill}
              disabled={fetchingBill || !billType || !providerName || !accountNumber}
              style={{
                backgroundColor: fetchingBill || !billType || !providerName || !accountNumber ? '#ccc' : '#00A86B',
                paddingVertical: 15,
                borderRadius: 10,
                alignItems: 'center',
                marginBottom: 20,
              }}
            >
              {fetchingBill ? (
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <ActivityIndicator size="small" color="white" />
                  <Text style={{ color: 'white', fontSize: 16, fontWeight: '600', marginLeft: 10 }}>
                    Fetching Bill Details...
                  </Text>
                </View>
              ) : (
                <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                  Add Bill
                </Text>
              )}
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>

      {/* Payment Modal */}
      <Modal
        visible={showPayModal}
        animationType="slide"
        transparent={true}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: 'white', borderRadius: 20, padding: 20, width: width - 40, maxHeight: '80%' }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333' }}>
                Pay Bill
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowPayModal(false);
                  setSelectedBill(null);
                }}
              >
                <X size={24} color="#666" />
              </TouchableOpacity>
            </View>

            {selectedBill && (
              <>
                <View style={{ backgroundColor: '#F8F9FA', borderRadius: 10, padding: 15, marginBottom: 20 }}>
                  <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                    {selectedBill.providerName}
                  </Text>
                  <Text style={{ fontSize: 20, color: '#00A86B', fontWeight: 'bold', marginBottom: 5 }}>
                    ₹{selectedBill.amount}
                  </Text>
                  <Text style={{ fontSize: 12, color: '#666' }}>
                    Account: {selectedBill.accountNumber}
                  </Text>
                </View>

                <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 15 }}>
                  Select Payment Method
                </Text>

                <View style={{ gap: 10 }}>
                  {['UPI', 'Debit Card', 'Credit Card', 'Net Banking', 'Wallet'].map((method) => (
                    <TouchableOpacity
                      key={method}
                      onPress={() => handlePayBill(method)}
                      disabled={paymentProcessing}
                      style={{
                        backgroundColor: paymentProcessing ? '#F5F5F5' : '#00A86B',
                        paddingVertical: 15,
                        borderRadius: 10,
                        alignItems: 'center',
                        opacity: paymentProcessing ? 0.6 : 1,
                      }}
                    >
                      {paymentProcessing ? (
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                          <ActivityIndicator size="small" color="#666" />
                          <Text style={{ color: '#666', fontSize: 16, fontWeight: '600', marginLeft: 10 }}>
                            Processing...
                          </Text>
                        </View>
                      ) : (
                        <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                          Pay with {method}
                        </Text>
                      )}
                    </TouchableOpacity>
                  ))}
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}