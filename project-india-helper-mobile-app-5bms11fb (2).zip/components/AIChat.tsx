import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  MessageCircle,
  Send,
  X,
  Bot,
  User,
  Mic,
  Globe,
  Sparkles,
} from 'lucide-react-native';
import { blink } from '@/lib/blink';
import { useLanguage } from '@/contexts/LanguageContext';

const { width, height } = Dimensions.get('window');

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  language?: string;
}

interface AIChatProps {
  visible: boolean;
  onClose: () => void;
}

export function AIChat({ visible, onClose }: AIChatProps) {
  const { t, currentLanguage } = useLanguage();
  const langCode = currentLanguage?.code || 'en';
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  // Welcome message based on language
  useEffect(() => {
    if (visible && messages.length === 0) {
      const welcomeMessages = {
        en: "Hello! I'm your India Helper AI assistant. I can help you with government services, transportation, bills, emergency contacts, and general queries about India. How can I assist you today?",
        hi: "नमस्ते! मैं आपका इंडिया हेल्पर AI सहायक हूं। मैं आपकी सरकारी सेवाओं, परिवहन, बिलों, आपातकालीन संपर्कों और भारत के बारे में सामान्य प्रश्नों में मदद कर सकता हूं। आज मैं आपकी कैसे सहायता कर सकता हूं?",
        ta: "வணக்கம்! நான் உங்கள் இந்தியா ஹெல்பர் AI உதவியாளர். அரசு சேவைகள், போக்குவரத்து, பில்கள், அவசர தொடர்புகள் மற்றும் இந்தியா பற்றிய பொதுவான கேள்விகளில் உங்களுக்கு உதவ முடியும். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?"
      } as const;

      const welcomeMessage: Message = {
        id: Date.now().toString(),
        text: welcomeMessages[langCode as keyof typeof welcomeMessages] || welcomeMessages.en,
        isUser: false,
        timestamp: new Date(),
        language: langCode,
      };

      setMessages([welcomeMessage]);
    }
  }, [visible, langCode]);

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  // Simple script checks to validate language output
  const isLikelyHindi = (text: string) => /[\u0900-\u097F]/.test(text); // Devanagari
  const isLikelyTamil = (text: string) => /[\u0B80-\u0BFF]/.test(text); // Tamil

  const enforceLanguageIfNeeded = async (text: string): Promise<string> => {
    try {
      if (langCode === 'hi' && !isLikelyHindi(text)) {
        const { text: translated } = await blink.ai.generateText({
          prompt: `Translate the following text into natural, fluent Hindi (हिन्दी) using Devanagari script. Only return the translated text, nothing else.\n\nText:\n${text}`,
          model: 'gpt-4.1-mini',
          maxTokens: 300,
        });
        return translated;
      }
      if (langCode === 'ta' && !isLikelyTamil(text)) {
        const { text: translated } = await blink.ai.generateText({
          prompt: `Translate the following text into natural, fluent Tamil (தமிழ்). Only return the translated text, nothing else.\n\nText:\n${text}`,
          model: 'gpt-4.1-mini',
          maxTokens: 300,
        });
        return translated;
      }
      // English or already correct script
      return text;
    } catch (e) {
      return text; // fallback silently
    }
  };

  const getAIResponse = async (userMessage: string): Promise<string> => {
    try {
      // Create a context-aware prompt for Indian queries with explicit language instruction
      const languageInstruction = langCode === 'hi'
        ? 'IMPORTANT: You MUST respond in Hindi (हिन्दी) using Devanagari script only.'
        : langCode === 'ta'
        ? 'IMPORTANT: You MUST respond in Tamil (தமிழ்) using Tamil script only.'
        : 'IMPORTANT: You MUST respond in English only.';

      const systemText = `You are an AI assistant specifically designed to help Indians with everyday tasks and queries.\n\n${languageInstruction}\n\nYou should:\n1. Provide helpful information about Indian government services, transportation, utilities, and local services\n2. Be knowledgeable about Indian culture, festivals, and regional differences\n3. Help with queries about Aadhaar, PAN, GST, railway bookings, bill payments, etc.\n4. Keep responses concise but informative (2-3 sentences maximum)\n5. Be culturally sensitive and aware of Indian context\n6. If you don't know something specific, suggest where they might find the information\n\nRemember: Respond ONLY in ${langCode === 'hi' ? 'Hindi (हिन्दी)' : langCode === 'ta' ? 'Tamil (தமிழ்)' : 'English'}.`;

      const { text } = await blink.ai.generateText({
        messages: [
          { role: 'system', content: systemText },
          { role: 'user', content: userMessage },
        ],
        model: 'gpt-4.1-mini',
        maxTokens: 300,
      });
      // Enforce script if model slipped
      const ensured = await enforceLanguageIfNeeded(text);
      return ensured;
    } catch (error) {
      console.error('AI response error:', error);
      
      // Fallback responses in different languages
      const fallbackMessages = {
        en: "I'm sorry, I'm having trouble connecting right now. Please try again in a moment. For urgent queries, you can use the emergency services section.",
        hi: "मुझे खेद है, मुझे अभी कनेक्ट करने में परेशानी हो रही है। कृपया एक क्षण में फिर से कोशिश करें। तत्काल प्रश्नों के लिए, आप आपातकालीन सेवा अनुभाग का उपयोग कर सकते हैं।",
        ta: "மன்னிக்கவும், இப்போது இணைப்பதில் சிக்கல் உள்ளது. தயவுசெய்து சிறிது நேரம் கழித்து மீண்டும் முயற்சிக்கவும். அவசர கேள்விகளுக்கு, அவசர சேவைகள் பிரிவைப் பயன்படுத்தலாம்."
      } as const;

      return fallbackMessages[langCode as keyof typeof fallbackMessages] || fallbackMessages.en;
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      isUser: true,
      timestamp: new Date(),
      language: langCode,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);
    scrollToBottom();

    try {
      const aiResponse = await getAIResponse(userMessage.text);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date(),
        language: langCode,
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error getting AI response:', error);
    } finally {
      setIsLoading(false);
      scrollToBottom();
    }
  };

  const handleVoiceInput = () => {
    Alert.alert(
      t('voice_input') || 'Voice Input',
      t('voice_input_coming_soon') || 'Voice input feature coming soon!',
      [{ text: 'OK' }]
    );
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const suggestedQueries = [
    {
      en: "How to apply for Aadhaar card?",
      hi: "आधार कार्ड के लिए आवेदन कैसे करें?",
      ta: "ஆதார் கார்டுக்கு எப்படி விண்ணப்பிக்கலாம்?"
    },
    {
      en: "Check PNR status",
      hi: "PNR स्थिति जांचें",
      ta: "PNR நிலையை சரிபார்க்கவும்"
    },
    {
      en: "GST calculation help",
      hi: "GST गणना सहायता",
      ta: "GST கணக்கீடு உதவி"
    },
    {
      en: "Emergency numbers",
      hi: "आपातकालीन नंबर",
      ta: "அவசர எண்கள்"
    }
  ] as const;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.container}>
        {/* Header */}
        <LinearGradient
          colors={['#003366', '#004080']}
          style={styles.header}
        >
          <View style={styles.headerContent}>
            <View style={styles.headerLeft}>
              <View style={styles.botIcon}>
                <Bot size={24} color="white" />
              </View>
              <View>
                <Text style={styles.headerTitle}>India Helper AI</Text>
                <Text style={styles.headerSubtitle}>
                  {isLoading ? (langCode === 'hi' ? 'टाइप कर रहा है...' : langCode === 'ta' ? 'தட்டச்சு செய்கிறது...' : 'Typing...') : (langCode === 'hi' ? 'ऑनलाइन' : langCode === 'ta' ? 'ஆன்லைன்' : 'Online')}
                </Text>
              </View>
            </View>
            
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color="white" />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        <KeyboardAvoidingView 
          style={styles.chatContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          {/* Messages */}
          <ScrollView
            ref={scrollViewRef}
            style={styles.messagesContainer}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.messagesContent}
          >
            {messages.map((message) => (
              <View
                key={message.id}
                style={[
                  styles.messageContainer,
                  message.isUser ? styles.userMessageContainer : styles.aiMessageContainer,
                ]}
              >
                {!message.isUser && (
                  <View style={styles.aiAvatar}>
                    <Bot size={16} color="#003366" />
                  </View>
                )}
                
                <View
                  style={[
                    styles.messageBubble,
                    message.isUser ? styles.userMessageBubble : styles.aiMessageBubble,
                  ]}
                >
                  <Text
                    style={[
                      styles.messageText,
                      message.isUser ? styles.userMessageText : styles.aiMessageText,
                    ]}
                  >
                    {message.text}
                  </Text>
                  <Text
                    style={[
                      styles.messageTime,
                      message.isUser ? styles.userMessageTime : styles.aiMessageTime,
                    ]}
                  >
                    {formatTime(message.timestamp)}
                  </Text>
                </View>

                {message.isUser && (
                  <View style={styles.userAvatar}>
                    <User size={16} color="white" />
                  </View>
                )}
              </View>
            ))}

            {isLoading && (
              <View style={styles.loadingContainer}>
                <View style={styles.aiAvatar}>
                  <Bot size={16} color="#003366" />
                </View>
                <View style={styles.loadingBubble}>
                  <ActivityIndicator size="small" color="#003366" />
                  <Text style={styles.loadingText}>
                    {langCode === 'hi' ? 'सोच रहा है...' : langCode === 'ta' ? 'யோசித்துக்கொண்டிருக்கிறது...' : 'Thinking...'}
                  </Text>
                </View>
              </View>
            )}

            {/* Suggested Queries */}
            {messages.length <= 1 && !isLoading && (
              <View style={styles.suggestionsContainer}>
                <Text style={styles.suggestionsTitle}>
                  {langCode === 'hi' ? 'पूछने की कोशिश करें:' : langCode === 'ta' ? 'கேட்க முயற்சிக்கவும்:' : 'Try asking:'}
                </Text>
                {suggestedQueries.map((query, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.suggestionButton}
                    onPress={() => setInputText((query as any)[langCode] || query.en)}
                  >
                    <Sparkles size={16} color="#003366" />
                    <Text style={styles.suggestionText}>
                      {(query as any)[langCode] || query.en}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </ScrollView>

          {/* Input Area */}
          <View style={styles.inputContainer}>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.textInput}
                placeholder={t('type_your_message') || 'Type your message...'}
                placeholderTextColor="#999"
                value={inputText}
                onChangeText={setInputText}
                multiline
                maxLength={500}
                onSubmitEditing={handleSendMessage}
                blurOnSubmit={false}
              />
              
              <View style={styles.inputActions}>
                <TouchableOpacity
                  onPress={handleVoiceInput}
                  style={styles.voiceButton}
                >
                  <Mic size={20} color="#666" />
                </TouchableOpacity>
                
                <TouchableOpacity
                  onPress={handleSendMessage}
                  style={[
                    styles.sendButton,
                    (!inputText.trim() || isLoading) && styles.sendButtonDisabled,
                  ]}
                  disabled={!inputText.trim() || isLoading}
                >
                  <Send size={20} color="white" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  botIcon: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 8,
    borderRadius: 20,
  },
  headerTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  closeButton: {
    padding: 8,
  },
  chatContainer: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
    paddingBottom: 20,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
  },
  userMessageContainer: {
    justifyContent: 'flex-end',
  },
  aiMessageContainer: {
    justifyContent: 'flex-start',
  },
  aiAvatar: {
    backgroundColor: '#E3F2FD',
    padding: 8,
    borderRadius: 16,
    marginRight: 8,
  },
  userAvatar: {
    backgroundColor: '#003366',
    padding: 8,
    borderRadius: 16,
    marginLeft: 8,
  },
  messageBubble: {
    maxWidth: width * 0.75,
    padding: 12,
    borderRadius: 16,
  },
  userMessageBubble: {
    backgroundColor: '#003366',
    borderBottomRightRadius: 4,
  },
  aiMessageBubble: {
    backgroundColor: 'white',
    borderBottomLeftRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
  },
  userMessageText: {
    color: 'white',
  },
  aiMessageText: {
    color: '#333',
  },
  messageTime: {
    fontSize: 12,
    marginTop: 4,
  },
  userMessageTime: {
    color: 'rgba(255,255,255,0.7)',
  },
  aiMessageTime: {
    color: '#999',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  loadingBubble: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  loadingText: {
    color: '#666',
    fontSize: 14,
  },
  suggestionsContainer: {
    marginTop: 20,
  },
  suggestionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#003366',
    marginBottom: 12,
  },
  suggestionButton: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  suggestionText: {
    color: '#333',
    fontSize: 14,
    flex: 1,
  },
  inputContainer: {
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#F5F5F5',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    maxHeight: 100,
    paddingVertical: 8,
  },
  inputActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginLeft: 8,
  },
  voiceButton: {
    padding: 8,
  },
  sendButton: {
    backgroundColor: '#003366',
    padding: 8,
    borderRadius: 20,
  },
  sendButtonDisabled: {
    backgroundColor: '#CCC',
  },
});