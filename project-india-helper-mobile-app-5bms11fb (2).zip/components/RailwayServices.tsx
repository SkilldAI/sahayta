import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  Alert, 
  ActivityIndicator, 
  StyleSheet,
  Dimensions 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Train, Search, Calendar, MapPin, Clock, Users, CreditCard, ArrowRight } from 'lucide-react-native';
import { railwayService, PNRStatus, TrainSchedule, SeatAvailability, TrainSearchResult } from '../services/railwayService';
import { useLanguage } from '../contexts/LanguageContext';

const { width } = Dimensions.get('window');

interface RailwayServicesProps {
  onServiceSelect?: (service: string) => void;
}

export default function RailwayServices({ onServiceSelect }: RailwayServicesProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'pnr' | 'search' | 'schedule' | 'availability'>('pnr');
  const [loading, setLoading] = useState(false);

  // PNR Status states
  const [pnrNumber, setPnrNumber] = useState('');
  const [pnrStatus, setPnrStatus] = useState<PNRStatus | null>(null);

  // Train Search states
  const [searchFrom, setSearchFrom] = useState('');
  const [searchTo, setSearchTo] = useState('');
  const [searchDate, setSearchDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchResults, setSearchResults] = useState<TrainSearchResult[]>([]);

  // Train Schedule states
  const [scheduleTrainNumber, setScheduleTrainNumber] = useState('');
  const [trainSchedule, setTrainSchedule] = useState<TrainSchedule | null>(null);

  // Seat Availability states
  const [availabilityTrainNumber, setAvailabilityTrainNumber] = useState('');
  const [availabilityFrom, setAvailabilityFrom] = useState('');
  const [availabilityTo, setAvailabilityTo] = useState('');
  const [availabilityDate, setAvailabilityDate] = useState(new Date().toISOString().split('T')[0]);
  const [seatAvailability, setSeatAvailability] = useState<SeatAvailability | null>(null);

  const handlePNRCheck = async () => {
    if (!railwayService.validatePNR(pnrNumber)) {
      Alert.alert('Error', 'Please enter a valid 10-digit PNR number');
      return;
    }

    setLoading(true);
    try {
      const status = await railwayService.getPNRStatus(pnrNumber);
      setPnrStatus(status);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to fetch PNR status');
    } finally {
      setLoading(false);
    }
  };

  const handleTrainSearch = async () => {
    if (!searchFrom || !searchTo || !searchDate) {
      Alert.alert('Error', 'Please fill all search fields');
      return;
    }

    setLoading(true);
    try {
      const results = await railwayService.searchTrains(searchFrom, searchTo, searchDate);
      setSearchResults(results);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to search trains');
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleCheck = async () => {
    if (!railwayService.validateTrainNumber(scheduleTrainNumber)) {
      Alert.alert('Error', 'Please enter a valid 5-digit train number');
      return;
    }

    setLoading(true);
    try {
      const schedule = await railwayService.getTrainSchedule(scheduleTrainNumber);
      setTrainSchedule(schedule);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to fetch train schedule');
    } finally {
      setLoading(false);
    }
  };

  const handleAvailabilityCheck = async () => {
    if (!availabilityTrainNumber || !availabilityFrom || !availabilityTo || !availabilityDate) {
      Alert.alert('Error', 'Please fill all availability fields');
      return;
    }

    setLoading(true);
    try {
      const availability = await railwayService.getSeatAvailability(
        availabilityTrainNumber,
        availabilityFrom,
        availabilityTo,
        availabilityDate
      );
      setSeatAvailability(availability);
    } catch (error) {
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to fetch seat availability');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { key: 'pnr', title: 'PNR Status', icon: Search, color: '#4285F4' },
    { key: 'search', title: 'Search Trains', icon: Train, color: '#00A86B' },
    { key: 'schedule', title: 'Schedule', icon: Clock, color: '#9C27B0' },
    { key: 'availability', title: 'Seats', icon: Users, color: '#FF6B35' },
  ];

  const renderTabButton = (tab: any) => (
    <TouchableOpacity
      key={tab.key}
      onPress={() => setActiveTab(tab.key as any)}
      style={[
        styles.tabButton,
        activeTab === tab.key && { backgroundColor: tab.color }
      ]}
    >
      <tab.icon 
        size={18} 
        color={activeTab === tab.key ? 'white' : '#666'} 
      />
      <Text style={[
        styles.tabButtonText,
        activeTab === tab.key && styles.tabButtonTextActive
      ]}>
        {tab.title}
      </Text>
    </TouchableOpacity>
  );

  const renderInputField = (
    label: string, 
    value: string, 
    onChangeText: (text: string) => void, 
    placeholder: string,
    keyboardType: 'default' | 'numeric' = 'default',
    maxLength?: number
  ) => (
    <View style={styles.inputContainer}>
      <Text style={styles.inputLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        style={styles.textInput}
        keyboardType={keyboardType}
        maxLength={maxLength}
        placeholderTextColor="#999"
      />
    </View>
  );

  const renderActionButton = (
    title: string, 
    onPress: () => void, 
    icon: React.ReactNode, 
    color: string,
    disabled: boolean = false
  ) => (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={[styles.actionButton, { backgroundColor: color }]}
    >
      {loading ? (
        <ActivityIndicator color="white" size="small" />
      ) : (
        <>
          {icon}
          <Text style={styles.actionButtonText}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );

  const renderPNRTab = () => (
    <View style={styles.tabContent}>
      {renderInputField(
        'PNR Number',
        pnrNumber,
        setPnrNumber,
        'Enter 10-digit PNR number',
        'numeric',
        10
      )}

      {renderActionButton(
        'Check PNR Status',
        handlePNRCheck,
        <Search size={20} color="white" />,
        '#4285F4'
      )}

      {pnrStatus && (
        <View style={styles.resultCard}>
          <LinearGradient
            colors={['#4285F4', '#5A9BF8']}
            style={styles.resultHeader}
          >
            <Text style={styles.resultTitle}>
              {pnrStatus.trainName} ({pnrStatus.trainNumber})
            </Text>
          </LinearGradient>
          
          <View style={styles.resultContent}>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>Journey Date:</Text>
              <Text style={styles.resultValue}>{pnrStatus.dateOfJourney}</Text>
            </View>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>Route:</Text>
              <Text style={styles.resultValue}>{pnrStatus.from} → {pnrStatus.to}</Text>
            </View>
            <View style={styles.resultRow}>
              <Text style={styles.resultLabel}>Chart Status:</Text>
              <Text style={[styles.resultValue, { color: '#00A86B', fontWeight: '600' }]}>
                {pnrStatus.chartStatus}
              </Text>
            </View>

            {pnrStatus.passengers.length > 0 && (
              <View style={styles.passengersSection}>
                <Text style={styles.sectionTitle}>Passengers</Text>
                {pnrStatus.passengers.map((passenger, index) => (
                  <View key={index} style={styles.passengerCard}>
                    <View style={styles.passengerHeader}>
                      <Text style={styles.passengerNumber}>
                        Passenger {passenger.passengerNumber}
                      </Text>
                      <Text style={[
                        styles.passengerStatus,
                        { color: passenger.currentStatus.includes('CNF') ? '#00A86B' : '#FF6B35' }
                      ]}>
                        {passenger.currentStatus}
                      </Text>
                    </View>
                    {passenger.coach && passenger.berth && (
                      <Text style={styles.passengerDetails}>
                        Coach: {passenger.coach} • Berth: {passenger.berth}
                      </Text>
                    )}
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      )}
    </View>
  );

  const renderSearchTab = () => (
    <View style={styles.tabContent}>
      <View style={styles.rowContainer}>
        <View style={styles.halfWidth}>
          {renderInputField('From Station', searchFrom, setSearchFrom, 'e.g., NDLS')}
        </View>
        <View style={styles.halfWidth}>
          {renderInputField('To Station', searchTo, setSearchTo, 'e.g., BCT')}
        </View>
      </View>

      {renderInputField('Journey Date', searchDate, setSearchDate, 'YYYY-MM-DD')}

      {renderActionButton(
        'Search Trains',
        handleTrainSearch,
        <Train size={20} color="white" />,
        '#00A86B'
      )}

      {searchResults.length > 0 && (
        <ScrollView style={styles.resultsContainer} showsVerticalScrollIndicator={false}>
          {searchResults.map((train, index) => (
            <View key={index} style={styles.trainCard}>
              <View style={styles.trainHeader}>
                <Text style={styles.trainName}>{train.trainName}</Text>
                <Text style={styles.trainNumber}>({train.trainNumber})</Text>
              </View>
              
              <View style={styles.trainTiming}>
                <View style={styles.timeSection}>
                  <Text style={styles.timeLabel}>Departure</Text>
                  <Text style={styles.timeValue}>{train.departureTime}</Text>
                </View>
                <ArrowRight size={16} color="#666" />
                <View style={styles.timeSection}>
                  <Text style={styles.timeLabel}>Arrival</Text>
                  <Text style={styles.timeValue}>{train.arrivalTime}</Text>
                </View>
                <View style={styles.durationSection}>
                  <Text style={styles.timeLabel}>Duration</Text>
                  <Text style={styles.durationValue}>{train.duration}</Text>
                </View>
              </View>
              
              {train.classes.length > 0 && (
                <View style={styles.classesSection}>
                  <Text style={styles.classesLabel}>Available Classes:</Text>
                  <Text style={styles.classesValue}>{train.classes.join(' • ')}</Text>
                </View>
              )}
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );

  const renderScheduleTab = () => (
    <View style={styles.tabContent}>
      {renderInputField(
        'Train Number',
        scheduleTrainNumber,
        setScheduleTrainNumber,
        'Enter 5-digit train number',
        'numeric',
        5
      )}

      {renderActionButton(
        'Get Schedule',
        handleScheduleCheck,
        <Clock size={20} color="white" />,
        '#9C27B0'
      )}

      {trainSchedule && (
        <View style={styles.resultCard}>
          <LinearGradient
            colors={['#9C27B0', '#BA68C8']}
            style={styles.resultHeader}
          >
            <Text style={styles.resultTitle}>
              {trainSchedule.trainName} ({trainSchedule.trainNumber})
            </Text>
          </LinearGradient>
          
          <ScrollView style={styles.scheduleContainer} showsVerticalScrollIndicator={false}>
            {trainSchedule.stations.map((station, index) => (
              <View key={index} style={styles.stationRow}>
                <View style={styles.stationInfo}>
                  <Text style={styles.stationName}>{station.stationName}</Text>
                  <Text style={styles.stationCode}>({station.stationCode})</Text>
                </View>
                <View style={styles.stationTiming}>
                  <View style={styles.stationTime}>
                    <Text style={styles.stationTimeLabel}>Arr</Text>
                    <Text style={styles.stationTimeValue}>{station.arrivalTime || '--'}</Text>
                  </View>
                  <View style={styles.stationTime}>
                    <Text style={styles.stationTimeLabel}>Dep</Text>
                    <Text style={styles.stationTimeValue}>{station.departureTime || '--'}</Text>
                  </View>
                  <View style={styles.stationDistance}>
                    <Text style={styles.stationTimeLabel}>Km</Text>
                    <Text style={styles.stationTimeValue}>{station.distance}</Text>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );

  const renderAvailabilityTab = () => (
    <View style={styles.tabContent}>
      {renderInputField(
        'Train Number',
        availabilityTrainNumber,
        setAvailabilityTrainNumber,
        'Enter 5-digit train number',
        'numeric',
        5
      )}

      <View style={styles.rowContainer}>
        <View style={styles.halfWidth}>
          {renderInputField('From Station', availabilityFrom, setAvailabilityFrom, 'Station code')}
        </View>
        <View style={styles.halfWidth}>
          {renderInputField('To Station', availabilityTo, setAvailabilityTo, 'Station code')}
        </View>
      </View>

      {renderInputField('Journey Date', availabilityDate, setAvailabilityDate, 'YYYY-MM-DD')}

      {renderActionButton(
        'Check Availability',
        handleAvailabilityCheck,
        <Users size={20} color="white" />,
        '#FF6B35'
      )}

      {seatAvailability && (
        <View style={styles.resultCard}>
          <LinearGradient
            colors={['#FF6B35', '#FF8A65']}
            style={styles.resultHeader}
          >
            <Text style={styles.resultTitle}>
              {seatAvailability.trainName} ({seatAvailability.trainNumber})
            </Text>
            <Text style={styles.resultSubtitle}>
              {seatAvailability.from} → {seatAvailability.to} • {seatAvailability.date}
            </Text>
          </LinearGradient>
          
          <View style={styles.resultContent}>
            {seatAvailability.classes.map((cls, index) => (
              <View key={index} style={styles.availabilityRow}>
                <View style={styles.classInfo}>
                  <Text style={styles.className}>{cls.className}</Text>
                  <Text style={styles.classCode}>({cls.classCode})</Text>
                </View>
                <View style={styles.availabilityInfo}>
                  <Text style={[
                    styles.availabilityStatus,
                    {
                      color: cls.availability.includes('AVAILABLE') ? '#00A86B' : 
                             cls.availability.includes('WAITING') ? '#FF9800' : '#F44336'
                    }
                  ]}>
                    {cls.availability}
                  </Text>
                  {cls.fare && (
                    <Text style={styles.fareText}>₹{cls.fare}</Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.tabScrollContainer}
        >
          {tabs.map(renderTabButton)}
        </ScrollView>
      </View>

      {/* Tab Content */}
      <ScrollView style={styles.contentContainer} showsVerticalScrollIndicator={false}>
        {activeTab === 'pnr' && renderPNRTab()}
        {activeTab === 'search' && renderSearchTab()}
        {activeTab === 'schedule' && renderScheduleTab()}
        {activeTab === 'availability' && renderAvailabilityTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  tabContainer: {
    backgroundColor: 'white',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  tabScrollContainer: {
    paddingHorizontal: 20,
    gap: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    minWidth: 100,
  },
  tabButtonText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
  },
  tabButtonTextActive: {
    color: 'white',
  },
  contentContainer: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#E5E5E5',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    backgroundColor: 'white',
    color: '#333',
  },
  rowContainer: {
    flexDirection: 'row',
    gap: 15,
  },
  halfWidth: {
    flex: 1,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  resultCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  resultHeader: {
    padding: 20,
  },
  resultTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  resultSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
  },
  resultContent: {
    padding: 20,
    gap: 16,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  resultLabel: {
    fontSize: 14,
    color: '#666',
  },
  resultValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  passengersSection: {
    gap: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  passengerCard: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    gap: 8,
  },
  passengerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  passengerNumber: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  passengerStatus: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  passengerDetails: {
    fontSize: 12,
    color: '#666',
  },
  resultsContainer: {
    maxHeight: 400,
  },
  trainCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  trainHeader: {
    marginBottom: 16,
  },
  trainName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  trainNumber: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  trainTiming: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  timeSection: {
    alignItems: 'center',
    flex: 1,
  },
  timeLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  timeValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  durationSection: {
    alignItems: 'center',
    flex: 1,
  },
  durationValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#00A86B',
  },
  classesSection: {
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 16,
  },
  classesLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  classesValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  scheduleContainer: {
    maxHeight: 400,
  },
  stationRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  stationInfo: {
    flex: 1,
  },
  stationName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  stationCode: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  stationTiming: {
    flexDirection: 'row',
    gap: 20,
  },
  stationTime: {
    alignItems: 'center',
  },
  stationTimeLabel: {
    fontSize: 10,
    color: '#666',
    marginBottom: 2,
  },
  stationTimeValue: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  stationDistance: {
    alignItems: 'center',
  },
  availabilityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  classInfo: {
    flex: 1,
  },
  className: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  classCode: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  availabilityInfo: {
    alignItems: 'flex-end',
  },
  availabilityStatus: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  fareText: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
});