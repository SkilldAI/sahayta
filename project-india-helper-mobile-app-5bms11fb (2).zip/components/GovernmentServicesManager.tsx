import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Modal,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  FileText,
  Car,
  Vote,
  Gift,
  X,
  CheckCircle,
  Clock,
  AlertCircle,
  ExternalLink,
  Calendar,
  IndianRupee,
  Users,
  FileCheck,
  Plus,
  Search,
} from 'lucide-react-native';
import { 
  GovernmentServiceManager, 
  GovernmentService, 
  governmentServiceCategories,
  ServiceItem 
} from '@/services/governmentService';
import { useAuth } from '@/contexts/AuthContext';

const { width } = Dimensions.get('window');

interface GovernmentServicesManagerProps {
  onApplicationSubmitted?: () => void;
}

const iconMap = {
  FileText,
  Car,
  Vote,
  Gift,
};

export default function GovernmentServicesManager({ onApplicationSubmitted }: GovernmentServicesManagerProps) {
  const { user } = useAuth();
  const [applications, setApplications] = useState<GovernmentService[]>([]);
  const [loading, setLoading] = useState(false);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [showApplicationModal, setShowApplicationModal] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [submittingApplication, setSubmittingApplication] = useState(false);

  useEffect(() => {
    if (user) {
      loadApplications();
    }
  }, [user]);

  const loadApplications = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const userApplications = await GovernmentServiceManager.getUserApplications(user.id);
      setApplications(userApplications);
    } catch (error) {
      Alert.alert('Error', 'Failed to load applications');
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = (service: ServiceItem, categoryId: string) => {
    setSelectedService(service);
    setSelectedCategory(categoryId);
    setShowServiceModal(true);
  };

  const handleApplyForService = () => {
    setShowServiceModal(false);
    setShowApplicationModal(true);
  };

  const handleSubmitApplication = async () => {
    if (!user || !selectedService) return;

    try {
      setSubmittingApplication(true);
      
      const newApplication = await GovernmentServiceManager.submitApplication({
        userId: user.id,
        serviceType: selectedCategory,
        serviceName: selectedService.name,
        status: 'pending',
        appliedDate: new Date().toISOString(),
        expectedCompletionDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        documentsRequired: selectedService.documentsRequired.join(', '),
        notes: 'Application submitted through India Helper app',
      });

      setApplications(prev => [newApplication, ...prev]);
      setShowApplicationModal(false);
      setSelectedService(null);
      onApplicationSubmitted?.();
      
      Alert.alert(
        'Application Submitted!',
        `Your application for ${selectedService.name} has been submitted successfully.\n\nApplication Number: ${newApplication.applicationNumber}`,
        [{ text: 'OK' }]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to submit application');
    } finally {
      setSubmittingApplication(false);
    }
  };

  const handleCheckStatus = async (application: GovernmentService) => {
    if (!application.applicationNumber) return;

    try {
      Alert.alert('Checking Status', 'Please wait while we check your application status...');
      
      const statusResult = await GovernmentServiceManager.checkApplicationStatus(application.applicationNumber);
      
      Alert.alert(
        'Application Status',
        `Status: ${statusResult.status.toUpperCase()}\nLast Updated: ${new Date(statusResult.lastUpdated).toLocaleDateString()}\n\nRemarks: ${statusResult.remarks}`,
        [{ text: 'OK' }]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to check application status');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#00A86B';
      case 'in_progress': return '#4285F4';
      case 'pending': return '#FF9800';
      case 'rejected': return '#F44336';
      default: return '#666';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'in_progress': return Clock;
      case 'pending': return Clock;
      case 'rejected': return AlertCircle;
      default: return Clock;
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <ActivityIndicator size="large" color="#003366" />
        <Text style={{ marginTop: 10, color: '#666' }}>Loading applications...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* My Applications */}
        {applications.length > 0 && (
          <View style={{ padding: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              My Applications
            </Text>
            {applications.slice(0, 3).map((application) => {
              const StatusIcon = getStatusIcon(application.status);
              
              return (
                <TouchableOpacity
                  key={application.id}
                  onPress={() => handleCheckStatus(application)}
                  style={{
                    backgroundColor: 'white',
                    borderRadius: 12,
                    padding: 15,
                    marginBottom: 10,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 4,
                    elevation: 3,
                  }}
                >
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                        {application.serviceName}
                      </Text>
                      <Text style={{ fontSize: 12, color: '#666', marginBottom: 5 }}>
                        Application: {application.applicationNumber}
                      </Text>
                      <Text style={{ fontSize: 12, color: '#666', marginBottom: 5 }}>
                        Applied: {new Date(application.appliedDate).toLocaleDateString()}
                      </Text>
                      {application.expectedCompletionDate && (
                        <Text style={{ fontSize: 12, color: '#666' }}>
                          Expected: {new Date(application.expectedCompletionDate).toLocaleDateString()}
                        </Text>
                      )}
                    </View>
                    
                    <View style={{ alignItems: 'center' }}>
                      <StatusIcon size={20} color={getStatusColor(application.status)} />
                      <Text style={{ fontSize: 12, color: getStatusColor(application.status), marginTop: 2, textAlign: 'center' }}>
                        {application.status.charAt(0).toUpperCase() + application.status.slice(1).replace('_', ' ')}
                      </Text>
                    </View>
                  </View>
                  
                  <TouchableOpacity
                    style={{
                      backgroundColor: '#003366',
                      paddingHorizontal: 15,
                      paddingVertical: 8,
                      borderRadius: 15,
                      alignSelf: 'flex-start',
                      marginTop: 10,
                    }}
                  >
                    <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                      Check Status
                    </Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              );
            })}
            
            {applications.length > 3 && (
              <TouchableOpacity
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  alignItems: 'center',
                  borderWidth: 1,
                  borderColor: '#E5E5E5',
                  borderStyle: 'dashed',
                }}
              >
                <Text style={{ color: '#003366', fontSize: 14, fontWeight: '600' }}>
                  View All Applications ({applications.length})
                </Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Service Categories */}
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Available Services
          </Text>
          
          {governmentServiceCategories.map((category) => {
            const IconComponent = iconMap[category.icon as keyof typeof iconMap] || FileText;
            
            return (
              <View key={category.id} style={{ marginBottom: 20 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                  <View
                    style={{
                      backgroundColor: category.color,
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginRight: 12,
                    }}
                  >
                    <IconComponent size={20} color="white" />
                  </View>
                  <View>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333' }}>
                      {category.title}
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>
                      {category.subtitle}
                    </Text>
                  </View>
                </View>
                
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: 'row', gap: 12 }}>
                    {category.services.map((service) => (
                      <TouchableOpacity
                        key={service.id}
                        onPress={() => handleServiceSelect(service, category.id)}
                        style={{
                          backgroundColor: 'white',
                          borderRadius: 12,
                          padding: 15,
                          width: 200,
                          shadowColor: '#000',
                          shadowOffset: { width: 0, height: 1 },
                          shadowOpacity: 0.1,
                          shadowRadius: 2,
                          elevation: 2,
                        }}
                      >
                        <Text style={{ fontSize: 14, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                          {service.name}
                        </Text>
                        <Text style={{ fontSize: 12, color: '#666', marginBottom: 8, lineHeight: 16 }}>
                          {service.description}
                        </Text>
                        
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 5 }}>
                          <Clock size={12} color="#666" />
                          <Text style={{ fontSize: 11, color: '#666', marginLeft: 5 }}>
                            {service.processingTime}
                          </Text>
                        </View>
                        
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                          <IndianRupee size={12} color="#666" />
                          <Text style={{ fontSize: 11, color: '#666', marginLeft: 5 }}>
                            {service.fees}
                          </Text>
                        </View>
                        
                        <TouchableOpacity
                          style={{
                            backgroundColor: category.color,
                            paddingVertical: 8,
                            paddingHorizontal: 12,
                            borderRadius: 15,
                            alignItems: 'center',
                          }}
                        >
                          <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                            View Details
                          </Text>
                        </TouchableOpacity>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>
              </View>
            );
          })}
        </View>

        {applications.length === 0 && (
          <View style={{ alignItems: 'center', padding: 40 }}>
            <FileText size={48} color="#ccc" />
            <Text style={{ fontSize: 18, color: '#666', marginTop: 15, textAlign: 'center' }}>
              No applications yet
            </Text>
            <Text style={{ fontSize: 14, color: '#999', marginTop: 5, textAlign: 'center' }}>
              Apply for government services to get started
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Service Details Modal */}
      <Modal
        visible={showServiceModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
          <LinearGradient
            colors={['#003366', '#004080']}
            style={{
              paddingHorizontal: 20,
              paddingVertical: 20,
              paddingTop: 50,
            }}
          >
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ color: 'white', fontSize: 20, fontWeight: 'bold', flex: 1 }}>
                {selectedService?.name}
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowServiceModal(false);
                  setSelectedService(null);
                }}
              >
                <X size={24} color="white" />
              </TouchableOpacity>
            </View>
          </LinearGradient>

          {selectedService && (
            <ScrollView style={{ flex: 1, padding: 20 }}>
              {/* Description */}
              <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 16, color: '#333', lineHeight: 24 }}>
                  {selectedService.description}
                </Text>
              </View>

              {/* Key Information */}
              <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
                  Key Information
                </Text>
                
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                  <Clock size={16} color="#666" />
                  <Text style={{ fontSize: 14, color: '#666', marginLeft: 10, fontWeight: '600' }}>
                    Processing Time: {selectedService.processingTime}
                  </Text>
                </View>
                
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                  <IndianRupee size={16} color="#666" />
                  <Text style={{ fontSize: 14, color: '#666', marginLeft: 10, fontWeight: '600' }}>
                    Fees: {selectedService.fees}
                  </Text>
                </View>
              </View>

              {/* Required Documents */}
              <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
                  Required Documents
                </Text>
                {selectedService.documentsRequired.map((doc, index) => (
                  <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                    <FileCheck size={16} color="#00A86B" />
                    <Text style={{ fontSize: 14, color: '#333', marginLeft: 10, flex: 1 }}>
                      {doc}
                    </Text>
                  </View>
                ))}
              </View>

              {/* Eligibility */}
              <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
                  Eligibility Criteria
                </Text>
                {selectedService.eligibility.map((criteria, index) => (
                  <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                    <Users size={16} color="#4285F4" />
                    <Text style={{ fontSize: 14, color: '#333', marginLeft: 10, flex: 1 }}>
                      {criteria}
                    </Text>
                  </View>
                ))}
              </View>

              {/* Application Steps */}
              <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
                  Application Process
                </Text>
                {selectedService.steps.map((step, index) => (
                  <View key={index} style={{ flexDirection: 'row', marginBottom: 12 }}>
                    <View
                      style={{
                        backgroundColor: '#003366',
                        width: 24,
                        height: 24,
                        borderRadius: 12,
                        justifyContent: 'center',
                        alignItems: 'center',
                        marginRight: 12,
                      }}
                    >
                      <Text style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>
                        {index + 1}
                      </Text>
                    </View>
                    <Text style={{ fontSize: 14, color: '#333', flex: 1, lineHeight: 20 }}>
                      {step}
                    </Text>
                  </View>
                ))}
              </View>

              {/* Official Website */}
              {selectedService.officialUrl && (
                <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
                  <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 }}>
                    Official Website
                  </Text>
                  <TouchableOpacity
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      backgroundColor: '#F8F9FA',
                      padding: 15,
                      borderRadius: 10,
                    }}
                  >
                    <ExternalLink size={16} color="#003366" />
                    <Text style={{ fontSize: 14, color: '#003366', marginLeft: 10, flex: 1 }}>
                      {selectedService.officialUrl}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Apply Button */}
              <TouchableOpacity
                onPress={handleApplyForService}
                style={{
                  backgroundColor: '#003366',
                  paddingVertical: 15,
                  borderRadius: 10,
                  alignItems: 'center',
                  marginBottom: 30,
                }}
              >
                <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                  Apply for This Service
                </Text>
              </TouchableOpacity>
            </ScrollView>
          )}
        </View>
      </Modal>

      {/* Application Confirmation Modal */}
      <Modal
        visible={showApplicationModal}
        animationType="slide"
        transparent={true}
      >
        <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: 'white', borderRadius: 20, padding: 20, width: width - 40, maxHeight: '80%' }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#333' }}>
                Confirm Application
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowApplicationModal(false);
                  setSelectedService(null);
                }}
              >
                <X size={24} color="#666" />
              </TouchableOpacity>
            </View>

            {selectedService && (
              <>
                <View style={{ backgroundColor: '#F8F9FA', borderRadius: 10, padding: 15, marginBottom: 20 }}>
                  <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                    {selectedService.name}
                  </Text>
                  <Text style={{ fontSize: 14, color: '#666', marginBottom: 10 }}>
                    {selectedService.description}
                  </Text>
                  <Text style={{ fontSize: 12, color: '#666' }}>
                    Processing Time: {selectedService.processingTime} • Fees: {selectedService.fees}
                  </Text>
                </View>

                <Text style={{ fontSize: 14, color: '#666', marginBottom: 20, lineHeight: 20 }}>
                  By submitting this application, you confirm that you meet all eligibility criteria and have the required documents ready. You will receive an application number for tracking.
                </Text>

                <TouchableOpacity
                  onPress={handleSubmitApplication}
                  disabled={submittingApplication}
                  style={{
                    backgroundColor: submittingApplication ? '#ccc' : '#003366',
                    paddingVertical: 15,
                    borderRadius: 10,
                    alignItems: 'center',
                    marginBottom: 10,
                  }}
                >
                  {submittingApplication ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <ActivityIndicator size="small" color="white" />
                      <Text style={{ color: 'white', fontSize: 16, fontWeight: '600', marginLeft: 10 }}>
                        Submitting...
                      </Text>
                    </View>
                  ) : (
                    <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                      Submit Application
                    </Text>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => setShowApplicationModal(false)}
                  style={{
                    backgroundColor: '#F5F5F5',
                    paddingVertical: 15,
                    borderRadius: 10,
                    alignItems: 'center',
                  }}
                >
                  <Text style={{ color: '#666', fontSize: 16, fontWeight: '600' }}>
                    Cancel
                  </Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}