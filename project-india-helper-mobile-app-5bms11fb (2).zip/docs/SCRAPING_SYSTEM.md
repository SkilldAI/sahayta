# India Helper App - Scraping System Documentation

## Overview

The India Helper mobile app now includes a comprehensive scraping system that provides real-time data for various services without waiting for API access. This system is designed to be modular, scalable, and easy to extend.

## Architecture

### 1. Universal Scraper (`functions/universal-scraper/index.ts`)
- **URL**: `https://5bms11fb--universal-scraper.functions.blink.new`
- **Purpose**: Central scraping service that handles multiple service types
- **Services Supported**:
  - Bus booking (RedBus, KSRTC, APSRTC)
  - Flight information (status, search)
  - Utility bills (BESCOM, KSEB, TNEB, BWSSB, IGL)
  - Hotel search (basic implementation)

### 2. Scheduler System (`functions/scraper-scheduler/index.ts`)
- **URL**: `https://5bms11fb--scraper-scheduler.functions.blink.new`
- **Purpose**: Manages periodic scraping jobs and caching
- **Features**:
  - Configurable scraping schedules
  - Job queue management
  - Result caching
  - Error handling and retry logic

### 3. Service Classes
- `services/busService.ts` - Bus booking and operator information
- `services/flightService.ts` - Flight status and search
- `services/utilityService.ts` - Utility bill checking and provider info
- `services/railwayService.ts` - Railway services (existing)

### 4. UI Components
- `components/BusServices.tsx` - Bus search and booking interface
- `components/FlightServices.tsx` - Flight status and search interface
- `components/UtilityServices.tsx` - Utility bill management interface
- `components/RailwayServices.tsx` - Railway services interface (existing)

## Supported Services

### Bus Services
**Sources**: RedBus, KSRTC, APSRTC
**Features**:
- Route search between cities
- Bus operator information
- Seat availability
- Fare comparison
- Amenities and ratings

**API Endpoints**:
```
POST /universal-scraper?service=bus&action=search
POST /universal-scraper?service=bus&action=operators
```

### Flight Services
**Sources**: FlightAware, airline websites
**Features**:
- Flight status by flight number
- Flight search between airports
- Airport information
- Airline details
- Delay notifications

**API Endpoints**:
```
POST /universal-scraper?service=flight&action=status
POST /universal-scraper?service=flight&action=search
```

### Utility Services
**Sources**: BESCOM, KSEB, TNEB, BWSSB, IGL
**Features**:
- Bill amount and due date
- Consumption details
- Payment status
- Provider information
- Emergency contacts

**API Endpoints**:
```
POST /universal-scraper?service=utility&action=bill-info
POST /universal-scraper?service=utility&action=providers
```

## Usage Examples

### Bus Search
```typescript
import { busService } from '../services/busService';

const buses = await busService.searchBuses('Bangalore', 'Chennai', '2024-02-15');
console.log(buses); // Array of BusSearchResult
```

### Flight Status
```typescript
import { flightService } from '../services/flightService';

const status = await flightService.getFlightStatus('6E-123');
console.log(status); // FlightInfo object
```

### Utility Bill Check
```typescript
import { utilityService } from '../services/utilityService';

const bill = await utilityService.getBillInfo('BESCOM', '1234567890');
console.log(bill); // UtilityBillInfo object
```

## Scheduler Configuration

### Default Schedules
- **Bus Operators**: Daily refresh
- **Flight Search**: Hourly for popular routes
- **Utility Providers**: Weekly refresh

### Adding Custom Schedules
```typescript
// Add a new scraping schedule
const response = await fetch('https://5bms11fb--scraper-scheduler.functions.blink.new?action=add-schedule', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    service: 'bus',
    action: 'search',
    interval: 60, // minutes
    enabled: true
  })
});
```

### Running Jobs Manually
```typescript
// Run a scraping job immediately
const response = await fetch('https://5bms11fb--scraper-scheduler.functions.blink.new?action=run-job', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    service: 'flight',
    action: 'status',
    data: { flightNumber: '6E-123' }
  })
});
```

## Adding New Services

### 1. Extend Universal Scraper
Add a new service handler in `functions/universal-scraper/index.ts`:

```typescript
// Add to the main switch statement
case 'hotel':
  return await handleHotelService(req, action);

// Implement the handler
async function handleHotelService(req: Request, action: string | null): Promise<Response> {
  switch (action) {
    case 'search':
      return await searchHotels(req);
    default:
      return createErrorResponse('Invalid hotel action');
  }
}
```

### 2. Create Service Class
Create `services/hotelService.ts`:

```typescript
export class HotelService {
  private async makeRequest(action: string, data: any): Promise<any> {
    // Implementation similar to other services
  }

  async searchHotels(location: string, checkIn: string, checkOut: string): Promise<HotelInfo[]> {
    return await this.makeRequest('search', { location, checkIn, checkOut });
  }
}
```

### 3. Create UI Component
Create `components/HotelServices.tsx` with search interface and results display.

### 4. Integrate with App
Add the new service to the appropriate tab in the mobile app.

## Error Handling

### Service Level
- Network timeouts
- Invalid responses
- Rate limiting
- Captcha challenges

### Scheduler Level
- Job failures
- Retry logic
- Dead letter queues
- Monitoring and alerts

## Performance Considerations

### Caching Strategy
- Results cached for appropriate durations
- Popular routes cached longer
- Real-time data (flight status) cached briefly

### Rate Limiting
- Respectful scraping intervals
- User-agent rotation
- IP rotation (if needed)
- Fallback to cached data

### Scalability
- Horizontal scaling of scraper functions
- Load balancing across multiple instances
- Database optimization for cached results

## Monitoring and Maintenance

### Health Checks
- Regular validation of scraping endpoints
- Data quality checks
- Performance monitoring

### Updates Required
- Website structure changes
- New data sources
- API endpoint changes
- Legal compliance updates

## Legal and Ethical Considerations

### Compliance
- Robots.txt compliance
- Terms of service adherence
- Rate limiting respect
- Data usage policies

### Best Practices
- Minimal data collection
- User privacy protection
- Transparent data sources
- Regular compliance reviews

## Future Enhancements

### Planned Features
1. **Machine Learning**: Predictive pricing and availability
2. **Real-time Updates**: WebSocket connections for live data
3. **Advanced Caching**: Redis integration for better performance
4. **Analytics**: Usage patterns and optimization insights
5. **API Gateway**: Centralized request management and throttling

### Additional Services
1. **Hotel Booking**: OYO, MakeMyTrip integration
2. **Cab Services**: Ola, Uber fare estimation
3. **Food Delivery**: Swiggy, Zomato menu scraping
4. **E-commerce**: Price comparison across platforms
5. **Government Services**: Form status checking

## Troubleshooting

### Common Issues
1. **Scraping Failures**: Check website structure changes
2. **Rate Limiting**: Implement backoff strategies
3. **Data Quality**: Validate scraped data format
4. **Performance**: Monitor response times and optimize

### Debug Tools
- Function logs via Blink dashboard
- Error tracking and reporting
- Performance metrics
- Data validation checks

## Contributing

### Adding New Scrapers
1. Follow the modular architecture
2. Implement proper error handling
3. Add comprehensive tests
4. Document API endpoints
5. Update this documentation

### Code Standards
- TypeScript strict mode
- Proper error handling
- Consistent naming conventions
- Comprehensive logging
- Performance optimization

---

This scraping system provides a robust foundation for accessing real-time data across multiple Indian services without waiting for official API access. The modular design makes it easy to add new services and maintain existing ones.