import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Users,
  FileText,
  CreditCard,
  MapPin,
  Settings,
  LogOut,
  Eye,
  Trash2,
  Edit,
  Calendar,
  TrendingUp,
  Shield,
  Database,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { blink } from '@/lib/blink';

interface User {
  id: string;
  email: string;
  display_name: string;
  phone_number?: string;
  preferred_language: string;
  location_state?: string;
  location_city?: string;
  aadhaar_linked: string;
  pan_linked: string;
  created_at: string;
  updated_at: string;
}

interface DashboardStats {
  totalUsers: number;
  totalDocuments: number;
  totalBills: number;
  totalTransportBookings: number;
  newUsersToday: number;
  activeUsers: number;
}

export default function AdminDashboardScreen() {
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalDocuments: 0,
    totalBills: 0,
    totalTransportBookings: 0,
    newUsersToday: 0,
    activeUsers: 0,
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');

  useEffect(() => {
    // Check admin session
    if (!global.adminSession) {
      Alert.alert('Access Denied', 'Please login as admin first', [
        { text: 'Login', onPress: () => router.replace('/admin/login') }
      ]);
      return;
    }

    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Load users
      const allUsers = await blink.db.users.list({
        orderBy: { created_at: 'desc' },
        limit: 50
      });
      setUsers(allUsers);

      // Load statistics
      const [
        totalUsers,
        totalDocuments,
        totalBills,
        totalTransportBookings
      ] = await Promise.all([
        blink.db.users.list({}),
        blink.db.documents.list({}),
        blink.db.bills.list({}),
        blink.db.transportation.list({})
      ]);

      // Calculate new users today
      const today = new Date().toISOString().split('T')[0];
      const newUsersToday = allUsers.filter(user => 
        user.created_at.startsWith(today)
      ).length;

      setStats({
        totalUsers: totalUsers.length,
        totalDocuments: totalDocuments.length,
        totalBills: totalBills.length,
        totalTransportBookings: totalTransportBookings.length,
        newUsersToday,
        activeUsers: allUsers.filter(user => 
          new Date(user.updated_at) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        ).length,
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      Alert.alert('Error', 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout from admin panel?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: () => {
            global.adminSession = null;
            router.replace('/admin/login');
          }
        }
      ]
    );
  };

  const handleViewUser = (user: User) => {
    Alert.alert(
      'User Details',
      `Name: ${user.display_name || 'N/A'}\nEmail: ${user.email}\nPhone: ${user.phone_number || 'N/A'}\nLanguage: ${user.preferred_language}\nLocation: ${user.location_city || 'N/A'}, ${user.location_state || 'N/A'}\nAadhaar Linked: ${user.aadhaar_linked === 'true' ? 'Yes' : 'No'}\nPAN Linked: ${user.pan_linked === 'true' ? 'Yes' : 'No'}\nJoined: ${new Date(user.created_at).toLocaleDateString()}`,
      [{ text: 'OK' }]
    );
  };

  const handleDeleteUser = (user: User) => {
    Alert.alert(
      'Delete User',
      `Are you sure you want to delete user "${user.display_name || user.email}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await blink.db.users.delete(user.id);
              await loadDashboardData();
              Alert.alert('Success', 'User deleted successfully');
            } catch (error) {
              console.error('Error deleting user:', error);
              Alert.alert('Error', 'Failed to delete user');
            }
          }
        }
      ]
    );
  };

  const StatCard = ({ title, value, icon: Icon, color, subtitle }: any) => (
    <View
      style={{
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 15,
        flex: 1,
        marginHorizontal: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
        <Icon size={20} color={color} />
        <Text style={{ fontSize: 12, color: '#666', marginLeft: 8, flex: 1 }}>
          {title}
        </Text>
      </View>
      <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#333' }}>
        {value}
      </Text>
      {subtitle && (
        <Text style={{ fontSize: 10, color: '#999', marginTop: 2 }}>
          {subtitle}
        </Text>
      )}
    </View>
  );

  if (loading) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#003366" />
        <Text style={{ marginTop: 10, color: '#666' }}>Loading dashboard...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#003366', '#004080']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Shield size={24} color="white" />
            <View style={{ marginLeft: 12 }}>
              <Text style={{ color: 'white', fontSize: 20, fontWeight: 'bold' }}>
                Admin Dashboard
              </Text>
              <Text style={{ color: 'white', opacity: 0.9, fontSize: 12 }}>
                Welcome back, {global.adminSession?.displayName || 'Admin'}
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={handleLogout}>
            <LogOut size={20} color="white" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Tab Navigation */}
        <View style={{ flexDirection: 'row', paddingHorizontal: 20, paddingTop: 20, marginBottom: 20 }}>
          {[
            { id: 'overview', title: 'Overview', icon: TrendingUp },
            { id: 'users', title: 'Users', icon: Users },
            { id: 'data', title: 'Data', icon: Database },
          ].map((tab) => (
            <TouchableOpacity
              key={tab.id}
              onPress={() => setSelectedTab(tab.id)}
              style={{
                flex: 1,
                backgroundColor: selectedTab === tab.id ? '#003366' : 'white',
                borderRadius: 8,
                paddingVertical: 10,
                paddingHorizontal: 15,
                marginHorizontal: 5,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 2,
                elevation: 2,
              }}
            >
              <tab.icon 
                size={16} 
                color={selectedTab === tab.id ? 'white' : '#666'} 
              />
              <Text
                style={{
                  color: selectedTab === tab.id ? 'white' : '#666',
                  fontSize: 12,
                  fontWeight: '600',
                  marginLeft: 6,
                }}
              >
                {tab.title}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Overview Tab */}
        {selectedTab === 'overview' && (
          <View style={{ paddingHorizontal: 20 }}>
            {/* Stats Grid */}
            <View style={{ flexDirection: 'row', marginBottom: 20 }}>
              <StatCard
                title="Total Users"
                value={stats.totalUsers}
                icon={Users}
                color="#4285F4"
                subtitle="All registered users"
              />
              <StatCard
                title="New Today"
                value={stats.newUsersToday}
                icon={Calendar}
                color="#00A86B"
                subtitle="Users joined today"
              />
            </View>

            <View style={{ flexDirection: 'row', marginBottom: 20 }}>
              <StatCard
                title="Documents"
                value={stats.totalDocuments}
                icon={FileText}
                color="#FF9800"
                subtitle="Stored documents"
              />
              <StatCard
                title="Bills"
                value={stats.totalBills}
                icon={CreditCard}
                color="#9C27B0"
                subtitle="Bill records"
              />
            </View>

            <View style={{ flexDirection: 'row', marginBottom: 20 }}>
              <StatCard
                title="Transport"
                value={stats.totalTransportBookings}
                icon={MapPin}
                color="#F44336"
                subtitle="Bookings made"
              />
              <StatCard
                title="Active Users"
                value={stats.activeUsers}
                icon={TrendingUp}
                color="#607D8B"
                subtitle="Last 7 days"
              />
            </View>
          </View>
        )}

        {/* Users Tab */}
        {selectedTab === 'users' && (
          <View style={{ paddingHorizontal: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              User Management ({users.length} users)
            </Text>
            
            {users.map((user, index) => (
              <View
                key={user.id}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  marginBottom: 12,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      backgroundColor: '#E3F2FD',
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginRight: 12,
                    }}
                  >
                    <Text style={{ color: '#1976D2', fontWeight: 'bold', fontSize: 16 }}>
                      {(user.display_name || user.email).charAt(0).toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: '600', color: '#333' }}>
                      {user.display_name || 'No Name'}
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>
                      {user.email}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    <TouchableOpacity
                      onPress={() => handleViewUser(user)}
                      style={{
                        backgroundColor: '#E8F5E8',
                        padding: 8,
                        borderRadius: 6,
                      }}
                    >
                      <Eye size={16} color="#4CAF50" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleDeleteUser(user)}
                      style={{
                        backgroundColor: '#FFEBEE',
                        padding: 8,
                        borderRadius: 6,
                      }}
                    >
                      <Trash2 size={16} color="#F44336" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <View style={{ flexDirection: 'row', gap: 10 }}>
                    {user.aadhaar_linked === 'true' && (
                      <View style={{ backgroundColor: '#E8F5E8', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 }}>
                        <Text style={{ fontSize: 10, color: '#4CAF50', fontWeight: '600' }}>
                          Aadhaar
                        </Text>
                      </View>
                    )}
                    {user.pan_linked === 'true' && (
                      <View style={{ backgroundColor: '#E3F2FD', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 }}>
                        <Text style={{ fontSize: 10, color: '#1976D2', fontWeight: '600' }}>
                          PAN
                        </Text>
                      </View>
                    )}
                    <View style={{ backgroundColor: '#FFF3E0', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 }}>
                      <Text style={{ fontSize: 10, color: '#F57C00', fontWeight: '600' }}>
                        {user.preferred_language.toUpperCase()}
                      </Text>
                    </View>
                  </View>
                  <Text style={{ fontSize: 10, color: '#999' }}>
                    {new Date(user.created_at).toLocaleDateString()}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Data Tab */}
        {selectedTab === 'data' && (
          <View style={{ paddingHorizontal: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              Database Overview
            </Text>
            
            <View style={{ gap: 12 }}>
              {[
                { table: 'Users', count: stats.totalUsers, icon: Users, color: '#4285F4' },
                { table: 'Documents', count: stats.totalDocuments, icon: FileText, color: '#FF9800' },
                { table: 'Bills', count: stats.totalBills, icon: CreditCard, color: '#9C27B0' },
                { table: 'Transportation', count: stats.totalTransportBookings, icon: MapPin, color: '#F44336' },
              ].map((item, index) => (
                <View
                  key={index}
                  style={{
                    backgroundColor: 'white',
                    borderRadius: 12,
                    padding: 15,
                    flexDirection: 'row',
                    alignItems: 'center',
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 1 },
                    shadowOpacity: 0.1,
                    shadowRadius: 2,
                    elevation: 2,
                  }}
                >
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      backgroundColor: item.color + '20',
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginRight: 15,
                    }}
                  >
                    <item.icon size={20} color={item.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: '600', color: '#333' }}>
                      {item.table} Table
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666' }}>
                      Database records
                    </Text>
                  </View>
                  <Text style={{ fontSize: 20, fontWeight: 'bold', color: item.color }}>
                    {item.count}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={{ height: 30 }} />
      </ScrollView>
    </SafeAreaView>
  );
}