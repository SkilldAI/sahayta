import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Shield, Eye, EyeOff, Lock, Mail } from 'lucide-react-native';
import { router } from 'expo-router';
import { blink } from '@/lib/blink';

export default function AdminLoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    setLoading(true);
    try {
      // Check admin credentials in database
      const admins = await blink.db.admins.list({
        where: { 
          email: email.toLowerCase().trim(),
          password_hash: password, // In production, this should be properly hashed
          is_active: 'true'
        },
        limit: 1
      });

      if (admins.length === 0) {
        Alert.alert('Access Denied', 'Invalid admin credentials');
        return;
      }

      const admin = admins[0];

      // Update last login
      await blink.db.admins.update(admin.id, {
        last_login: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

      // Store admin session (simple approach)
      // In production, use proper JWT tokens
      global.adminSession = {
        id: admin.id,
        email: admin.email,
        displayName: admin.display_name,
        role: admin.role,
        loginTime: new Date().toISOString()
      };

      Alert.alert(
        'Login Successful', 
        `Welcome back, ${admin.display_name || 'Admin'}!`,
        [{ text: 'Continue', onPress: () => router.replace('/admin/dashboard') }]
      );

    } catch (error) {
      console.error('Admin login error:', error);
      Alert.alert('Error', 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    Alert.alert(
      'Password Reset',
      'Please contact the system administrator to reset your password.',
      [{ text: 'OK' }]
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <LinearGradient
          colors={['#003366', '#004080']}
          style={{
            paddingHorizontal: 20,
            paddingVertical: 40,
            borderBottomLeftRadius: 30,
            borderBottomRightRadius: 30,
            alignItems: 'center',
          }}
        >
          <View
            style={{
              width: 80,
              height: 80,
              borderRadius: 40,
              backgroundColor: 'rgba(255,255,255,0.2)',
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 20,
            }}
          >
            <Shield size={40} color="white" />
          </View>
          <Text style={{ color: 'white', fontSize: 28, fontWeight: 'bold' }}>
            Admin Portal
          </Text>
          <Text style={{ color: 'white', opacity: 0.9, fontSize: 16, marginTop: 8, textAlign: 'center' }}>
            India Helper App Administration
          </Text>
        </LinearGradient>

        {/* Login Form */}
        <View style={{ flex: 1, paddingHorizontal: 20, paddingTop: 40 }}>
          <View
            style={{
              backgroundColor: 'white',
              borderRadius: 20,
              padding: 30,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.1,
              shadowRadius: 8,
              elevation: 5,
            }}
          >
            <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#003366', marginBottom: 8, textAlign: 'center' }}>
              Admin Login
            </Text>
            <Text style={{ fontSize: 14, color: '#666', marginBottom: 30, textAlign: 'center' }}>
              Access the admin dashboard to manage users and app data
            </Text>

            {/* Email Input */}
            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 }}>
                Email Address
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#F8F9FA',
                  borderRadius: 12,
                  paddingHorizontal: 15,
                  paddingVertical: 15,
                  borderWidth: 1,
                  borderColor: '#E9ECEF',
                }}
              >
                <Mail size={20} color="#666" />
                <TextInput
                  style={{
                    flex: 1,
                    marginLeft: 12,
                    fontSize: 16,
                    color: '#333',
                  }}
                  placeholder="admin@indiahelper.com"
                  placeholderTextColor="#999"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
            </View>

            {/* Password Input */}
            <View style={{ marginBottom: 30 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 }}>
                Password
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#F8F9FA',
                  borderRadius: 12,
                  paddingHorizontal: 15,
                  paddingVertical: 15,
                  borderWidth: 1,
                  borderColor: '#E9ECEF',
                }}
              >
                <Lock size={20} color="#666" />
                <TextInput
                  style={{
                    flex: 1,
                    marginLeft: 12,
                    fontSize: 16,
                    color: '#333',
                  }}
                  placeholder="Enter your password"
                  placeholderTextColor="#999"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                  autoCorrect={false}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={{ marginLeft: 10 }}
                >
                  {showPassword ? (
                    <EyeOff size={20} color="#666" />
                  ) : (
                    <Eye size={20} color="#666" />
                  )}
                </TouchableOpacity>
              </View>
            </View>

            {/* Login Button */}
            <TouchableOpacity
              onPress={handleLogin}
              disabled={loading}
              style={{
                backgroundColor: loading ? '#ccc' : '#003366',
                borderRadius: 12,
                paddingVertical: 16,
                alignItems: 'center',
                marginBottom: 20,
              }}
            >
              {loading ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={{ color: 'white', fontSize: 16, fontWeight: 'bold' }}>
                  Login to Admin Panel
                </Text>
              )}
            </TouchableOpacity>

            {/* Forgot Password */}
            <TouchableOpacity onPress={handleForgotPassword}>
              <Text style={{ color: '#003366', fontSize: 14, textAlign: 'center' }}>
                Forgot Password?
              </Text>
            </TouchableOpacity>
          </View>

          {/* Demo Credentials */}
          <View
            style={{
              backgroundColor: '#FFF3CD',
              borderRadius: 12,
              padding: 15,
              marginTop: 20,
              borderWidth: 1,
              borderColor: '#FFEAA7',
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: 'bold', color: '#856404', marginBottom: 8 }}>
              Demo Credentials:
            </Text>
            <Text style={{ fontSize: 12, color: '#856404' }}>
              Email: admin@indiahelper.com
            </Text>
            <Text style={{ fontSize: 12, color: '#856404' }}>
              Password: admin123
            </Text>
            <Text style={{ fontSize: 11, color: '#856404', marginTop: 8, fontStyle: 'italic' }}>
              Change these credentials in production!
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}