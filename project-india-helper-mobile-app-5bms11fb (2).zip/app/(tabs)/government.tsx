import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  FileText,
  Download,
  Eye,
  Edit,
  CheckCircle,
  Clock,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { blink } from '@/lib/blink';
import GovernmentServicesManager from '@/components/GovernmentServicesManager';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function GovernmentScreen() {
  const { user, isAuthenticated, login } = useAuth();
  const [refreshKey, setRefreshKey] = useState(0);

  const handleApplicationSubmitted = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#003366', '#004080']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold', textAlign: 'center' }}>
          Government Services
        </Text>
        <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, textAlign: 'center', marginTop: 5 }}>
          Access official government portals and services
        </Text>
      </LinearGradient>

      {isAuthenticated ? (
        <GovernmentServicesManager 
          key={refreshKey}
          onApplicationSubmitted={handleApplicationSubmitted}
        />
      ) : (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
          <View
            style={{
              backgroundColor: 'white',
              borderRadius: 15,
              padding: 30,
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
              width: '100%',
            }}
          >
            <FileText size={48} color="#003366" />
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#003366', marginTop: 15, marginBottom: 10 }}>
              Sign In to Access Services
            </Text>
            <Text style={{ fontSize: 14, color: '#666', textAlign: 'center', marginBottom: 25 }}>
              Apply for government services, track applications, and access official portals
            </Text>
            <TouchableOpacity
              onPress={() => login()}
              style={{
                backgroundColor: '#003366',
                paddingHorizontal: 40,
                paddingVertical: 15,
                borderRadius: 25,
              }}
            >
              <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                Sign In Now
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}