import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Modal,
  StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Train,
  Bus,
  Plane,
  Car,
  MapPin,
  Calendar,
  Clock,
  Users,
  Search,
  Ticket,
  X,
  ArrowRight,
  Star,
  TrendingUp,
  Hotel,
  Building2,
  Fuel,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { blink } from '@/lib/blink';
import RailwayServices from '@/components/RailwayServices';
import BusServices from '@/components/BusServices';
import FlightServices from '@/components/FlightServices';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function TransportScreen() {
  const { user, isAuthenticated, login } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showRailwayModal, setShowRailwayModal] = useState(false);
  const [showBusModal, setShowBusModal] = useState(false);
  const [showFlightModal, setShowFlightModal] = useState(false);

  const transportTypes = [
    {
      id: 'train',
      title: 'Train',
      subtitle: 'Book tickets & check PNR',
      icon: Train,
      color: '#4285F4',
      gradient: ['#4285F4', '#5A9BF8'],
      features: ['Book Tickets', 'PNR Status', 'Live Status', 'Seat Availability'],
      popular: true,
      available: true,
    },
    {
      id: 'bus',
      title: 'Bus',
      subtitle: 'State & private buses',
      icon: Bus,
      color: '#00A86B',
      gradient: ['#00A86B', '#26C281'],
      features: ['Book Tickets', 'Live Tracking', 'Route Info', 'Cancellation'],
      popular: false,
      available: true,
    },
    {
      id: 'flight',
      title: 'Flight',
      subtitle: 'Domestic & international',
      icon: Plane,
      color: '#FF6B35',
      gradient: ['#FF6B35', '#FF8A65'],
      features: ['Book Flights', 'Check-in', 'Flight Status', 'Baggage Info'],
      popular: false,
      available: true,
    },
    {
      id: 'taxi',
      title: 'Taxi/Cab',
      subtitle: 'Ola, Uber & local cabs',
      icon: Car,
      color: '#9C27B0',
      gradient: ['#9C27B0', '#BA68C8'],
      features: ['Book Ride', 'Share Ride', 'Fare Estimate', 'Driver Details'],
      popular: false,
      available: false,
    },
    {
      id: 'hotel',
      title: 'Hotels',
      subtitle: 'Book accommodations',
      icon: Hotel,
      color: '#E91E63',
      gradient: ['#E91E63', '#F06292'],
      features: ['Search Hotels', 'Compare Prices', 'Book Rooms', 'Reviews'],
      popular: false,
      available: true,
    },
    {
      id: 'airport',
      title: 'Airport Info',
      subtitle: 'Flight status & facilities',
      icon: Building2,
      color: '#607D8B',
      gradient: ['#607D8B', '#90A4AE'],
      features: ['Flight Status', 'Airport Map', 'Facilities', 'Transport'],
      popular: false,
      available: true,
    },
    {
      id: 'fuel',
      title: 'Fuel Stations',
      subtitle: 'Find nearby petrol pumps',
      icon: Fuel,
      color: '#FF6B35',
      gradient: ['#FF6B35', '#FF8A65'],
      features: ['Find Stations', 'Fuel Prices', 'Directions', 'Services'],
      popular: false,
      available: true,
    },
  ];

  const quickServices = [
    { title: 'PNR Status', icon: Search, color: '#4285F4', gradient: ['#4285F4', '#5A9BF8'] },
    { title: 'Live Train Status', icon: Train, color: '#00A86B', gradient: ['#00A86B', '#26C281'] },
    { title: 'Seat Availability', icon: Users, color: '#FF6B35', gradient: ['#FF6B35', '#FF8A65'] },
    { title: 'Platform Locator', icon: MapPin, color: '#9C27B0', gradient: ['#9C27B0', '#BA68C8'] },
  ];

  const popularRoutes = [
    { from: 'Delhi', to: 'Mumbai', type: 'train', duration: '16h 30m', price: '₹1,200', discount: '15% OFF' },
    { from: 'Bangalore', to: 'Chennai', type: 'bus', duration: '6h 45m', price: '₹800', discount: null },
    { from: 'Mumbai', to: 'Goa', type: 'flight', duration: '1h 15m', price: '₹4,500', discount: '20% OFF' },
    { from: 'Kolkata', to: 'Darjeeling', type: 'train', duration: '8h 20m', price: '₹600', discount: null },
  ];

  useEffect(() => {
    if (isAuthenticated) {
      loadUserBookings();
    }
  }, [isAuthenticated]);

  const loadUserBookings = async () => {
    try {
      setLoading(true);
      const userBookings = await blink.db.transportation.list({
        where: { userId: user.id },
        orderBy: { departureDate: 'desc' },
        limit: 10,
      });
      setBookings(userBookings);
    } catch (error) {
      console.error('Error loading bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTransportAction = (transport: any) => {
    if (transport.id === 'train') {
      setShowRailwayModal(true);
      return;
    }

    if (transport.id === 'bus') {
      setShowBusModal(true);
      return;
    }

    if (transport.id === 'flight') {
      setShowFlightModal(true);
      return;
    }

    if (!isAuthenticated) {
      Alert.alert(
        'Sign In Required',
        'Please sign in to book transportation',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Sign In', onPress: () => login() },
        ]
      );
      return;
    }

    Alert.alert(
      transport.title,
      `${transport.title} booking feature will be available soon!`,
      [{ text: 'OK' }]
    );
  };

  const handleQuickService = (service: any) => {
    if (service.title.includes('Train') || service.title.includes('PNR') || service.title.includes('Seat')) {
      setShowRailwayModal(true);
      return;
    }

    Alert.alert(
      service.title,
      `${service.title} feature will be available soon!`,
      [{ text: 'OK' }]
    );
  };

  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'train': return Train;
      case 'bus': return Bus;
      case 'flight': return Plane;
      case 'taxi': return Car;
      default: return Train;
    }
  };

  const getTransportColor = (type: string) => {
    switch (type) {
      case 'train': return '#4285F4';
      case 'bus': return '#00A86B';
      case 'flight': return '#FF6B35';
      case 'taxi': return '#9C27B0';
      default: return '#4285F4';
    }
  };

  const getTransportGradient = (type: string) => {
    switch (type) {
      case 'train': return ['#4285F4', '#5A9BF8'];
      case 'bus': return ['#00A86B', '#26C281'];
      case 'flight': return ['#FF6B35', '#FF8A65'];
      case 'taxi': return ['#9C27B0', '#BA68C8'];
      default: return ['#4285F4', '#5A9BF8'];
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={['#4285F4', '#5A9BF8']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>Transportation</Text>
          <Text style={styles.headerSubtitle}>
            Book trains, buses, flights and cabs
          </Text>
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* My Bookings */}
        {isAuthenticated && bookings.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>My Bookings</Text>
              <TouchableOpacity>
                <Text style={styles.sectionAction}>View All</Text>
              </TouchableOpacity>
            </View>
            
            {bookings.slice(0, 2).map((booking: any) => {
              const TransportIcon = getTransportIcon(booking.transportType);
              const gradient = getTransportGradient(booking.transportType);
              
              return (
                <View key={booking.id} style={styles.bookingCard}>
                  <LinearGradient
                    colors={gradient}
                    style={styles.bookingIconContainer}
                  >
                    <TransportIcon size={24} color="white" />
                  </LinearGradient>
                  
                  <View style={styles.bookingContent}>
                    <View style={styles.bookingHeader}>
                      <Text style={styles.bookingRoute}>
                        {booking.fromLocation} → {booking.toLocation}
                      </Text>
                      <Text style={[
                        styles.bookingStatus,
                        { color: booking.bookingStatus === 'confirmed' ? '#00A86B' : '#FF6B35' }
                      ]}>
                        {booking.bookingStatus}
                      </Text>
                    </View>
                    
                    <Text style={styles.bookingReference}>
                      {booking.bookingReference || booking.pnrNumber}
                    </Text>
                    
                    <View style={styles.bookingDetails}>
                      <Text style={styles.bookingDetail}>
                        {new Date(booking.departureDate).toLocaleDateString()} • {booking.departureTime}
                      </Text>
                      <Text style={styles.bookingDetail}>
                        {booking.passengerCount} passenger{booking.passengerCount > 1 ? 's' : ''}
                      </Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Quick Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Services</Text>
          <View style={styles.quickServicesGrid}>
            {quickServices.map((service, index) => (
              <TouchableOpacity
                key={index}
                onPress={() => handleQuickService(service)}
                style={styles.quickServiceCard}
              >
                <LinearGradient
                  colors={service.gradient}
                  style={styles.quickServiceIcon}
                >
                  <service.icon size={24} color="white" />
                </LinearGradient>
                <Text style={styles.quickServiceTitle}>{service.title}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Book Transportation */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Book Transportation</Text>
          <View style={styles.transportGrid}>
            {transportTypes.map((transport) => (
              <TouchableOpacity
                key={transport.id}
                onPress={() => handleTransportAction(transport)}
                style={styles.transportCard}
              >
                {transport.popular && (
                  <View style={styles.popularBadge}>
                    <Star size={12} color="white" />
                    <Text style={styles.popularText}>Popular</Text>
                  </View>
                )}
                
                <LinearGradient
                  colors={transport.gradient}
                  style={styles.transportIcon}
                >
                  <transport.icon size={28} color="white" />
                </LinearGradient>
                
                <View style={styles.transportContent}>
                  <Text style={styles.transportTitle}>{transport.title}</Text>
                  <Text style={styles.transportSubtitle}>{transport.subtitle}</Text>
                  
                  <View style={styles.transportFeatures}>
                    {transport.features.slice(0, 2).map((feature, index) => (
                      <View key={index} style={styles.featureItem}>
                        <View style={[styles.featureDot, { backgroundColor: transport.color }]} />
                        <Text style={styles.featureText}>{feature}</Text>
                      </View>
                    ))}
                  </View>
                  
                  {transport.available ? (
                    <LinearGradient
                      colors={transport.gradient}
                      style={styles.bookButton}
                    >
                      <Text style={styles.bookButtonText}>Book Now</Text>
                      <ArrowRight size={16} color="white" />
                    </LinearGradient>
                  ) : (
                    <View style={[styles.bookButton, { backgroundColor: '#E0E0E0' }]}>
                      <Text style={[styles.bookButtonText, { color: '#666' }]}>Coming Soon</Text>
                      <Clock size={16} color="#666" />
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Popular Routes */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Popular Routes</Text>
            <View style={styles.trendingBadge}>
              <TrendingUp size={14} color="#FF6B35" />
              <Text style={styles.trendingText}>Trending</Text>
            </View>
          </View>
          
          <View style={styles.routesContainer}>
            {popularRoutes.map((route, index) => (
              <TouchableOpacity key={index} style={styles.routeCard}>
                <View style={styles.routeHeader}>
                  <View style={styles.routeInfo}>
                    <Text style={styles.routeTitle}>
                      {route.from} → {route.to}
                    </Text>
                    <Text style={styles.routeDetails}>
                      {route.type.charAt(0).toUpperCase() + route.type.slice(1)} • {route.duration}
                    </Text>
                  </View>
                  
                  <View style={styles.routePricing}>
                    {route.discount && (
                      <View style={styles.discountBadge}>
                        <Text style={styles.discountText}>{route.discount}</Text>
                      </View>
                    )}
                    <Text style={styles.routePrice}>{route.price}</Text>
                  </View>
                </View>
                
                <View style={styles.routeFooter}>
                  <View style={[
                    styles.routeTypeIndicator, 
                    { backgroundColor: getTransportColor(route.type) }
                  ]} />
                  <ArrowRight size={16} color="#666" />
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Sign In CTA */}
        {!isAuthenticated && (
          <View style={styles.section}>
            <LinearGradient
              colors={['#4285F4', '#5A9BF8']}
              style={styles.signInCard}
            >
              <View style={styles.signInContent}>
                <Text style={styles.signInTitle}>Sign In to Book Travel</Text>
                <Text style={styles.signInSubtitle}>
                  Save your bookings and get personalized travel recommendations
                </Text>
                <TouchableOpacity
                  onPress={() => login()}
                  style={styles.signInButton}
                >
                  <Text style={styles.signInButtonText}>Sign In Now</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </View>
        )}
      </ScrollView>

      {/* Railway Services Modal */}
      <Modal
        visible={showRailwayModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowRailwayModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Railway Services</Text>
            <TouchableOpacity
              onPress={() => setShowRailwayModal(false)}
              style={styles.closeButton}
            >
              <X size={20} color="#666" />
            </TouchableOpacity>
          </View>
          
          <RailwayServices />
        </SafeAreaView>
      </Modal>

      {/* Bus Services Modal */}
      <Modal
        visible={showBusModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowBusModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Bus Services</Text>
            <TouchableOpacity
              onPress={() => setShowBusModal(false)}
              style={styles.closeButton}
            >
              <X size={20} color="#666" />
            </TouchableOpacity>
          </View>
          
          <BusServices />
        </SafeAreaView>
      </Modal>

      {/* Flight Services Modal */}
      <Modal
        visible={showFlightModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowFlightModal(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Flight Services</Text>
            <TouchableOpacity
              onPress={() => setShowFlightModal(false)}
              style={styles.closeButton}
            >
              <X size={20} color="#666" />
            </TouchableOpacity>
          </View>
          
          <FlightServices />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 30,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    alignItems: 'center',
  },
  headerTitle: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#003366',
  },
  sectionAction: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4285F4',
  },
  trendingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 107, 53, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  trendingText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FF6B35',
  },
  bookingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  bookingIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  bookingContent: {
    flex: 1,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  bookingRoute: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  bookingStatus: {
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  bookingReference: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  bookingDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  bookingDetail: {
    fontSize: 12,
    color: '#666',
  },
  quickServicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  quickServiceCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    width: (width - 60) / 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  quickServiceIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  quickServiceTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  transportGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  transportCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    width: cardWidth,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
    position: 'relative',
  },
  popularBadge: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: '#FF6B35',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
    zIndex: 1,
  },
  popularText: {
    fontSize: 10,
    fontWeight: '600',
    color: 'white',
  },
  transportIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  transportContent: {
    flex: 1,
  },
  transportTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  transportSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 16,
  },
  transportFeatures: {
    marginBottom: 20,
    gap: 8,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  featureDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  featureText: {
    fontSize: 12,
    color: '#666',
  },
  bookButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 24,
    gap: 8,
  },
  bookButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  routesContainer: {
    gap: 12,
  },
  routeCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  routeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  routeInfo: {
    flex: 1,
  },
  routeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  routeDetails: {
    fontSize: 14,
    color: '#666',
  },
  routePricing: {
    alignItems: 'flex-end',
  },
  discountBadge: {
    backgroundColor: '#00A86B',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 4,
  },
  discountText: {
    fontSize: 10,
    fontWeight: '600',
    color: 'white',
  },
  routePrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  routeFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  routeTypeIndicator: {
    width: 32,
    height: 4,
    borderRadius: 2,
  },
  signInCard: {
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
  },
  signInContent: {
    alignItems: 'center',
  },
  signInTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  signInSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    textAlign: 'center',
    marginBottom: 24,
  },
  signInButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 24,
  },
  signInButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#003366',
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
});