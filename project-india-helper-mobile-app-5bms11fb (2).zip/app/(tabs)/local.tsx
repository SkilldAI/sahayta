import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Linking,
  Dimensions,
  Modal,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  MapPin,
  Phone,
  Heart,
  Shield,
  Flame,
  Building,
  Car,
  ShoppingBag,
  Utensils,
  Navigation,
  Clock,
  Search,
  Stethoscope,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { blink } from '@/lib/blink';
import { hospitalService, type Hospital } from '@/services/hospitalService';
import ATMFinder from '@/components/ATMFinder';
import PetrolFinder from '@/components/PetrolFinder';
import PharmacyFinder from '@/components/PharmacyFinder';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function LocalScreen() {
  const { user, isAuthenticated } = useAuth();
  const [nearbyServices, setNearbyServices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showHospitalModal, setShowHospitalModal] = useState(false);
  const [showATMModal, setShowATMModal] = useState(false);
  const [showPetrolModal, setShowPetrolModal] = useState(false);
  const [showPharmacyModal, setShowPharmacyModal] = useState(false);
  const [hospitalCity, setHospitalCity] = useState('');
  const [hospitalLoading, setHospitalLoading] = useState(false);
  const [hospitalError, setHospitalError] = useState<string | null>(null);
  const [hospitalResults, setHospitalResults] = useState<Hospital[]>([]);

  const emergencyServices = [
    {
      id: 'police',
      title: 'Police',
      number: '100',
      icon: Shield,
      color: '#4285F4',
      description: 'Emergency police assistance',
    },
    {
      id: 'fire',
      title: 'Fire Brigade',
      number: '101',
      icon: Flame,
      color: '#F44336',
      description: 'Fire emergency services',
    },
    {
      id: 'ambulance',
      title: 'Ambulance',
      number: '108',
      icon: Heart,
      color: '#00A86B',
      description: 'Medical emergency services',
    },
    {
      id: 'disaster',
      title: 'Disaster Helpline',
      number: '1078',
      icon: Phone,
      color: '#FF9800',
      description: 'Natural disaster assistance',
    },
  ];

  const serviceCategories = [
    {
      id: 'hospital',
      title: 'Hospitals',
      icon: Heart,
      color: '#F44336',
      description: 'Nearby hospitals and clinics',
      available: true,
    },
    {
      id: 'atm',
      title: 'ATMs',
      icon: Building,
      color: '#4285F4',
      description: 'ATMs and banks nearby',
      available: true,
    },
    {
      id: 'petrol',
      title: 'Petrol Pumps',
      icon: Car,
      color: '#FF6B35',
      description: 'Fuel stations nearby',
      available: true,
    },
    {
      id: 'pharmacy',
      title: 'Pharmacies',
      icon: Heart,
      color: '#00A86B',
      description: 'Medical stores and pharmacies',
      available: true,
    },
    {
      id: 'restaurant',
      title: 'Restaurants',
      icon: Utensils,
      color: '#9C27B0',
      description: 'Nearby restaurants and cafes',
      available: false,
    },
    {
      id: 'shopping',
      title: 'Shopping',
      icon: ShoppingBag,
      color: '#FF9800',
      description: 'Malls and shopping centers',
      available: false,
    },
  ];

  useEffect(() => {
    loadNearbyServices();
  }, []);

  const loadNearbyServices = async () => {
    try {
      setLoading(true);
      // Load some sample local services
      const services = await blink.db.localServices.list({
        limit: 10,
        orderBy: { rating: 'desc' },
      });
      setNearbyServices(services);
    } catch (error) {
      console.error('Error loading services:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEmergencyCall = (service: any) => {
    Alert.alert(
      `Call ${service.title}`,
      `Do you want to call ${service.number}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Call Now',
          onPress: () => {
            Linking.openURL(`tel:${service.number}`);
          },
        },
      ]
    );
  };

  const openMapsForHospital = (h: Hospital) => {
    const coords: any = (h as any).coordinates;
    if (coords?.latitude && coords?.longitude) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${coords.latitude},${coords.longitude}`;
      Linking.openURL(url);
    } else {
      const q = encodeURIComponent(`${h.name}, ${(h as any).address || ''}`);
      Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${q}`);
    }
  };

  const searchHospitals = async () => {
    setHospitalError(null);
    if (!hospitalCity.trim()) {
      setHospitalError('Please enter a city name.');
      return;
    }
    setHospitalLoading(true);
    try {
      const data = await hospitalService.searchHospitals(hospitalCity.trim());
      setHospitalResults(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setHospitalError(e?.message || 'Failed to fetch hospitals.');
    } finally {
      setHospitalLoading(false);
    }
  };

  const handleServiceCategory = (category: any) => {
    if (category.id === 'hospital') {
      setShowHospitalModal(true);
      return;
    }
    if (category.id === 'atm') {
      setShowATMModal(true);
      return;
    }
    if (category.id === 'petrol') {
      setShowPetrolModal(true);
      return;
    }
    if (category.id === 'pharmacy') {
      setShowPharmacyModal(true);
      return;
    }
    if (!category.available) {
      Alert.alert(
        category.title,
        `${category.title} finder feature will be available soon!`,
        [{ text: 'OK' }]
      );
    } else {
      // Handle available services
      Alert.alert(
        category.title,
        `Opening ${category.title} finder...`,
        [{ text: 'OK' }]
      );
    }
  };

  const handleGetDirections = (service: any) => {
    if (service.latitude && service.longitude) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${service.latitude},${service.longitude}`;
      Linking.openURL(url);
    } else {
      Alert.alert('Directions', 'Location coordinates not available');
    }
  };

  const handleCallService = (phoneNumber: string) => {
    if (phoneNumber) {
      Linking.openURL(`tel:${phoneNumber}`);
    } else {
      Alert.alert('Call', 'Phone number not available');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#F44336', '#E57373']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold', textAlign: 'center' }}>
          Local Services
        </Text>
        <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, textAlign: 'center', marginTop: 5 }}>
          Emergency contacts and nearby services
        </Text>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
        {/* Emergency Services */}
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Emergency Services
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 15 }}>
            {emergencyServices.map((service) => (
              <TouchableOpacity
                key={service.id}
                onPress={() => handleEmergencyCall(service)}
                style={{
                  width: cardWidth,
                  backgroundColor: 'white',
                  borderRadius: 15,
                  padding: 20,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                  borderLeftWidth: 4,
                  borderLeftColor: service.color,
                }}
              >
                <View
                  style={{
                    backgroundColor: service.color,
                    width: 50,
                    height: 50,
                    borderRadius: 25,
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginBottom: 12,
                  }}
                >
                  <service.icon size={24} color="white" />
                </View>
                <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 4 }}>
                  {service.title}
                </Text>
                <Text style={{ fontSize: 20, fontWeight: 'bold', color: service.color, marginBottom: 8 }}>
                  {service.number}
                </Text>
                <Text style={{ fontSize: 11, color: '#666', lineHeight: 16 }}>
                  {service.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Nearby Services */}
        {nearbyServices.length > 0 && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              Nearby Services
            </Text>
            {nearbyServices.slice(0, 3).map((service: any) => (
              <View
                key={service.id}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  marginBottom: 10,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                }}
              >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 }}>
                      {service.name}
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666', marginBottom: 5 }}>
                      {service.serviceType} • {service.city}
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666', marginBottom: 10 }}>
                      {service.address}
                    </Text>

                    {service.rating && (
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
                        <Text style={{ fontSize: 12, color: '#FF9800', marginRight: 5 }}>
                          ★ {service.rating}
                        </Text>
                        {Number(service.isVerified) > 0 && (
                          <Text style={{ fontSize: 10, color: '#00A86B', backgroundColor: '#E8F5E8', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10 }}>
                            Verified
                          </Text>
                        )}
                      </View>
                    )}

                    <View style={{ flexDirection: 'row', gap: 10 }}>
                      {service.phoneNumber && (
                        <TouchableOpacity
                          onPress={() => handleCallService(service.phoneNumber)}
                          style={{
                            backgroundColor: '#00A86B',
                            paddingHorizontal: 12,
                            paddingVertical: 6,
                            borderRadius: 15,
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}
                        >
                          <Phone size={12} color="white" />
                          <Text style={{ color: 'white', fontSize: 11, marginLeft: 4 }}>Call</Text>
                        </TouchableOpacity>
                      )}

                      <TouchableOpacity
                        onPress={() => handleGetDirections(service)}
                        style={{
                          backgroundColor: '#4285F4',
                          paddingHorizontal: 12,
                          paddingVertical: 6,
                          borderRadius: 15,
                          flexDirection: 'row',
                          alignItems: 'center',
                        }}
                      >
                        <Navigation size={12} color="white" />
                        <Text style={{ color: 'white', fontSize: 11, marginLeft: 4 }}>Directions</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Service Categories */}
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Find Nearby
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 15 }}>
            {serviceCategories.map((category) => (
              <TouchableOpacity
                key={category.id}
                onPress={() => handleServiceCategory(category)}
                style={{
                  width: cardWidth,
                  backgroundColor: 'white',
                  borderRadius: 15,
                  padding: 20,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                }}
              >
                <View
                  style={{
                    backgroundColor: category.color,
                    width: 50,
                    height: 50,
                    borderRadius: 25,
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginBottom: 12,
                  }}
                >
                  <category.icon size={24} color="white" />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                  <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333' }}>
                    {category.title}
                  </Text>
                  {!category.available && (
                    <View style={{ backgroundColor: '#FFF3E0', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 }}>
                      <Text style={{ fontSize: 10, color: '#FF9800', fontWeight: '600' }}>Coming Soon</Text>
                    </View>
                  )}
                </View>
                <Text style={{ fontSize: 12, color: '#666', lineHeight: 16 }}>
                  {category.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Important Numbers */}
        <View style={{ paddingHorizontal: 20, marginBottom: 30 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Important Numbers
          </Text>
          <View style={{ gap: 10 }}>
            {[
              { title: 'Women Helpline', number: '1091', description: 'Women in distress' },
              { title: 'Child Helpline', number: '1098', description: 'Child abuse and missing children' },
              { title: 'Senior Citizen Helpline', number: '14567', description: 'Senior citizen assistance' },
              { title: 'Tourist Helpline', number: '1363', description: 'Tourist assistance and information' },
              { title: 'Railway Enquiry', number: '139', description: 'Train information and booking' },
              { title: 'Gas Leak Helpline', number: '1906', description: 'Gas leak emergency' },
            ].map((helpline, index) => (
              <TouchableOpacity
                key={index}
                onPress={() => Linking.openURL(`tel:${helpline.number}`)}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
              >
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: '600', color: '#333' }}>
                    {helpline.title}
                  </Text>
                  <Text style={{ fontSize: 12, color: '#666', marginTop: 2 }}>
                    {helpline.description}
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#F44336' }}>
                    {helpline.number}
                  </Text>
                  <Phone size={16} color="#666" />
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Hospitals Finder Modal */}
      <Modal visible={showHospitalModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowHospitalModal(false)}>
        <View style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
          <LinearGradient colors={["#003366", "#004080"]} style={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <View style={{ backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 18 }}>
                  <Stethoscope size={22} color="white" />
                </View>
                <View>
                  <Text style={{ color: 'white', fontSize: 18, fontWeight: '700' }}>Find Hospitals</Text>
                  <Text style={{ color: 'rgba(255,255,255,0.9)' }}>Search by city and get directions</Text>
                </View>
              </View>
              <TouchableOpacity onPress={() => setShowHospitalModal(false)} style={{ padding: 8 }}>
                <Text style={{ color: 'white', fontSize: 16 }}>Close</Text>
              </TouchableOpacity>
            </View>

            <View style={{ backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 14, padding: 8, marginTop: 12, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <MapPin size={18} color="white" />
              <TextInput
                style={{ flex: 1, fontSize: 16, color: 'white' }}
                placeholder="Enter city (e.g., Mumbai)"
                placeholderTextColor="rgba(255,255,255,0.7)"
                value={hospitalCity}
                onChangeText={setHospitalCity}
                returnKeyType="search"
                onSubmitEditing={searchHospitals}
              />
              <TouchableOpacity onPress={searchHospitals} disabled={hospitalLoading}>
                {hospitalLoading ? (
                  <ActivityIndicator size="small" color="white" />
                ) : (
                  <Search size={18} color="white" />
                )}
              </TouchableOpacity>
            </View>
          </LinearGradient>

          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
            {hospitalError && (
              <View style={{ backgroundColor: '#FEF2F2', borderColor: '#FECACA', borderWidth: 1, padding: 10, borderRadius: 10, marginBottom: 12 }}>
                <Text style={{ color: '#991B1B' }}>{hospitalError}</Text>
              </View>
            )}

            {!hospitalLoading && hospitalResults.length === 0 && !hospitalError && (
              <View style={{ backgroundColor: 'white', borderRadius: 16, padding: 20, borderWidth: 1, borderColor: '#E5E7EB' }}>
                <Text style={{ color: '#111', fontSize: 16, fontWeight: '600', marginBottom: 6 }}>No hospitals yet</Text>
                <Text style={{ color: '#6B7280' }}>Try a different city.</Text>
              </View>
            )}

            {hospitalResults.map((h) => (
              <View key={h.id} style={{ backgroundColor: 'white', borderRadius: 16, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#E5E7EB' }}>
                <Text style={{ color: '#111827', fontSize: 16, fontWeight: '700' }}>{h.name}</Text>
                <Text style={{ color: '#4B5563', marginTop: 6, fontSize: 12 }}>{(h as any).address}</Text>
                <Text style={{ color: '#6B7280', marginTop: 2, fontSize: 12 }}>{(h as any).city}{(h as any).pincode ? ` • ${(h as any).pincode}` : ''}</Text>

                <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
                  {!!(h as any).contactInfo?.phone && (
                    <TouchableOpacity onPress={() => Linking.openURL(`tel:${(h as any).contactInfo?.phone}`)}>
                      <View style={{ backgroundColor: '#00A86B', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                        <Phone size={16} color="white" />
                        <Text style={{ color: 'white', fontWeight: '600' }}>Call</Text>
                      </View>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity onPress={() => openMapsForHospital(h)}>
                    <View style={{ backgroundColor: '#003366', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Navigation size={16} color="white" />
                      <Text style={{ color: 'white', fontWeight: '600' }}>Directions</Text>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            ))}

            {hospitalLoading && (
              <View style={{ padding: 20 }}>
                <ActivityIndicator size="large" color="#003366" />
                <Text style={{ textAlign: 'center', marginTop: 8, color: '#6B7280' }}>Fetching hospitals…</Text>
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>

      {/* ATM Finder Modal */}
      <ATMFinder visible={showATMModal} onClose={() => setShowATMModal(false)} />

      {/* Petrol Finder Modal */}
      <PetrolFinder visible={showPetrolModal} onClose={() => setShowPetrolModal(false)} />

      {/* Pharmacy Finder Modal */}
      <PharmacyFinder visible={showPharmacyModal} onClose={() => setShowPharmacyModal(false)} />
    </SafeAreaView>
  );
}