import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Calculator,
  Percent,
  TrendingUp,
  PiggyBank,
  CreditCard,
  FileText,
  IndianRupee,
  Target,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function FinanceScreen() {
  const [gstAmount, setGstAmount] = useState('');
  const [gstRate, setGstRate] = useState('18');
  const [calculatedGst, setCalculatedGst] = useState(null);

  const financeTools = [
    {
      id: 'gst',
      title: 'GST Calculator',
      subtitle: 'Calculate GST on amount',
      icon: Calculator,
      color: '#9C27B0',
      description: 'Calculate GST inclusive/exclusive amounts',
    },
    {
      id: 'emi',
      title: 'EMI Calculator',
      subtitle: 'Loan EMI calculation',
      icon: TrendingUp,
      color: '#4285F4',
      description: 'Calculate monthly EMI for loans',
    },
    {
      id: 'sip',
      title: 'SIP Calculator',
      subtitle: 'Mutual fund returns',
      icon: PiggyBank,
      color: '#00A86B',
      description: 'Calculate SIP investment returns',
    },
    {
      id: 'fd',
      title: 'FD Calculator',
      subtitle: 'Fixed deposit returns',
      icon: Target,
      color: '#FF6B35',
      description: 'Calculate FD maturity amount',
    },
    {
      id: 'income-tax',
      title: 'Income Tax',
      subtitle: 'Tax calculation',
      icon: FileText,
      color: '#F44336',
      description: 'Calculate income tax liability',
    },
    {
      id: 'ppf',
      title: 'PPF Calculator',
      subtitle: 'PPF maturity amount',
      icon: PiggyBank,
      color: '#FF9800',
      description: 'Calculate PPF returns',
    },
  ];

  const quickCalculations = [
    { title: 'Simple Interest', formula: 'P × R × T / 100' },
    { title: 'Compound Interest', formula: 'P(1+R/100)^T - P' },
    { title: 'Percentage', formula: 'Value × Percentage / 100' },
    { title: 'Profit/Loss %', formula: '(SP-CP)/CP × 100' },
  ];

  const calculateGST = () => {
    if (!gstAmount || isNaN(parseFloat(gstAmount))) {
      Alert.alert('Error', 'Please enter a valid amount');
      return;
    }

    const amount = parseFloat(gstAmount);
    const rate = parseFloat(gstRate);
    
    const gstValue = (amount * rate) / 100;
    const totalAmount = amount + gstValue;
    
    setCalculatedGst({
      originalAmount: amount,
      gstRate: rate,
      gstAmount: gstValue,
      totalAmount: totalAmount,
    });
  };

  const handleToolPress = (tool: any) => {
    if (tool.id === 'gst') {
      // GST calculator is already implemented
      return;
    }
    
    Alert.alert(
      tool.title,
      `${tool.title} feature will be available soon!`,
      [{ text: 'OK' }]
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#9C27B0', '#BA68C8']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold', textAlign: 'center' }}>
          Finance Tools
        </Text>
        <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, textAlign: 'center', marginTop: 5 }}>
          Calculators and financial planning tools
        </Text>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
        {/* GST Calculator */}
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            GST Calculator
          </Text>
          <View
            style={{
              backgroundColor: 'white',
              borderRadius: 15,
              padding: 20,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <View style={{ marginBottom: 15 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 }}>
                Amount (₹)
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: '#E5E5E5',
                  borderRadius: 8,
                  paddingHorizontal: 15,
                  paddingVertical: 12,
                  fontSize: 16,
                  backgroundColor: '#FAFAFA',
                }}
                placeholder="Enter amount"
                value={gstAmount}
                onChangeText={setGstAmount}
                keyboardType="numeric"
              />
            </View>

            <View style={{ marginBottom: 20 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 }}>
                GST Rate (%)
              </Text>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                {['5', '12', '18', '28'].map((rate) => (
                  <TouchableOpacity
                    key={rate}
                    onPress={() => setGstRate(rate)}
                    style={{
                      flex: 1,
                      paddingVertical: 10,
                      paddingHorizontal: 15,
                      borderRadius: 8,
                      backgroundColor: gstRate === rate ? '#9C27B0' : '#F5F5F5',
                      alignItems: 'center',
                    }}
                  >
                    <Text
                      style={{
                        color: gstRate === rate ? 'white' : '#333',
                        fontWeight: '600',
                      }}
                    >
                      {rate}%
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <TouchableOpacity
              onPress={calculateGST}
              style={{
                backgroundColor: '#9C27B0',
                paddingVertical: 15,
                borderRadius: 10,
                alignItems: 'center',
                marginBottom: 15,
              }}
            >
              <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                Calculate GST
              </Text>
            </TouchableOpacity>

            {calculatedGst && (
              <View
                style={{
                  backgroundColor: '#F8F9FA',
                  borderRadius: 10,
                  padding: 15,
                  borderLeftWidth: 4,
                  borderLeftColor: '#9C27B0',
                }}
              >
                <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 10 }}>
                  GST Calculation Result
                </Text>
                <View style={{ gap: 5 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={{ color: '#666' }}>Original Amount:</Text>
                    <Text style={{ fontWeight: '600', color: '#333' }}>
                      ₹{calculatedGst.originalAmount.toFixed(2)}
                    </Text>
                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text style={{ color: '#666' }}>GST ({calculatedGst.gstRate}%):</Text>
                    <Text style={{ fontWeight: '600', color: '#9C27B0' }}>
                      ₹{calculatedGst.gstAmount.toFixed(2)}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      borderTopWidth: 1,
                      borderTopColor: '#E5E5E5',
                      paddingTop: 5,
                      marginTop: 5,
                    }}
                  >
                    <Text style={{ fontWeight: 'bold', color: '#333' }}>Total Amount:</Text>
                    <Text style={{ fontWeight: 'bold', color: '#00A86B', fontSize: 16 }}>
                      ₹{calculatedGst.totalAmount.toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            )}
          </View>
        </View>

        {/* Finance Tools */}
        <View style={{ padding: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Financial Calculators
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 15 }}>
            {financeTools.map((tool) => (
              <TouchableOpacity
                key={tool.id}
                onPress={() => handleToolPress(tool)}
                style={{
                  width: cardWidth,
                  backgroundColor: 'white',
                  borderRadius: 15,
                  padding: 20,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                }}
              >
                <View
                  style={{
                    backgroundColor: tool.color,
                    width: 50,
                    height: 50,
                    borderRadius: 25,
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginBottom: 12,
                  }}
                >
                  <tool.icon size={24} color="white" />
                </View>
                <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 4 }}>
                  {tool.title}
                </Text>
                <Text style={{ fontSize: 12, color: '#666', marginBottom: 8 }}>
                  {tool.subtitle}
                </Text>
                <Text style={{ fontSize: 11, color: '#999', lineHeight: 16 }}>
                  {tool.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Quick Formulas */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Quick Formulas
          </Text>
          <View style={{ gap: 10 }}>
            {quickCalculations.map((calc, index) => (
              <View
                key={index}
                style={{
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
              >
                <Text style={{ fontSize: 16, fontWeight: '600', color: '#333', marginBottom: 5 }}>
                  {calc.title}
                </Text>
                <Text style={{ fontSize: 14, color: '#666', fontFamily: 'monospace' }}>
                  {calc.formula}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Financial Tips */}
        <View style={{ paddingHorizontal: 20, marginBottom: 30 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            Financial Tips
          </Text>
          <LinearGradient
            colors={['#00A86B', '#00C878']}
            style={{
              borderRadius: 15,
              padding: 20,
            }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
              <PiggyBank size={24} color="white" />
              <Text style={{ color: 'white', fontSize: 18, fontWeight: 'bold', marginLeft: 10 }}>
                Smart Saving Tips
              </Text>
            </View>
            <View style={{ gap: 8 }}>
              <Text style={{ color: 'white', opacity: 0.9, fontSize: 14 }}>
                • Start SIP with as low as ₹500 per month
              </Text>
              <Text style={{ color: 'white', opacity: 0.9, fontSize: 14 }}>
                • Use 50-30-20 rule: 50% needs, 30% wants, 20% savings
              </Text>
              <Text style={{ color: 'white', opacity: 0.9, fontSize: 14 }}>
                • Build emergency fund of 6-12 months expenses
              </Text>
              <Text style={{ color: 'white', opacity: 0.9, fontSize: 14 }}>
                • Invest in tax-saving instruments under 80C
              </Text>
            </View>
          </LinearGradient>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}