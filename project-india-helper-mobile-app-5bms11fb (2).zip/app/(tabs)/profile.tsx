import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import {
  User,
  Settings,
  FileText,
  Bell,
  Shield,
  Globe,
  Moon,
  LogOut,
  ChevronRight,
  Star,
  Heart,
  Download,
  Share,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { LanguageSelector } from '@/components/LanguageSelector';
import { blink } from '@/lib/blink';

export default function ProfileScreen() {
  const { user, isAuthenticated, login, logout } = useAuth();
  const { t } = useLanguage();
  const [userSettings, setUserSettings] = useState(null);
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(false);

  const profileSections = [
    {
      title: t('my_documents'),
      icon: FileText,
      color: '#4285F4',
      description: 'Aadhaar, PAN, Passport, etc.',
      action: 'documents',
    },
    {
      title: t('favorites'),
      icon: Heart,
      color: '#F44336',
      description: t('favorites_description'),
      action: 'favorites',
    },
    {
      title: t('download_history'),
      icon: Download,
      color: '#00A86B',
      description: t('downloads_description'),
      action: 'downloads',
    },
    {
      title: t('settings'),
      icon: Settings,
      color: '#9C27B0',
      description: t('settings_description'),
      action: 'settings',
    },
  ];

  const settingsOptions = [
    {
      title: t('notifications'),
      icon: Bell,
      type: 'toggle',
      key: 'notificationEnabled',
    },
    {
      title: t('dark_mode'),
      icon: Moon,
      type: 'toggle',
      key: 'darkModeEnabled',
    },
    {
      title: t('location_sharing'),
      icon: Shield,
      type: 'toggle',
      key: 'locationSharingEnabled',
    },
    {
      title: t('language'),
      icon: Globe,
      type: 'language_selector',
      key: 'languagePreference',
    },
  ];

  useEffect(() => {
    if (isAuthenticated) {
      loadUserData();
    }
  }, [isAuthenticated]);

  const loadUserData = async () => {
    try {
      setLoading(true);
      
      // Load user settings
      const settings = await blink.db.userSettings.list({
        where: { userId: user.id },
        limit: 1,
      });
      
      if (settings.length > 0) {
        setUserSettings(settings[0]);
      }

      // Load user documents
      const userDocs = await blink.db.documents.list({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        limit: 5,
      });
      setDocuments(userDocs);
      
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSectionPress = (action: string) => {
    if (!isAuthenticated) {
      Alert.alert(
        t('sign_in_required'),
        t('sign_in_required_message'),
        [
          { text: t('cancel'), style: 'cancel' },
          { text: t('sign_in'), onPress: () => login() },
        ]
      );
      return;
    }

    Alert.alert(
      t('feature_coming_soon'),
      t('feature_available_soon', { feature: action.charAt(0).toUpperCase() + action.slice(1) }),
      [{ text: t('ok') }]
    );
  };

  const handleSettingToggle = async (key: string, value: boolean) => {
    if (!isAuthenticated || !userSettings) return;

    try {
      await blink.db.userSettings.update(userSettings.id, {
        [key]: value ? 'true' : 'false',
        updatedAt: new Date().toISOString(),
      });
      
      setUserSettings(prev => ({
        ...prev,
        [key]: value ? 'true' : 'false',
      }));
    } catch (error) {
      console.error('Error updating setting:', error);
      Alert.alert(t('error'), 'Failed to update setting');
    }
  };

  const handleLogout = () => {
    Alert.alert(
      t('sign_out'),
      t('sign_out_confirmation'),
      [
        { text: t('cancel'), style: 'cancel' },
        { text: t('sign_out'), style: 'destructive', onPress: () => logout() },
      ]
    );
  };

  const handleShare = () => {
    Alert.alert(
      t('share_app'),
      t('share_app_message'),
      [{ text: t('ok') }]
    );
  };

  const handleRate = () => {
    Alert.alert(
      t('rate_app'),
      t('rate_app_message'),
      [{ text: t('ok') }]
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FAFAFA' }}>
      {/* Header */}
      <LinearGradient
        colors={['#003366', '#004080']}
        style={{
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        {isAuthenticated ? (
          <View style={{ alignItems: 'center' }}>
            <View
              style={{
                width: 80,
                height: 80,
                borderRadius: 40,
                backgroundColor: 'rgba(255,255,255,0.2)',
                justifyContent: 'center',
                alignItems: 'center',
                marginBottom: 15,
              }}
            >
              <User size={40} color="white" />
            </View>
            <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold' }}>
              {user?.displayName || 'User'}
            </Text>
            <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, marginTop: 5 }}>
              {user?.email}
            </Text>
          </View>
        ) : (
          <View style={{ alignItems: 'center' }}>
            <Text style={{ color: 'white', fontSize: 24, fontWeight: 'bold', marginBottom: 10 }}>
              {t('welcome_to_india_helper')}
            </Text>
            <Text style={{ color: 'white', opacity: 0.9, fontSize: 14, textAlign: 'center', marginBottom: 20 }}>
              {t('sign_in_description')}
            </Text>
            <TouchableOpacity
              onPress={() => login()}
              style={{
                backgroundColor: 'rgba(255,255,255,0.2)',
                paddingHorizontal: 30,
                paddingVertical: 15,
                borderRadius: 25,
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.3)',
              }}
            >
              <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                {t('sign_in')}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
        {/* Profile Sections */}
        {isAuthenticated && (
          <View style={{ padding: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              {t('my_account')}
            </Text>
            <View style={{ gap: 12 }}>
              {profileSections.map((section, index) => (
                <TouchableOpacity
                  key={index}
                  onPress={() => handleSectionPress(section.action)}
                  style={{
                    backgroundColor: 'white',
                    borderRadius: 12,
                    padding: 15,
                    flexDirection: 'row',
                    alignItems: 'center',
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 1 },
                    shadowOpacity: 0.1,
                    shadowRadius: 2,
                    elevation: 2,
                  }}
                >
                  <View
                    style={{
                      backgroundColor: section.color,
                      width: 40,
                      height: 40,
                      borderRadius: 20,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginRight: 15,
                    }}
                  >
                    <section.icon size={20} color="white" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, fontWeight: '600', color: '#333' }}>
                      {section.title}
                    </Text>
                    <Text style={{ fontSize: 12, color: '#666', marginTop: 2 }}>
                      {section.description}
                    </Text>
                  </View>
                  <ChevronRight size={16} color="#666" />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Quick Stats */}
        {isAuthenticated && documents.length > 0 && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              {t('quick_stats')}
            </Text>
            <View style={{ flexDirection: 'row', gap: 15 }}>
              <View
                style={{
                  flex: 1,
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  alignItems: 'center',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
              >
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#4285F4' }}>
                  {documents.length}
                </Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>
                  {t('documents_saved')}
                </Text>
              </View>
              <View
                style={{
                  flex: 1,
                  backgroundColor: 'white',
                  borderRadius: 12,
                  padding: 15,
                  alignItems: 'center',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.1,
                  shadowRadius: 2,
                  elevation: 2,
                }}
              >
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#00A86B' }}>
                  0
                </Text>
                <Text style={{ fontSize: 12, color: '#666', textAlign: 'center' }}>
                  {t('bills_paid')}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Settings */}
        {isAuthenticated && userSettings && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
              {t('preferences')}
            </Text>
            <View
              style={{
                backgroundColor: 'white',
                borderRadius: 12,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 2,
                elevation: 2,
              }}
            >
              {settingsOptions.map((option, index) => (
                <View
                  key={index}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingHorizontal: 15,
                    paddingVertical: 15,
                    borderBottomWidth: index < settingsOptions.length - 1 ? 1 : 0,
                    borderBottomColor: '#F5F5F5',
                  }}
                >
                  <option.icon size={20} color="#666" />
                  <Text style={{ flex: 1, fontSize: 16, color: '#333', marginLeft: 15 }}>
                    {option.title}
                  </Text>
                  {option.type === 'toggle' ? (
                    <Switch
                      value={Number(userSettings[option.key]) > 0}
                      onValueChange={(value) => handleSettingToggle(option.key, value)}
                      trackColor={{ false: '#E5E5E5', true: '#003366' }}
                      thumbColor={Number(userSettings[option.key]) > 0 ? '#FFFFFF' : '#FFFFFF'}
                    />
                  ) : option.type === 'language_selector' ? (
                    <LanguageSelector 
                      showIcon={false} 
                      showText={true}
                      style={{
                        backgroundColor: '#F5F5F5',
                        paddingHorizontal: 12,
                        paddingVertical: 6,
                        borderRadius: 15,
                      }}
                    />
                  ) : (
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <ChevronRight size={16} color="#666" />
                    </View>
                  )}
                </View>
              ))}
            </View>
          </View>
        )}

        {/* App Actions */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#003366', marginBottom: 15 }}>
            {t('app')}
          </Text>
          <View style={{ gap: 12 }}>
            <TouchableOpacity
              onPress={handleRate}
              style={{
                backgroundColor: 'white',
                borderRadius: 12,
                padding: 15,
                flexDirection: 'row',
                alignItems: 'center',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 2,
                elevation: 2,
              }}
            >
              <Star size={20} color="#FFD700" />
              <Text style={{ flex: 1, fontSize: 16, color: '#333', marginLeft: 15 }}>
                {t('rate_app')}
              </Text>
              <ChevronRight size={16} color="#666" />
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleShare}
              style={{
                backgroundColor: 'white',
                borderRadius: 12,
                padding: 15,
                flexDirection: 'row',
                alignItems: 'center',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 2,
                elevation: 2,
              }}
            >
              <Share size={20} color="#4285F4" />
              <Text style={{ flex: 1, fontSize: 16, color: '#333', marginLeft: 15 }}>
                {t('share_app')}
              </Text>
              <ChevronRight size={16} color="#666" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Sign Out */}
        {isAuthenticated && (
          <View style={{ paddingHorizontal: 20, marginBottom: 30 }}>
            <TouchableOpacity
              onPress={handleLogout}
              style={{
                backgroundColor: 'white',
                borderRadius: 12,
                padding: 15,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.1,
                shadowRadius: 2,
                elevation: 2,
                borderWidth: 1,
                borderColor: '#F44336',
              }}
            >
              <LogOut size={20} color="#F44336" />
              <Text style={{ fontSize: 16, color: '#F44336', marginLeft: 10, fontWeight: '600' }}>
                {t('sign_out')}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* App Info */}
        <View style={{ paddingHorizontal: 20, marginBottom: 30, alignItems: 'center' }}>
          <Text style={{ fontSize: 12, color: '#999', textAlign: 'center' }}>
            {t('app_version')}
          </Text>
          <Text style={{ fontSize: 12, color: '#999', textAlign: 'center', marginTop: 5 }}>
            {t('made_with_love')}
          </Text>
          
          {/* Hidden Admin Access - Triple tap to reveal */}
          <TouchableOpacity
            onPress={() => {
              // Simple triple-tap detection
              const now = Date.now();
              if (!global.lastTap) global.lastTap = 0;
              if (!global.tapCount) global.tapCount = 0;
              
              if (now - global.lastTap < 500) {
                global.tapCount++;
                if (global.tapCount >= 3) {
                  global.tapCount = 0;
                  Alert.alert(
                    'Admin Access',
                    'Access admin panel?',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { 
                        text: 'Admin Login', 
                        onPress: () => {
                          const { router } = require('expo-router');
                          router.push('/admin/login');
                        }
                      }
                    ]
                  );
                }
              } else {
                global.tapCount = 1;
              }
              global.lastTap = now;
            }}
            style={{ 
              marginTop: 20, 
              padding: 10,
              opacity: 0.1 // Nearly invisible
            }}
          >
            <Shield size={16} color="#999" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}