import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import {
  Search,
  Mic,
  Bell,
  MapPin,
  FileText,
  CreditCard,
  Car,
  Calculator,
  Building2,
  Phone,
  Zap,
  Shield,
  Heart,
  Banknote,
  Train,
  Smartphone,
  Star,
  TrendingUp,
  ArrowRight,
  Plane,
  MessageCircle,
  Bot,
} from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { LanguageSelector } from '@/components/LanguageSelector';
import { AIChat } from '@/components/AIChat';
import { blink } from '@/lib/blink';

const { width } = Dimensions.get('window');
const cardWidth = (width - 60) / 2;

export default function HomeScreen() {
  const { user, isAuthenticated, login } = useAuth();
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [greeting, setGreeting] = useState('');
  const [showAIChat, setShowAIChat] = useState(false);

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting(t('good_morning'));
    else if (hour < 17) setGreeting(t('good_afternoon'));
    else setGreeting(t('good_evening'));
  }, [t]);

  const quickActions = [
    {
      id: 'transport',
      title: 'Transportation',
      subtitle: 'Book trains, buses & flights',
      icon: Car,
      color: '#4285F4',
      gradient: ['#4285F4', '#5A9BF8'],
      route: 'transport',
      popular: true,
    },
    {
      id: 'finance',
      title: 'Finance Tools',
      subtitle: 'GST calculator & more',
      icon: Calculator,
      color: '#9C27B0',
      gradient: ['#9C27B0', '#BA68C8'],
      route: 'finance',
      popular: true,
    },
    {
      id: 'emergency',
      title: 'Emergency Services',
      subtitle: 'Quick access to help',
      icon: Phone,
      color: '#F44336',
      gradient: ['#F44336', '#EF5350'],
      route: 'local',
      popular: false,
    },
    {
      id: 'government',
      title: 'Government Services',
      subtitle: 'Official portals & services',
      icon: Building2,
      color: '#003366',
      gradient: ['#003366', '#004080'],
      route: 'government',
      popular: false,
    },
  ];

  const workingServices = [
    { title: 'Hospitals', icon: Heart, color: '#F44336', gradient: ['#F44336', '#EF5350'], route: 'local' },
    { title: 'Hotels', icon: Building2, color: '#E91E63', gradient: ['#E91E63', '#F06292'], route: 'transport' },
    { title: 'Fuel Stations', icon: Car, color: '#FF6B35', gradient: ['#FF6B35', '#FF8A65'], route: 'transport' },
    { title: 'Airport Info', icon: Plane, color: '#607D8B', gradient: ['#607D8B', '#90A4AE'], route: 'transport' },
  ];

  const utilityServices = [
    { title: 'Railway Services', icon: Train, color: '#4285F4', gradient: ['#4285F4', '#5A9BF8'], route: 'transport' },
    { title: 'Finance Tools', icon: Calculator, color: '#9C27B0', gradient: ['#9C27B0', '#BA68C8'], route: 'finance' },
    { title: 'Emergency', icon: Phone, color: '#F44336', gradient: ['#F44336', '#EF5350'], route: 'local' },
    { title: 'Government', icon: Building2, color: '#003366', gradient: ['#003366', '#004080'], route: 'government' },
  ];

  const handleQuickAction = (action: any) => {
    if (!isAuthenticated) {
      Alert.alert(
        t('sign_in_required'),
        t('sign_in_required_message'),
        [
          { text: t('cancel'), style: 'cancel' },
          { text: t('sign_in'), onPress: () => login() },
        ]
      );
      return;
    }
    // Navigate to the specified tab
    router.push(`/(tabs)/${action.route}`);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      Alert.alert('Search', `Searching for: ${searchQuery}`);
    }
  };

  const handleVoiceSearch = () => {
    Alert.alert(t('voice_search'), t('voice_search_coming_soon'));
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={['#003366', '#004080']}
        style={styles.header}
      >
        <View style={styles.headerTop}>
          <View style={styles.greetingSection}>
            <Text style={styles.greetingText}>{greeting}</Text>
            <Text style={styles.welcomeText}>
              {isAuthenticated ? user?.displayName || 'User' : t('welcome_to_india_helper')}
            </Text>
          </View>
          
          <View style={styles.headerActions}>
            <LanguageSelector />
            <TouchableOpacity style={styles.headerButton}>
              <MapPin size={20} color="white" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerButton}>
              <Bell size={20} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <Search size={20} color="#666" />
          <TextInput
            style={styles.searchInput}
            placeholder={t('search_placeholder')}
            placeholderTextColor="#999"
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
          />
          <TouchableOpacity onPress={handleVoiceSearch} style={styles.voiceButton}>
            <Mic size={20} color="#003366" />
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* Quick Actions */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>{t('quick_actions')}</Text>
            <View style={styles.trendingBadge}>
              <TrendingUp size={14} color="#FF6B35" />
              <Text style={styles.trendingText}>Popular</Text>
            </View>
          </View>
          
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                onPress={() => handleQuickAction(action)}
                style={styles.quickActionCard}
              >
                {action.popular && (
                  <View style={styles.popularBadge}>
                    <Star size={10} color="white" />
                  </View>
                )}
                
                <LinearGradient
                  colors={action.gradient}
                  style={styles.quickActionIcon}
                >
                  <action.icon size={28} color="white" />
                </LinearGradient>
                
                <View style={styles.quickActionContent}>
                  <Text style={styles.quickActionTitle}>{action.title}</Text>
                  <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                </View>
                
                <ArrowRight size={16} color="#666" style={styles.quickActionArrow} />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Working Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Available Services</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.horizontalGrid}>
              {workingServices.map((service, index) => (
                <TouchableOpacity 
                  key={index} 
                  style={styles.serviceCard}
                  onPress={() => handleQuickAction(service)}
                >
                  <LinearGradient
                    colors={service.gradient}
                    style={styles.serviceIcon}
                  >
                    <service.icon size={24} color="white" />
                  </LinearGradient>
                  <Text style={styles.serviceTitle}>{service.title}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Quick Access */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Access</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.horizontalGrid}>
              {utilityServices.map((service, index) => (
                <TouchableOpacity 
                  key={index} 
                  style={styles.serviceCard}
                  onPress={() => handleQuickAction(service)}
                >
                  <LinearGradient
                    colors={service.gradient}
                    style={styles.serviceIcon}
                  >
                    <service.icon size={24} color="white" />
                  </LinearGradient>
                  <Text style={styles.serviceTitle}>{service.title}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Emergency Section */}
        <View style={styles.section}>
          <LinearGradient
            colors={['#F44336', '#D32F2F']}
            style={styles.emergencyCard}
          >
            <View style={styles.emergencyContent}>
              <View style={styles.emergencyInfo}>
                <Text style={styles.emergencyTitle}>{t('emergency_services')}</Text>
                <Text style={styles.emergencyDescription}>
                  {t('emergency_description')}
                </Text>
              </View>
              <TouchableOpacity style={styles.emergencyButton}>
                <Phone size={28} color="white" />
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {/* Sign In CTA */}
        {!isAuthenticated && (
          <View style={styles.section}>
            <View style={styles.signInCard}>
              <Text style={styles.signInTitle}>{t('sign_in_to_access')}</Text>
              <Text style={styles.signInDescription}>
                {t('sign_in_description')}
              </Text>
              <TouchableOpacity
                onPress={() => login()}
                style={styles.signInButton}
              >
                <Text style={styles.signInButtonText}>{t('sign_in_now')}</Text>
                <ArrowRight size={16} color="white" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Floating AI Chat Button */}
      <TouchableOpacity
        style={styles.aiChatButton}
        onPress={() => setShowAIChat(true)}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#00A86B', '#00C878']}
          style={styles.aiChatButtonGradient}
        >
          <Bot size={28} color="white" />
        </LinearGradient>
      </TouchableOpacity>

      {/* AI Chat Modal */}
      <AIChat
        visible={showAIChat}
        onClose={() => setShowAIChat(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  greetingSection: {
    flex: 1,
  },
  greetingText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    marginBottom: 4,
  },
  welcomeText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 12,
    borderRadius: 24,
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 28,
    paddingHorizontal: 20,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: '#333',
  },
  voiceButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#003366',
  },
  trendingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 107, 53, 0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  trendingText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FF6B35',
  },
  quickActionsGrid: {
    gap: 16,
  },
  quickActionCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
    position: 'relative',
  },
  popularBadge: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: '#FF6B35',
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  quickActionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  quickActionContent: {
    flex: 1,
  },
  quickActionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  quickActionArrow: {
    marginLeft: 12,
  },
  horizontalGrid: {
    flexDirection: 'row',
    gap: 16,
    paddingRight: 20,
  },
  serviceCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    minWidth: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  serviceIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  serviceTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  emergencyCard: {
    borderRadius: 20,
    padding: 24,
  },
  emergencyContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  emergencyInfo: {
    flex: 1,
  },
  emergencyTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emergencyDescription: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 20,
  },
  emergencyButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 16,
    borderRadius: 32,
  },
  signInCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  signInTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#003366',
    marginBottom: 12,
  },
  signInDescription: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  signInButton: {
    backgroundColor: '#003366',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 28,
    gap: 8,
  },
  signInButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  aiChatButton: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  aiChatButtonGradient: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
});