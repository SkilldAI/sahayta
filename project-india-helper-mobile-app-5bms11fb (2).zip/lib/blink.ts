import { createClient } from '@blinkdotnew/sdk'

// Initialize Blink client for India Helper app
export const blink = createClient({
  projectId: 'india-helper-mobile-app-5bms11fb', // Your project ID
  authRequired: false // We'll enable this later when needed
})

// Export individual services for easier imports
export const { auth, db, storage, ai, data, notifications, realtime, analytics } = blink

// Helper function to check if user is authenticated
export const isAuthenticated = () => {
  return blink.auth.isAuthenticated()
}

// Helper function to get current user
export const getCurrentUser = async () => {
  try {
    return await blink.auth.me()
  } catch (error) {
    console.log('User not authenticated')
    return null
  }
}